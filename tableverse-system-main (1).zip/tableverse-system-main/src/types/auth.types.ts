
import { Session, User } from '@supabase/supabase-js';

export interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: any | null;
  loading: boolean;
  authChecked: boolean;
  signUp: (data: { email: string; password: string; firstName: string; lastName: string }) => Promise<void>;
  signIn: (data: { email: string; password: string; rememberMe?: boolean }) => Promise<void>;
  signOut: () => Promise<void>;
  inviteUser: (email: string, role: string) => Promise<void>;
  createRestaurant: (data: RestaurantData) => Promise<string | undefined>;
  isRestaurantDialogOpen: boolean;
  setIsRestaurantDialogOpen: (open: boolean) => void;
}

export interface SignUpData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

export interface SignInData {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RestaurantData {
  name: string;
  address: string;
  phone: string;
}
