
export interface Order {
  order_id: string;
  table_id: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  total: number;
  items_count: number;
  created_at: string;
  updated_at: string;
  table_name?: string; // Joined from tables
  customer_name?: string;
  customer_phone?: string;
}

export interface OrderItem {
  item_id: string;
  order_id: string;
  menu_item_id: string;
  quantity: number;
  price: number;
  notes?: string;
  created_at: string;
  name?: string; // Joined from menu_items
  description?: string; // Joined from menu_items
  menu_item?: {
    mi_name: string;
    mi_description?: string;
  };
  menu_items?: {
    mi_name: string;
    mi_description?: string;
  }; // For direct join from Supabase
}

export type OrderStatus = 'Pending' | 'In Progress' | 'Ready' | 'Completed' | 'Cancelled';
export type PaymentStatus = 'Unpaid' | 'Prepaid' | 'Paid';

export interface OrderWithItems extends Order {
  items: OrderItem[];
  order_items?: OrderItem[]; // Include this for backward compatibility
}

export interface CartItem {
  id: string;
  name: string;
  price: number;
  price_variation_id?: string | null;
  price_variation_name?: string | null;
  quantity: number;
  notes?: string;
  size?: string; 
  specialInstructions?: string;
}
