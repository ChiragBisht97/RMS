
export interface TableItem {
  id: string;
  name: string;
  capacity: number;
  status: string;
  location: string | null;
  qr_code: string | null;
  created_at: string;
  updated_at: string;
}

export interface MenuItemAttributes {
  isVegan?: boolean;
  isVegetarian?: boolean;
  isGlutenFree?: boolean;
  isSpicy?: boolean;
  isChefChoice?: boolean;
  isBundle?: boolean;
}

export interface PriceVariation {
  size: string;
  price: string;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string | null;
  price: number;
  imageUrl: string | null;
  categoryId: string | null;
  categoryName?: string | null; // Added to store category name
  inStock: boolean;
  attributes?: MenuItemAttributes;
  variations?: PriceVariation[];
  tenantId?: string; // Added for multi-tenant support
}

export interface Category {
  id: string;
  name: string;
  description: string | null;
  order: number; // Add order field for sorting
  tenantId?: string; // Added for multi-tenant support
}

// Interface for Tenant (Restaurant) information
export interface Tenant {
  id: string;
  name: string;
  plan: 'free' | 'basic' | 'premium' | 'enterprise';
  status: 'active' | 'suspended' | 'trial';
  trialEndsAt?: string;
  createdAt: string;
  updatedAt: string;
  ownerId: string;
}

// Interface for Subscription information
export interface Subscription {
  id: string;
  tenantId: string;
  plan: 'free' | 'basic' | 'premium' | 'enterprise';
  status: 'active' | 'canceled' | 'past_due';
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
}
