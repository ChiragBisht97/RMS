
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { MenuItem, MenuItemAttributes, PriceVariation } from '@/types/tables';
import { Json } from '@/integrations/supabase/types';

interface UseMenuItemFormProps {
  onSuccess: () => void;
  onCloseDialog: () => void;
  restaurantId: string | null;
  isEditing: boolean;
  itemId?: string;
}

export interface MenuItemFormData {
  name: string;
  description: string;
  price: number;
  categoryId: string;
  inStock: boolean;
  isVegan: boolean;
  isVegetarian: boolean;
  isGlutenFree: boolean;
  isSpicy: boolean;
  isChefChoice: boolean;
  isBundle: boolean;
}

export const useMenuItemForm = ({
  onSuccess,
  onCloseDialog,
  restaurantId,
  isEditing,
  itemId
}: UseMenuItemFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [useVariations, setUseVariations] = useState(false);
  const [variations, setVariations] = useState<PriceVariation[]>([{ size: 'Regular', price: '0' }]);

  const handleImageChange = (file: File | null, preview: string | null) => {
    setImageFile(file);
    setImagePreview(preview);
  };

  const toggleUseVariations = () => {
    setUseVariations(!useVariations);
  };

  const handleImageUpload = async (file: File): Promise<string | null> => {
    try {
      if (!restaurantId) {
        throw new Error('Restaurant ID is missing');
      }
      
      const filePath = `${restaurantId}/${Date.now()}-${file.name}`;
      
      const { data, error } = await supabase.storage
        .from('menuimages')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });
      
      if (error) {
        console.error('Storage upload error:', error);
        throw error;
      }
      
      const { data: publicUrlData } = supabase.storage
        .from('menuimages')
        .getPublicUrl(filePath);
      
      return publicUrlData.publicUrl;
    } catch (error: any) {
      console.error('Error uploading image:', error);
      toast({
        title: 'Error',
        description: 'Failed to upload image: ' + error.message,
        variant: 'destructive',
      });
      return null;
    }
  };

  const onSubmit = async (data: MenuItemFormData) => {
    try {
      setIsSubmitting(true);
      
      if (!restaurantId) {
        toast({
          title: 'Error',
          description: 'Restaurant ID is missing. Please try again later.',
          variant: 'destructive',
        });
        return;
      }

      let finalImageUrl = null;
      
      if (imageFile) {
        finalImageUrl = await handleImageUpload(imageFile);
        if (!finalImageUrl) {
          toast({
            title: 'Warning',
            description: 'Could not upload image, but the item will still be saved.',
            variant: 'default',
          });
        }
      }

      const attributes: MenuItemAttributes = {
        isVegan: data.isVegan,
        isVegetarian: data.isVegetarian,
        isGlutenFree: data.isGlutenFree,
        isSpicy: data.isSpicy,
        isChefChoice: data.isChefChoice,
        isBundle: data.isBundle,
      };

      const itemData = {
        mi_name: data.name,
        mi_description: data.description,
        mi_price: parseFloat(data.price.toString()),
        mi_image_url: finalImageUrl,
        mi_category_id: data.categoryId === 'none' ? null : data.categoryId,
        mi_updated_at: new Date().toISOString(),
        mi_in_stock: data.inStock,
        mi_active: true,
        mi_attributes: attributes as unknown as Json,
        mi_variations: useVariations ? variations as unknown as Json : null,
        restaurant_id: restaurantId
      };

      if (isEditing && itemId) {
        console.log("Updating item:", itemId, itemData);
        
        const { error } = await supabase
          .from('menu_items')
          .update(itemData)
          .eq('mi_id', itemId);

        if (error) {
          console.error("Update error:", error);
          throw error;
        }
        
        toast({
          title: 'Menu item updated',
          description: 'The menu item has been updated successfully.',
        });
      } else {
        console.log("Creating new item:", itemData);
        
        const { error } = await supabase
          .from('menu_items')
          .insert({
            ...itemData,
            mi_created_at: new Date().toISOString(),
          });

        if (error) {
          console.error("Insert error:", error);
          throw error;
        }
        
        toast({
          title: 'Menu item created',
          description: 'The new menu item has been created successfully.',
        });
      }
      
      onSuccess();
      onCloseDialog();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save menu item.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    isSubmitting,
    imagePreview,
    useVariations,
    variations,
    setVariations,
    handleImageChange,
    toggleUseVariations,
    onSubmit
  };
};
