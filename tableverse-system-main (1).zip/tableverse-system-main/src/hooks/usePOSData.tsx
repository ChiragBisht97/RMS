
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { useCurrency } from './useCurrency';

export const usePOSData = () => {
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [filteredItems, setFilteredItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [tables, setTables] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentTab, setCurrentTab] = useState('all');
  const { profile } = useAuth();
  const { taxPercentage, applyTax } = useCurrency();

  // Fetch data function
  const fetchData = useCallback(async () => {
    if (!profile?.restaurant_id) return;

    setLoading(true);
    
    try {
      // Fetch tables data
      const { data: tablesData, error: tablesError } = await supabase
        .from('tables')
        .select('*')
        .eq('restaurant_id', profile.restaurant_id);
      
      if (tablesError) throw tablesError;
      
      // Transform tables data
      const transformedTables = tablesData.map(table => ({
        id: table.tb_id,
        name: table.tb_name,
        status: table.tb_status,
        capacity: table.tb_capacity,
        qrCode: table.tb_qr_code
      }));
      
      // Force a fresh check of table status
      await checkTableStatuses(transformedTables);
      
      // Fetch menu categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('menu_categories')
        .select('*')
        .eq('restaurant_id', profile.restaurant_id)
        .order('mc_order', { ascending: true });
      
      if (categoriesError) throw categoriesError;
      
      const transformedCategories = categoriesData.map(cat => ({
        id: cat.mc_id,
        name: cat.mc_name
      }));
      
      // Add "All Items" category (only once)
      setCategories([
        {
          id: 'all',
          name: 'All Items'
        },
        ...transformedCategories
      ]);
      
      // Fetch menu items
      const { data: itemsData, error: itemsError } = await supabase
        .from('menu_items')
        .select(`
          *,
          menu_categories(*)
        `)
        .eq('restaurant_id', profile.restaurant_id)
        .eq('mi_active', true);
      
      if (itemsError) throw itemsError;
      
      const transformedItems = itemsData.map(item => {
        // Safely cast attributes
        let attributes = {};
        if (item.mi_attributes) {
          try {
            attributes = item.mi_attributes as any;
          } catch (e) {
            console.error('Error parsing attributes:', e);
          }
        }
        
        // Safely cast variations
        let variations = [];
        if (item.mi_variations) {
          try {
            // If mi_variations is already an array, map it to ensure it has the right structure
            if (Array.isArray(item.mi_variations)) {
              variations = item.mi_variations.map(variation => ({
                size: (variation as any).size || '',
                price: (variation as any).price || '0'
              }));
            }
          } catch (e) {
            console.error('Error parsing variations:', e);
          }
        }
        
        return {
          id: item.mi_id,
          name: item.mi_name,
          description: item.mi_description,
          price: item.mi_price,
          imageUrl: item.mi_image_url,
          categoryId: item.mi_category_id,
          categoryName: item.menu_categories ? item.menu_categories.mc_name : '',
          inStock: item.mi_in_stock !== false,
          attributes,
          variations
        };
      });
      
      setMenuItems(transformedItems);
      setFilteredItems(transformedItems);
      
    } catch (error) {
      console.error('Error fetching POS data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load POS data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [profile?.restaurant_id]);

  // Function to check and update table statuses based on active orders
  const checkTableStatuses = async (tablesList) => {
    if (!profile?.restaurant_id) return;
    
    try {
      // Get all tables with active orders
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('table_id')
        .not('table_id', 'is', null)
        .eq('restaurant_id', profile.restaurant_id) // Filter by restaurant_id
        .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
        .neq('payment_status', 'Paid')
        .neq('payment_status', 'Prepaid')
        .order('created_at', { ascending: false });
      
      if (ordersError) throw ordersError;
      
      // Create a set of table IDs with active orders
      const tableIdsWithActiveOrders = new Set(ordersData.map(order => order.table_id));
      console.log('Tables with active orders:', Array.from(tableIdsWithActiveOrders));
      
      // Update local table status based on active orders
      const updatedTables = tablesList.map(table => {
        // If table has active orders, it should be marked as occupied
        if (tableIdsWithActiveOrders.has(table.id) && table.status !== 'Occupied') {
          // Update database status to match reality
          updateTableStatus(table.id, 'Occupied');
          return { ...table, status: 'Occupied' };
        }
        return table;
      });
      
      setTables(updatedTables);
      
    } catch (error) {
      console.error('Error checking table statuses:', error);
    }
  };
  
  // Helper function to update table status in database
  const updateTableStatus = async (tableId, status) => {
    try {
      const { error } = await supabase
        .from('tables')
        .update({ tb_status: status })
        .eq('tb_id', tableId);
      
      if (error) {
        console.error('Error updating table status in database:', error);
      } else {
        console.log(`Table ${tableId} status updated to ${status} in database`);
      }
    } catch (error) {
      console.error('Exception updating table status:', error);
    }
  };

  // Filter items by category and search query
  useEffect(() => {
    if (!menuItems.length) return;
    
    let filtered = menuItems;
    
    // Filter by category
    if (currentTab !== 'all') {
      filtered = filtered.filter(item => item.categoryId === currentTab);
    }
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        item => 
          item.name.toLowerCase().includes(query) || 
          (item.description && item.description.toLowerCase().includes(query)) ||
          (item.categoryName && item.categoryName.toLowerCase().includes(query))
      );
    }
    
    setFilteredItems(filtered);
  }, [menuItems, currentTab, searchQuery]);
  
  // Load data on component mount
  useEffect(() => {
    fetchData();
    
    // Set up polling to refresh table status every minute
    const refreshInterval = setInterval(() => {
      if (profile?.restaurant_id) {
        fetchData();
      }
    }, 60000); // 60 seconds refresh interval
    
    return () => {
      clearInterval(refreshInterval);
    };
  }, [fetchData, profile?.restaurant_id]);
  
  // Return data and functions
  return {
    filteredItems,
    tables,
    loading,
    searchQuery,
    setSearchQuery,
    currentTab,
    setCurrentTab,
    categories,
    taxPercentage: taxPercentage || 8,
    fetchData
  };
};
