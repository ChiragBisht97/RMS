import { useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { MenuItem } from '@/types/tables';
import { OrderStatus, PaymentStatus, CartItem } from '@/types/orders';
import { supabase } from '@/integrations/supabase/client';
import { updateOrdersPaymentStatus } from '@/components/pos/services/paymentService';
import { calculateOrderTotals } from '@/utils/formatCurrency';
import { useCurrency } from '@/hooks/useCurrency';

export const useCart = (taxPercentage: number = 8) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [orderType, setOrderType] = useState<'table' | 'walkin'>('table');
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<any>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { applyServiceCharge, serviceChargePercentage } = useCurrency();

  const addToCart = (item: MenuItem) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
      setCart(cart.map(cartItem => 
        cartItem.id === item.id 
          ? { ...cartItem, quantity: cartItem.quantity + 1 } 
          : cartItem
      ));
    } else {
      setCart([...cart, { id: item.id, name: item.name, price: item.price, quantity: 1, notes: '' }]);
    }
  };
  
  const updateQuantity = (id: string, change: number) => {
    setCart(cart.map(item => 
      item.id === id 
        ? { ...item, quantity: Math.max(1, item.quantity + change) } 
        : item
    ));
  };
  
  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };
  
  const clearCart = () => {
    setCart([]);
    setSelectedTable(null);
    setOrderType('table');
    setCurrentOrder(null);
  };

  const handleOrderCreated = () => {
    clearCart();
    toast({
      title: 'Success',
      description: 'Order has been created successfully',
    });
  };

  const handleTableSelect = async (tableId: string) => {
    setSelectedTable(tableId);
    setOrderType(tableId === 'walkin' ? 'walkin' : 'table');
    
    setIsLoading(true);
    try {
      if (tableId === 'walkin') {
        console.log("Fetching walk-in orders");
        const { data: orderData, error } = await supabase
          .from('orders')
          .select('*')
          .is('table_id', null)
          .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
          .neq('payment_status', 'Paid')
          .neq('payment_status', 'Prepaid')
          .order('created_at', { ascending: false })
          .limit(1);
        
        console.log("Walk-in orders result:", orderData);
        
        if (orderData && orderData.length > 0) {
          setCurrentOrder(orderData[0]);
          
          const { data: orderItems } = await supabase
            .from('order_items')
            .select(`
              item_id,
              menu_item_id,
              quantity,
              price,
              menu_items:menu_item_id (mi_name)
            `)
            .eq('order_id', orderData[0].order_id);
          
          if (orderItems && orderItems.length > 0) {
            setCart(orderItems.map((item: any) => ({
              id: item.menu_item_id,
              name: item.menu_items?.mi_name || 'Unknown Item',
              price: item.price,
              quantity: item.quantity
            })));
          }
        } else {
          setCurrentOrder(null);
          setCart([]);
        }
        return;
      }
      
      const { data: tableData } = await supabase
        .from('tables')
        .select('tb_status')
        .eq('tb_id', tableId)
        .single();
      
      if (tableData?.tb_status === 'Occupied') {
        const { data: orderData, error } = await supabase
          .from('orders')
          .select('*')
          .eq('table_id', tableId)
          .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
          .neq('payment_status', 'Paid')
          .order('created_at', { ascending: false })
          .limit(1);
        
        if (orderData && orderData.length > 0) {
          setCurrentOrder(orderData[0]);
          
          const { data: orderItems } = await supabase
            .from('order_items')
            .select(`
              item_id,
              menu_item_id,
              quantity,
              price,
              menu_items:menu_item_id (mi_name)
            `)
            .eq('order_id', orderData[0].order_id);
          
          if (orderItems && orderItems.length > 0) {
            setCart(orderItems.map((item: any) => ({
              id: item.menu_item_id,
              name: item.menu_items?.mi_name || 'Unknown Item',
              price: item.price,
              quantity: item.quantity
            })));
          }
        } else {
          toast({
            title: 'No Active Order',
            description: 'This table is marked as occupied but has no active orders.',
            variant: 'destructive',
          });
          setCurrentOrder(null);
          setCart([]);
        }
      } else {
        setCurrentOrder(null);
        setCart([]);
      }
    } catch (error) {
      console.error('Error loading table order:', error);
      toast({
        title: 'Error',
        description: 'Could not load table information',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const setWalkInOrder = () => {
    setSelectedTable('walkin');
    setOrderType('walkin');
    setCurrentOrder(null);
    setCart([]);
  };

  const voidLineItem = async (itemId: string) => {
    if (!currentOrder?.order_id) {
      toast({
        title: 'Error',
        description: 'No active order to void item from',
        variant: 'destructive',
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const itemToRemove = cart.find(item => item.id === itemId);
      if (!itemToRemove) {
        throw new Error('Item not found in cart');
      }
      
      const { data: orderItems, error: findError } = await supabase
        .from('order_items')
        .select('item_id')
        .eq('order_id', currentOrder.order_id)
        .eq('menu_item_id', itemId)
        .limit(1);
      
      if (findError || !orderItems || orderItems.length === 0) {
        throw new Error('Could not find order item in database');
      }
      
      const { error: deleteError } = await supabase
        .from('order_items')
        .delete()
        .eq('item_id', orderItems[0].item_id);
      
      if (deleteError) {
        throw deleteError;
      }
      
      const updatedCart = cart.filter(item => item.id !== itemId);
      setCart(updatedCart);
      
      const newSubtotal = updatedCart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const newTax = newSubtotal * (taxPercentage / 100);
      const newTotal = newSubtotal + newTax;
      const newItemsCount = updatedCart.reduce((sum, item) => sum + item.quantity, 0);
      
      if (updatedCart.length === 0) {
        await voidOrder();
      } else {
        const { error: updateError } = await supabase
          .from('orders')
          .update({
            total: newTotal,
            items_count: newItemsCount,
            updated_at: new Date().toISOString()
          })
          .eq('order_id', currentOrder.order_id);
        
        if (updateError) {
          throw updateError;
        }
        
        setCurrentOrder({
          ...currentOrder,
          total: newTotal,
          items_count: newItemsCount,
          updated_at: new Date().toISOString()
        });
      }
      
      toast({
        title: 'Item Voided',
        description: `${itemToRemove.name} has been removed from the order`,
      });
    } catch (error) {
      console.error('Error voiding item:', error);
      toast({
        title: 'Error',
        description: 'Could not void the item',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const voidOrder = async () => {
    if (!currentOrder?.order_id) {
      toast({
        title: 'Error',
        description: 'No active order to void',
        variant: 'destructive',
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const { error: updateError } = await supabase
        .from('orders')
        .update({
          status: 'Cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('order_id', currentOrder.order_id);
      
      if (updateError) {
        throw updateError;
      }
      
      if (selectedTable && selectedTable !== 'walkin') {
        const { error: tableError } = await supabase
          .from('tables')
          .update({ tb_status: 'Available' })
          .eq('tb_id', selectedTable);
        
        if (tableError) {
          throw tableError;
        }
      }
      
      clearCart();
      
      toast({
        title: 'Order Voided',
        description: `Order #${currentOrder.order_id.slice(-4)} has been cancelled`,
      });
    } catch (error) {
      console.error('Error voiding order:', error);
      toast({
        title: 'Error',
        description: 'Could not void the order',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const processPayment = async (paymentMethod: 'cash' | 'card' | 'mobile') => {
    if (!currentOrder && cart.length === 0) {
      toast({
        title: 'Error',
        description: 'No order to process payment for',
        variant: 'destructive',
      });
      return false;
    }
    
    setIsLoading(true);
    
    try {
      let orderId = currentOrder?.order_id;
      
      if (orderId) {
        const newPaymentStatus: PaymentStatus = currentOrder.status === 'Completed' ? 'Paid' : 'Prepaid';
        const shouldReleaseTable = currentOrder.status === 'Completed' && currentOrder.table_id;
        
        const success = await updateOrdersPaymentStatus([orderId], newPaymentStatus, shouldReleaseTable);
        
        if (success) {
          toast({
            title: 'Payment Successful',
            description: `Payment processed via ${paymentMethod}. Order ${currentOrder.status === 'Completed' ? 'completed' : 'prepaid'}.`,
          });
          
          clearCart();
          setIsPaymentModalOpen(false);
          
          return true;
        }
        return false;
      }
      return false;
    } catch (error) {
      console.error('Error processing payment:', error);
      toast({
        title: 'Payment Failed',
        description: 'There was an error processing the payment',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const { tax, serviceCharge, total } = calculateOrderTotals(
    subtotal, 
    taxPercentage, 
    serviceChargePercentage, 
    applyServiceCharge
  );

  return {
    cart,
    selectedTable,
    orderType,
    isCreateOrderOpen,
    setIsCreateOrderOpen,
    subtotal,
    tax,
    serviceCharge,
    total,
    taxPercentage,
    currentOrder,
    isPaymentModalOpen,
    setIsPaymentModalOpen,
    isLoading,
    applyServiceCharge,
    serviceChargePercentage,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    handleOrderCreated,
    handleTableSelect,
    setWalkInOrder,
    setOrderType,
    processPayment,
    voidLineItem,
    voidOrder
  };
};
