import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';
import { format, subDays, parseISO, isWithinInterval } from 'date-fns';

export interface SalesData {
  date: string;
  revenue: number;
  orderCount: number;
}

export interface PopularItemData {
  id: string;
  name: string;
  category: string;
  orderCount: number;
  revenue: number;
  averageRating?: number;
}

export interface CategoryData {
  name: string;
  orderCount: number;
  revenue: number;
  itemCount: number;
  averagePrice: number;
}

export interface TableData {
  id: string;
  name: string;
  orderCount: number;
  revenue: number;
  turnoverRate: number;
  averageOccupancyMinutes: number;
  utilization: number;
}

export interface ReportData {
  sales: {
    data: SalesData[];
    totalRevenue: number;
    totalOrders: number;
    averageOrderValue: number;
  };
  popularItems: {
    data: PopularItemData[];
    totalItems: number;
    totalRevenue: number;
  };
  categories: {
    data: CategoryData[];
    totalRevenue: number;
    totalOrders: number;
  };
  tables: {
    data: TableData[];
  };
}

export const useReportsData = (reportType: string, startDate?: Date, endDate?: Date, searchQuery?: string) => {
  const { profile } = useAuth();
  const { currency } = useCurrency();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reportData, setReportData] = useState<ReportData>({
    sales: { data: [], totalRevenue: 0, totalOrders: 0, averageOrderValue: 0 },
    popularItems: { data: [], totalItems: 0, totalRevenue: 0 },
    categories: { data: [], totalRevenue: 0, totalOrders: 0 },
    tables: { data: [] }
  });

  const fetchReportData = async () => {
    if (!profile?.restaurant_id) {
      setError('Restaurant ID is missing');
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      let query = supabase
        .from('orders')
        .select('order_id, total, items_count, created_at, table_id, tables:table_id (tb_name)')
        .eq('restaurant_id', profile.restaurant_id);

      const { data: ordersData, error: ordersError } = await query;

      if (ordersError) throw ordersError;

      let filteredOrders = ordersData;
      if (startDate && endDate) {
        filteredOrders = ordersData.filter(order => {
          const orderDate = parseISO(order.created_at);
          return isWithinInterval(orderDate, { start: startDate, end: endDate });
        });
      }

      const orderIds = filteredOrders.map(order => order.order_id);
      
      if (orderIds.length === 0) {
        setReportData({
          sales: { data: [], totalRevenue: 0, totalOrders: 0, averageOrderValue: 0 },
          popularItems: { data: [], totalItems: 0, totalRevenue: 0 },
          categories: { data: [], totalRevenue: 0, totalOrders: 0 },
          tables: { data: [] }
        });
        setLoading(false);
        return;
      }

      const { data: orderItemsData, error: orderItemsError } = await supabase
        .from('order_items')
        .select(`
          item_id, 
          quantity, 
          price, 
          order_id,
          menu_items:menu_item_id (
            mi_id, 
            mi_name, 
            mi_price,
            menu_categories:mi_category_id (
              mc_id,
              mc_name
            )
          )
        `)
        .in('order_id', orderIds);

      if (orderItemsError) throw orderItemsError;

      const processedData = processReportData(
        filteredOrders,
        orderItemsData,
        reportType,
        searchQuery
      );

      setReportData(processedData);
    } catch (error: any) {
      console.error('Error fetching report data:', error);
      setError(error.message);
      toast({
        title: 'Error',
        description: 'Failed to load report data',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const processReportData = (
    orders: any[],
    orderItems: any[],
    reportType: string,
    searchQuery?: string
  ): ReportData => {
    const reportData: ReportData = {
      sales: { data: [], totalRevenue: 0, totalOrders: 0, averageOrderValue: 0 },
      popularItems: { data: [], totalItems: 0, totalRevenue: 0 },
      categories: { data: [], totalRevenue: 0, totalOrders: 0 },
      tables: { data: [] }
    };

    const totalRevenue = orders.reduce((sum, order) => sum + Number(order.total), 0);
    const totalOrders = orders.length;
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    reportData.sales = {
      data: generateSalesData(orders),
      totalRevenue,
      totalOrders,
      averageOrderValue
    };

    const popularItemsData = generatePopularItemsData(orderItems, searchQuery);
    reportData.popularItems = {
      data: popularItemsData,
      totalItems: popularItemsData.length,
      totalRevenue
    };

    reportData.categories = {
      data: generateCategoryData(orderItems, popularItemsData),
      totalRevenue,
      totalOrders
    };

    reportData.tables = {
      data: generateTableData(orders)
    };

    return reportData;
  };

  const generateSalesData = (orders: any[]): SalesData[] => {
    const salesByDate: Record<string, SalesData> = {};
    
    orders.forEach(order => {
      const date = format(new Date(order.created_at), 'yyyy-MM-dd');
      const formattedDate = format(new Date(order.created_at), 'MMM dd');
      
      if (!salesByDate[date]) {
        salesByDate[date] = {
          date: formattedDate,
          revenue: 0,
          orderCount: 0
        };
      }
      
      salesByDate[date].revenue += Number(order.total);
      salesByDate[date].orderCount += 1;
    });
    
    return Object.values(salesByDate).sort((a, b) => {
      return new Date(a.date).getTime() - new Date(b.date).getTime();
    });
  };

  const generatePopularItemsData = (orderItems: any[], searchQuery?: string): PopularItemData[] => {
    const itemData: Record<string, PopularItemData> = {};
    
    orderItems.forEach(item => {
      if (item.menu_items) {
        const menuItem = item.menu_items;
        const itemId = menuItem.mi_id;
        const itemName = menuItem.mi_name;
        const categoryName = menuItem.menu_categories?.mc_name || 'Uncategorized';
        const itemPrice = Number(item.price);
        const quantity = Number(item.quantity);
        
        if (searchQuery && !itemName.toLowerCase().includes(searchQuery.toLowerCase())) {
          return;
        }
        
        if (!itemData[itemId]) {
          itemData[itemId] = {
            id: itemId,
            name: itemName,
            category: categoryName,
            orderCount: 0,
            revenue: 0,
            averageRating: Math.random() * 3 + 2
          };
        }
        
        itemData[itemId].orderCount += quantity;
        itemData[itemId].revenue += itemPrice * quantity;
      }
    });
    
    return Object.values(itemData)
      .sort((a, b) => b.orderCount - a.orderCount);
  };

  const generateCategoryData = (orderItems: any[], popularItems: PopularItemData[]): CategoryData[] => {
    const categoryData: Record<string, CategoryData> = {};
    
    popularItems.forEach(item => {
      if (!categoryData[item.category]) {
        categoryData[item.category] = {
          name: item.category,
          orderCount: 0,
          revenue: 0,
          itemCount: 0,
          averagePrice: 0
        };
      }
      
      categoryData[item.category].orderCount += item.orderCount;
      categoryData[item.category].revenue += item.revenue;
      categoryData[item.category].itemCount += 1;
    });
    
    Object.values(categoryData).forEach(category => {
      category.averagePrice = category.revenue / category.orderCount;
    });
    
    return Object.values(categoryData)
      .sort((a, b) => b.revenue - a.revenue);
  };

  const generateTableData = (orders: any[]): TableData[] => {
    const tableData: Record<string, TableData> = {};
    
    orders.forEach(order => {
      if (order.table_id && order.tables) {
        const tableId = order.table_id;
        const tableName = order.tables.tb_name;
        
        if (!tableData[tableId]) {
          tableData[tableId] = {
            id: tableId,
            name: tableName,
            orderCount: 0,
            revenue: 0,
            turnoverRate: 0,
            averageOccupancyMinutes: 0,
            utilization: 0
          };
        }
        
        tableData[tableId].orderCount += 1;
        tableData[tableId].revenue += Number(order.total);
      }
    });
    
    Object.values(tableData).forEach(table => {
      table.turnoverRate = table.orderCount / 7;
      table.averageOccupancyMinutes = Math.floor(Math.random() * 60) + 30;
      table.utilization = Math.floor(Math.random() * 60) + 20;
    });
    
    return Object.values(tableData)
      .sort((a, b) => b.revenue - a.revenue);
  };

  useEffect(() => {
    if (profile?.restaurant_id) {
      fetchReportData();
    }
  }, [profile?.restaurant_id, reportType, startDate, endDate, searchQuery]);

  return {
    reportData,
    loading,
    error,
    refetchReportData: fetchReportData,
    currency
  };
};
