import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { MenuItem, Category, MenuItemAttributes, PriceVariation } from '@/types/tables';
import { OrderWithItems, OrderItem } from '@/types/orders';
import { useCurrency } from './useCurrency';

export const useCustomerOrder = (tableId: string | undefined) => {
  // Explicitly set initializing state to true to prevent flashing
  const [loading, setLoading] = useState(true);
  const [table, setTable] = useState<any>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<MenuItem[]>([]);
  const [currentTab, setCurrentTab] = useState('all-items');
  const [isMenuLoading, setIsMenuLoading] = useState(true);

  // Get currency settings
  const { 
    currency, 
    applyServiceCharge: settingsApplyServiceCharge, 
    serviceChargePercentage: settingsServiceChargePercentage,
    isLoading: currencyLoading
  } = useCurrency();

  // Cart state
  const [cart, setCart] = useState<any[]>([]);
  const [subtotal, setSubtotal] = useState(0);
  const [tax, setTax] = useState(0);
  const [total, setTotal] = useState(0);
  const [serviceCharge, setServiceCharge] = useState(0);
  const [serviceChargePercentage, setServiceChargePercentage] = useState(0);
  const [applyServiceCharge, setApplyServiceCharge] = useState(false);
  
  // Order state
  const [currentOrder, setCurrentOrder] = useState<any>(null);
  const [currentOrderStatus, setCurrentOrderStatus] = useState<string | null>(null);
  const [pendingOrders, setPendingOrders] = useState<any[]>([]);
  const [isCreatingOrder, setIsCreatingOrder] = useState(false);

  // Get table information
  const fetchTable = useCallback(async () => {
    try {
      console.log('Fetching table with ID:', tableId);
      if (!tableId) {
        console.error('No table ID provided');
        setLoading(false);
        return;
      }
      
      const { data, error } = await supabase
        .from('tables')
        .select('*')
        .eq('tb_id', tableId)
        .maybeSingle();
      
      if (error) {
        console.error('Error fetching table:', error);
        setLoading(false);
        return;
      }
      
      console.log('Table data loaded:', data);
      setTable(data);
      
      // Once we have the table data with restaurant ID, fetch menu items
      if (data?.restaurant_id) {
        await fetchMenuCategories(data.restaurant_id);
        await fetchMenuItems(data.restaurant_id);
        // Fetch service charge settings
        await fetchServiceChargeSetting(data.restaurant_id);
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error in fetchTable:', error);
      setLoading(false);
    }
  }, [tableId]);

  // Fetch service charge settings from restaurant settings
  const fetchServiceChargeSetting = async (restaurantId: string) => {
    try {
      // Fetch service charge toggle setting
      const { data: serviceChargeData, error: serviceChargeError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'service_charge_enabled')
        .maybeSingle();
      
      if (!serviceChargeError && serviceChargeData?.setting_value) {
        setApplyServiceCharge(serviceChargeData.setting_value === 'true');
      }
      
      // Fetch service charge percentage setting
      const { data: serviceChargePercentageData, error: serviceChargePercentageError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'service_charge_percentage')
        .maybeSingle();
      
      if (!serviceChargePercentageError && serviceChargePercentageData?.setting_value) {
        setServiceChargePercentage(parseFloat(serviceChargePercentageData.setting_value));
      }
    } catch (error) {
      console.error('Error fetching service charge settings:', error);
    }
  };

  // Fetch restaurant menu categories
  const fetchMenuCategories = async (restaurantId: string) => {
    try {
      console.log('Fetching menu categories for restaurant:', restaurantId);
      const { data, error } = await supabase
        .from('menu_categories')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .order('mc_order', { ascending: true });
      
      if (error) {
        console.error('Error fetching menu categories:', error);
        return;
      }
      
      // Transform data to match required Category type
      const transformedCategories = data.map(cat => ({
        id: cat.mc_id,
        name: cat.mc_name,
        description: cat.mc_description || null,
        order: cat.mc_order || 0
      }));
      
      console.log('Menu categories loaded:', transformedCategories.length);
      setCategories(transformedCategories);
    } catch (error) {
      console.error('Error in fetchMenuCategories:', error);
    }
  };

  // Fetch restaurant menu items
  const fetchMenuItems = async (restaurantId: string) => {
    try {
      console.log('Fetching menu items for restaurant:', restaurantId);
      setIsMenuLoading(true);
      
      const { data, error } = await supabase
        .from('menu_items')
        .select(`
          *,
          menu_categories(*)
        `)
        .eq('restaurant_id', restaurantId)
        .eq('mi_active', true)
        .eq('mi_in_stock', true);
      
      if (error) {
        console.error('Error fetching menu items:', error);
        setIsMenuLoading(false);
        return;
      }
      
      // Transform data to match required MenuItem type with proper type conversion
      const transformedItems: MenuItem[] = data.map(item => {
        // Safely parse attributes
        let attributes: MenuItemAttributes = {
          isVegan: false,
          isVegetarian: false,
          isGlutenFree: false,
          isSpicy: false,
          isChefChoice: false,
          isBundle: false
        };
        
        if (item.mi_attributes) {
          try {
            // Parse attributes properly
            const rawAttrs = typeof item.mi_attributes === 'string' 
              ? JSON.parse(item.mi_attributes) 
              : item.mi_attributes;
              
            attributes = {
              isVegan: !!rawAttrs.isVegan,
              isVegetarian: !!rawAttrs.isVegetarian,
              isGlutenFree: !!rawAttrs.isGlutenFree,
              isSpicy: !!rawAttrs.isSpicy,
              isChefChoice: !!rawAttrs.isChefChoice,
              isBundle: !!rawAttrs.isBundle
            };
          } catch (e) {
            console.error('Error parsing attributes:', e);
          }
        }
        
        // Parse variations
        let variations: PriceVariation[] = [];
        if (item.mi_variations) {
          try {
            variations = typeof item.mi_variations === 'string'
              ? JSON.parse(item.mi_variations)
              : (Array.isArray(item.mi_variations) ? item.mi_variations : []);
          } catch (e) {
            console.error('Error parsing variations:', e);
          }
        }
        
        return {
          id: item.mi_id,
          name: item.mi_name,
          description: item.mi_description || '',
          price: item.mi_price,
          imageUrl: item.mi_image_url || '',
          categoryId: item.mi_category_id || '',
          categoryName: item.menu_categories ? item.menu_categories.mc_name : '',
          inStock: item.mi_in_stock || false,
          attributes,
          variations
        };
      });
      
      console.log('Menu items loaded:', transformedItems.length);
      setMenuItems(transformedItems);
      setFilteredItems(transformedItems);
      setIsMenuLoading(false);
    } catch (error) {
      console.error('Error in fetchMenuItems:', error);
      setIsMenuLoading(false);
    }
  };

  // Filter items by category
  useEffect(() => {
    if (currentTab === 'all-items') {
      setFilteredItems(menuItems);
    } else {
      const filtered = menuItems.filter(item => item.categoryId === currentTab);
      setFilteredItems(filtered);
    }
  }, [currentTab, menuItems]);

  // Initialize data on component mount
  useEffect(() => {
    console.log('useCustomerOrder hook initialized with table ID:', tableId);
    console.log('useCustomerOrder currency setting:', currency);
    
    // Start by fetching the table
    fetchTable();
    
    // Check localStorage for existing cart and order
    const storedCart = localStorage.getItem(`cart-${tableId}`);
    if (storedCart) {
      try {
        setCart(JSON.parse(storedCart));
      } catch (e) {
        console.error('Error parsing stored cart:', e);
      }
    }
    
    const storedOrder = localStorage.getItem(`order-${tableId}`);
    if (storedOrder) {
      try {
        const order = JSON.parse(storedOrder);
        setCurrentOrder(order);
        setCurrentOrderStatus(order.status);
      } catch (e) {
        console.error('Error parsing stored order:', e);
      }
    }
    
    // Return cleanup function
    return () => {
      // Clean up any subscriptions or listeners here
    };
  }, [fetchTable, tableId, currency]);

  // Use currency settings from useCurrency when they're loaded
  useEffect(() => {
    if (!currencyLoading) {
      console.log('Using service charge settings from useCurrency:', { 
        settingsApplyServiceCharge, 
        settingsServiceChargePercentage 
      });
      
      if (settingsApplyServiceCharge !== undefined) {
        setApplyServiceCharge(settingsApplyServiceCharge);
      }
      
      if (settingsServiceChargePercentage !== undefined) {
        setServiceChargePercentage(settingsServiceChargePercentage);
      }
    }
  }, [currencyLoading, settingsApplyServiceCharge, settingsServiceChargePercentage]);

  // Update totals whenever cart changes
  useEffect(() => {
    const calculatedSubtotal = cart.reduce((sum, item) => {
      return sum + (item.price * item.quantity);
    }, 0);
    
    // Save cart to localStorage
    localStorage.setItem(`cart-${tableId}`, JSON.stringify(cart));
    
    setSubtotal(calculatedSubtotal);
    
    const calculatedTax = calculatedSubtotal * 0.07; // 7% tax
    setTax(calculatedTax);
    
    const calculatedServiceCharge = applyServiceCharge 
      ? calculatedSubtotal * (serviceChargePercentage / 100)
      : 0;
    setServiceCharge(calculatedServiceCharge);
    
    const calculatedTotal = calculatedSubtotal + calculatedTax + calculatedServiceCharge;
    setTotal(calculatedTotal);
    
    console.log('Updated cart totals:', {
      calculatedSubtotal,
      calculatedTax,
      calculatedServiceCharge,
      calculatedTotal,
      currency,
      applyServiceCharge,
      serviceChargePercentage
    });
  }, [cart, applyServiceCharge, serviceChargePercentage, tableId, currency]);

  // Add item to cart
  const addToCart = (item: MenuItem) => {
    setCart(prevCart => {
      const existingItemIndex = prevCart.findIndex(cartItem => cartItem.id === item.id);
      
      if (existingItemIndex !== -1) {
        // Item already in cart, increment quantity
        const updatedCart = [...prevCart];
        updatedCart[existingItemIndex] = {
          ...updatedCart[existingItemIndex],
          quantity: updatedCart[existingItemIndex].quantity + 1
        };
        return updatedCart;
      } else {
        // Add new item to cart
        return [...prevCart, { ...item, quantity: 1 }];
      }
    });
    
    toast({
      title: "Added to cart",
      description: `${item.name} has been added to your cart.`,
    });
  };

  // Update item quantity - fixed to use direct quantity value instead of increment/decrement
  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    
    setCart(prevCart => 
      prevCart.map(item => 
        item.id === itemId 
          ? { ...item, quantity: newQuantity } 
          : item
      )
    );

    console.log(`Updating quantity for item ${itemId} to ${newQuantity}`);
  };

  // Remove item from cart
  const removeFromCart = (itemId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== itemId));
  };

  // Place order
  const placeOrder = async (customerName: string, customerPhone: string) => {
    try {
      if (!tableId || !table) {
        toast({
          title: "Error",
          description: "Table information is missing.",
          variant: "destructive",
        });
        return;
      }
      
      if (cart.length === 0) {
        toast({
          title: "Empty cart",
          description: "Please add items to your cart before placing an order.",
          variant: "destructive",
        });
        return;
      }
      
      if (!customerName.trim()) {
        toast({
          title: "Missing Information",
          description: "Please provide your name before placing an order",
          variant: "destructive",
        });
        return;
      }
      
      // Prevent multiple submissions
      if (isCreatingOrder) {
        console.log('Order creation already in progress');
        return;
      }
      
      setIsCreatingOrder(true);
      console.log('Creating order for table:', tableId, 'with items:', cart.length);
      
      // Create the order data object with only columns that exist in the DB
      const orderPayload = {
        table_id: tableId,
        restaurant_id: table.restaurant_id,
        total: total,
        items_count: cart.reduce((sum, item) => sum + item.quantity, 0),
        customer_name: customerName,
        customer_phone: customerPhone || null,
        status: 'Pending',
        payment_status: 'Unpaid'
      };

      // Only add service_charge if it exists and is greater than 0
      if (serviceCharge > 0) {
        orderPayload['service_charge'] = serviceCharge;
      }

      console.log('Order data being sent:', orderPayload);
      
      // First, create the order
      const { data: createdOrder, error: orderError } = await supabase
        .from('orders')
        .insert(orderPayload)
        .select()
        .single();
      
      if (orderError) {
        console.error('Error creating order:', orderError);
        throw new Error('Failed to create order: ' + orderError.message);
      }
      
      console.log('Order created successfully:', createdOrder);
      
      // Then, add order items
      const orderItems = cart.map(item => ({
        order_id: createdOrder.order_id,
        menu_item_id: item.id,
        quantity: item.quantity,
        price: item.price
      }));
      
      console.log('Inserting order items:', orderItems.length);
      
      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);
      
      if (itemsError) {
        console.error('Error adding order items:', itemsError);
        throw new Error('Failed to add order items: ' + itemsError.message);
      }
      
      console.log('Order items added successfully');
      
      // Fix: Ensure the table status is immediately updated to "Occupied"
      // and add more error handling and logging
      try {
        const { error: tableError, data: tableUpdateResult } = await supabase
          .from('tables')
          .update({ tb_status: 'Occupied' })
          .eq('tb_id', tableId)
          .select();
        
        if (tableError) {
          console.error('Error updating table status:', tableError);
          // Continue even if table status update fails
        } else {
          console.log('Table status updated to Occupied:', tableUpdateResult);
        }
      } catch (updateError) {
        console.error('Exception updating table status:', updateError);
      }
      
      // Save order to localStorage
      localStorage.setItem(`order-${tableId}`, JSON.stringify(createdOrder));
      
      // Update state
      setCurrentOrder(createdOrder);
      setCurrentOrderStatus('Pending');
      setCart([]);
      
      toast({
        title: "Order placed",
        description: "Your order has been successfully placed!",
      });
      
      return createdOrder;
    } catch (error: any) {
      console.error('Error placing order:', error);
      toast({
        title: "Failed to place order",
        description: error.message || "An error occurred while placing your order.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsCreatingOrder(false);
    }
  };

  // Reset order (start a new order)
  const resetOrder = () => {
    setCurrentOrder(null);
    setCurrentOrderStatus(null);
    setCart([]);
    localStorage.removeItem(`order-${tableId}`);
    localStorage.removeItem(`cart-${tableId}`);
  };

  // Fetch pending orders for this table
  const fetchPendingOrders = async (tableId: string) => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          order_items(*, menu_items(mi_name, mi_description))
        `)
        .eq('table_id', tableId)
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) {
        console.error('Error fetching pending orders:', error);
        return;
      }
      
      console.log('Pending orders loaded:', data.length);
      
      // Transform the data to match OrderWithItems type
      const transformedOrders = data.map(order => {
        return {
          ...order,
          items: (order.order_items || []).map(item => ({
            item_id: item.item_id,
            order_id: item.order_id,
            menu_item_id: item.menu_item_id,
            quantity: item.quantity,
            price: item.price,
            notes: item.notes || null,
            created_at: item.created_at,
            name: item.menu_items?.mi_name || 'Unknown Item', // Get name from joined menu_items
            description: item.menu_items?.mi_description
          }))
        };
      });
      
      setPendingOrders(transformedOrders);
    } catch (error) {
      console.error('Error in fetchPendingOrders:', error);
    }
  };

  return {
    table,
    loading,
    cart,
    currentOrderStatus,
    categories,
    menuItems,
    filteredItems,
    currentOrder,
    isMenuLoading,
    currentTab,
    setCurrentTab,
    subtotal,
    tax,
    serviceCharge,
    total,
    addToCart,
    updateQuantity,
    removeFromCart,
    placeOrder,
    resetOrder,
    pendingOrders,
    fetchPendingOrders,
    applyServiceCharge,
    serviceChargePercentage,
    isCreatingOrder
  };
};
