import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useCurrency } from '@/hooks/useCurrency';
import { calculateOrderTotals } from '@/utils/formatCurrency';
import { useAuth } from '@/contexts/AuthContext';

export const useServerOrder = () => {
  const [tables, setTables] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [filteredItems, setFilteredItems] = useState<any[]>([]);
  const [cart, setCart] = useState<any[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [currentTab, setCurrentTab] = useState<string>('all');
  const [currentOrderStatus, setCurrentOrderStatus] = useState<string | null>(null);
  const [currentOrder, setCurrentOrder] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isMenuLoading, setIsMenuLoading] = useState(true);
  const [isCreatingOrder, setIsCreatingOrder] = useState(false);
  
  const { profile } = useAuth();
  const { currency, applyServiceCharge, serviceChargePercentage } = useCurrency();

  useEffect(() => {
    const fetchTables = async () => {
      if (!profile?.restaurant_id) return;

      try {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('tables')
          .select('*')
          .eq('restaurant_id', profile.restaurant_id)
          .order('tb_name', { ascending: true });

        if (error) throw error;
        setTables(data || []);
      } catch (error) {
        console.error('Error fetching tables:', error);
        toast({
          title: 'Error',
          description: 'Failed to load tables',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchTables();
  }, [profile?.restaurant_id]);

  useEffect(() => {
    const fetchMenu = async () => {
      if (!profile?.restaurant_id) return;

      try {
        setIsMenuLoading(true);

        const { data: categoryData, error: categoryError } = await supabase
          .from('menu_categories')
          .select('*')
          .eq('restaurant_id', profile.restaurant_id)
          .order('mc_order');

        if (categoryError) throw categoryError;

        const { data: menuData, error: menuError } = await supabase
          .from('menu_items')
          .select(`
            mi_id,
            mi_name,
            mi_description,
            mi_price,
            mi_image_url,
            mi_category_id,
            mi_attributes,
            menu_categories:mi_category_id (mc_name)
          `)
          .eq('restaurant_id', profile.restaurant_id)
          .eq('mi_active', true)
          .eq('mi_in_stock', true);

        if (menuError) throw menuError;

        const formattedCategories = categoryData.map(cat => ({
          id: cat.mc_id,
          name: cat.mc_name
        }));

        const formattedItems = menuData.map(item => ({
          id: item.mi_id,
          name: item.mi_name,
          description: item.mi_description || '',
          price: item.mi_price,
          category: item.mi_category_id,
          categoryName: item.menu_categories?.mc_name || '',
          attributes: item.mi_attributes || {},
          image: item.mi_image_url || `https://placehold.co/300x200/e4e9f6/404e8f?text=${encodeURIComponent(item.mi_name)}`
        }));

        setCategories(formattedCategories);
        setMenuItems(formattedItems);
        setFilteredItems(formattedItems);
      } catch (error) {
        console.error('Error fetching menu:', error);
        toast({
          title: 'Error',
          description: 'Failed to load menu items',
          variant: 'destructive'
        });
      } finally {
        setIsMenuLoading(false);
      }
    };

    fetchMenu();
  }, [profile?.restaurant_id]);

  useEffect(() => {
    if (currentTab === 'all') {
      setFilteredItems(menuItems);
    } else {
      setFilteredItems(menuItems.filter(item => item.category === currentTab));
    }
  }, [currentTab, menuItems]);

  const addToCart = (item: any) => {
    const existingItem = cart.find(i => i.id === item.id);

    if (existingItem) {
      setCart(cart.map(i =>
        i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
      ));
    } else {
      setCart([...cart, {
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: 1
      }]);
    }
  };

  const updateQuantity = (id: string, change: number) => {
    const updatedCart = cart.map(item => {
      if (item.id === id) {
        const newQuantity = item.quantity + change;
        return newQuantity > 0 ? { ...item, quantity: newQuantity } : null;
      }
      return item;
    }).filter(Boolean);

    setCart(updatedCart);
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const taxPercentage = 8; // 8% tax rate
  
  const { tax, serviceCharge, total } = calculateOrderTotals(
    subtotal,
    taxPercentage,
    serviceChargePercentage,
    applyServiceCharge
  );

  const placeOrder = async () => {
    if (!selectedTable || cart.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please select a table and add items to the cart before placing an order",
        variant: "destructive",
      });
      return;
    }

    setIsCreatingOrder(true);

    try {
      console.log('Creating order for table:', selectedTable);
      
      const orderTotals = calculateOrderTotals(
        subtotal,
        taxPercentage,
        serviceChargePercentage,
        applyServiceCharge
      );

      if (!profile?.restaurant_id) {
        throw new Error("Restaurant ID is missing");
      }

      const orderPayload = {
        table_id: selectedTable,
        restaurant_id: profile.restaurant_id,
        status: 'Pending',
        total: orderTotals.total,
        items_count: cart.reduce((sum, item) => sum + item.quantity, 0),
        payment_status: 'Unpaid'
      };

      if (orderTotals.serviceCharge > 0) {
        orderPayload['service_charge'] = orderTotals.serviceCharge;
      }

      console.log('Order data being sent:', orderPayload);

      const { data: order, error } = await supabase
        .from('orders')
        .insert(orderPayload)
        .select()
        .single();

      if (error) {
        console.error('Error creating order:', error);
        throw new Error('Failed to create order record: ' + error.message);
      }
      
      console.log('Order created successfully:', order);

      const orderItems = cart.map(item => ({
        order_id: order.order_id,
        menu_item_id: item.id,
        quantity: item.quantity,
        price: item.price
      }));
      
      console.log('Creating order items:', orderItems.length);

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) {
        console.error('Error creating order items:', itemsError);
        throw new Error('Failed to create order items: ' + itemsError.message);
      }
      
      console.log('Order items created successfully');

      const { error: tableError } = await supabase
        .from('tables')
        .update({ tb_status: 'Occupied' })
        .eq('tb_id', selectedTable);

      if (tableError) {
        console.error('Error updating table status:', tableError);
        // Continue even if table update error
      } else {
        console.log('Table status updated to Occupied');
      }

      setCurrentOrderStatus('confirmed');
      setCurrentOrder(order);

      setTimeout(() => {
        setCurrentOrderStatus('preparing');
      }, 3000);

      toast({
        title: 'Order Created',
        description: `Order has been successfully created for Table ${tables.find(t => t.tb_id === selectedTable)?.tb_name}`
      });
      
      return order;
    } catch (error: any) {
      console.error('Error creating order:', error);
      toast({
        title: 'Order Failed',
        description: error.message || 'Failed to create order',
        variant: 'destructive'
      });
      return null;
    } finally {
      setIsCreatingOrder(false);
    }
  };

  const resetOrder = () => {
    setCart([]);
    setCurrentOrderStatus(null);
    setCurrentOrder(null);
  };

  return {
    tables,
    categories,
    menuItems,
    filteredItems,
    cart,
    selectedTable,
    currentTab,
    currentOrderStatus,
    currentOrder,
    isLoading,
    isMenuLoading,
    isCreatingOrder,
    subtotal,
    tax,
    serviceCharge,
    total,
    setSelectedTable,
    setCurrentTab,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    placeOrder,
    resetOrder,
    applyServiceCharge,
    serviceChargePercentage
  };
};
