
import { useState, useEffect, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useLocation } from 'react-router-dom';
import { isPublicRouteOrOrderPage } from '@/contexts/AuthContext';

interface Profile {
  pro_id: string;
  pro_first_name: string;
  pro_last_name: string;
  pro_role: string;
  restaurant_id: string | null;
  is_owner: boolean;
  pro_avatar_url: string | null;
}

// Helper function to save minimal session data for better persistence
const saveMinimalSessionData = (session: Session | null, rememberMe: boolean = false) => {
  if (!session) {
    localStorage.removeItem('auth.session.minimal');
    return;
  }
  
  const maxAge = rememberMe ? 7 * 24 * 60 * 60 : 24 * 60 * 60; // 7 days or 1 day in seconds
  const expiresAt = Math.floor(Date.now() / 1000) + maxAge;
  
  const minimalSession = {
    userId: session.user.id,
    email: session.user.email,
    expiresAt: expiresAt,
    refreshToken: session.refresh_token
  };
  
  localStorage.setItem('auth.session.minimal', JSON.stringify(minimalSession));
};

export function useAuthState() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authChecked, setAuthChecked] = useState(false);
  const location = useLocation();

  // Fetch user profile
  const fetchUserProfile = useCallback(async (userId: string) => {
    try {
      console.log('Fetching user profile for:', userId);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('pro_id', userId)
        .maybeSingle();
      
      if (error) {
        console.error('Error fetching profile:', error);
        return null;
      }
      
      return data;
    } catch (error) {
      console.error('Error in fetchUserProfile:', error);
      return null;
    }
  }, []);

  // Initialize authentication state
  useEffect(() => {
    // Check if current route is public
    const isPublicPath = isPublicRouteOrOrderPage(location.pathname);
    console.log('Initializing auth state. Current path:', location.pathname, 'Is public:', isPublicPath);

    // Always set a cleanup indicator to prevent state updates after unmount
    let isActive = true;

    // For public routes, we immediately set loading to false
    if (isPublicPath) {
      console.log('Public route detected, not blocking rendering');
      setLoading(false);
    }
    
    // Set up auth state listener first - THIS ORDER IS IMPORTANT
    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        console.log('Auth state changed:', event);
        
        if (!isActive) return; // Don't update state if component is unmounted
        
        if (newSession) {
          console.log('User logged in:', newSession.user?.email);
          setSession(newSession);
          setUser(newSession.user);
          
          // Save minimal session data for better persistence
          const rememberMe = localStorage.getItem('auth.rememberMe') === 'true';
          saveMinimalSessionData(newSession, rememberMe);
          
          // Use setTimeout to avoid potential deadlocks in auth state
          if (isActive) {
            setTimeout(() => {
              if (isActive) {
                fetchUserProfile(newSession.user.id).then(profileData => {
                  if (isActive) setProfile(profileData);
                  
                  // Set loading and authChecked after profile fetch is complete
                  if (isActive) {
                    setAuthChecked(true);
                    setLoading(false);
                  }
                });
              }
            }, 0);
          }
        } else {
          console.log('User logged out or no session');
          setSession(null);
          setUser(null);
          setProfile(null);
          localStorage.removeItem('auth.session.minimal');
          
          // Even without a session, we're done checking auth
          if (isActive) {
            setAuthChecked(true);
            setLoading(false);
          }
        }
      }
    );
    
    // Then check for existing session - with a timeout to prevent infinite loading
    const initAuth = async () => {
      try {
        // Set a timeout to prevent infinite loading
        const timeoutId = setTimeout(() => {
          if (isActive && loading) {
            console.log('Auth check timed out after 5 seconds, setting loading to false');
            setLoading(false);
            setAuthChecked(true);
          }
        }, 5000);
        
        // Get current session
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          if (isActive) {
            setLoading(false);
            setAuthChecked(true);
          }
          clearTimeout(timeoutId);
          return;
        }
        
        if (currentSession) {
          console.log('Session found:', currentSession.user?.email);
          if (isActive) {
            setSession(currentSession);
            setUser(currentSession.user);
            
            // Save minimal session data for better persistence
            const rememberMe = localStorage.getItem('auth.rememberMe') === 'true';
            saveMinimalSessionData(currentSession, rememberMe);
            
            // Fetch user profile
            const profileData = await fetchUserProfile(currentSession.user.id);
            if (isActive) {
              setProfile(profileData);
              setLoading(false);
              setAuthChecked(true);
            }
          }
        } else {
          // Try to recover from minimal session if no current session
          const minimalSessionStr = localStorage.getItem('auth.session.minimal');
          if (minimalSessionStr && isActive) {
            try {
              const minimalSession = JSON.parse(minimalSessionStr);
              const now = Math.floor(Date.now() / 1000);
              
              // If session isn't expired yet, try to refresh it
              if (minimalSession.expiresAt && minimalSession.expiresAt > now) {
                console.log('Found minimal session data, attempting to refresh session');
                
                // Do not await here - let the auth listener handle state updates
                if (minimalSession.refreshToken) {
                  supabase.auth.refreshSession({
                    refresh_token: minimalSession.refreshToken
                  }).catch(error => {
                    console.error('Error refreshing session:', error);
                    localStorage.removeItem('auth.session.minimal');
                    if (isActive) {
                      setLoading(false);
                      setAuthChecked(true);
                    }
                  });
                }
              } else {
                console.log('Minimal session is expired, clearing auth data');
                localStorage.removeItem('auth.session.minimal');
                if (isActive) {
                  setLoading(false);
                  setAuthChecked(true);
                }
              }
            } catch (e) {
              console.error('Error parsing minimal session data:', e);
              localStorage.removeItem('auth.session.minimal');
              if (isActive) {
                setLoading(false);
                setAuthChecked(true);
              }
            }
          } else {
            // No session at all, we're done checking
            if (isActive) {
              setLoading(false);
              setAuthChecked(true);
            }
          }
        }
        
        clearTimeout(timeoutId);
      } catch (error) {
        console.error('Error initializing auth:', error);
        if (isActive) {
          setLoading(false);
          setAuthChecked(true);
        }
      }
    };
    
    initAuth();
    
    // Cleanup function to prevent memory leaks and state updates after unmount
    return () => {
      console.log('Cleaning up auth state listener');
      isActive = false;
      authListener.subscription.unsubscribe();
    };
  }, [fetchUserProfile, location.pathname]);

  return { user, session, profile, loading, authChecked };
}
