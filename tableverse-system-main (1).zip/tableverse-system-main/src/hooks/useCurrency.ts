
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface CurrencySettings {
  currency: string;
  applyServiceCharge: boolean;
  serviceChargePercentage: number;
  applyTax: boolean;
  taxPercentage: number;
  inclusiveTax: boolean;
  isLoading: boolean;
}

export const useCurrency = (): CurrencySettings => {
  const { profile } = useAuth();
  const [currency, setCurrency] = useState('₹'); // Default to Rupee
  const [applyServiceCharge, setApplyServiceCharge] = useState(false);
  const [serviceChargePercentage, setServiceChargePercentage] = useState(0);
  const [applyTax, setApplyTax] = useState(false);
  const [taxPercentage, setTaxPercentage] = useState(0);
  const [inclusiveTax, setInclusiveTax] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(Date.now());

  const fetchSettings = useCallback(async (forceRefresh = false) => {
    setIsLoading(true);
    console.log('useCurrency: Starting to fetch currency settings' + (forceRefresh ? ' (forced)' : ''));
    
    // Try to get restaurant ID either from profile or from localStorage
    let restaurantId = profile?.restaurant_id;
    
    console.log('useCurrency: Initial profile restaurant ID:', restaurantId);
    
    // If we're on the customer order page, we might not have a profile
    // Try to extract restaurant ID from the URL if available (for customer order page)
    if (!restaurantId) {
      try {
        // Extract table ID from URL if available
        const pathSegments = window.location.pathname.split('/');
        const tableIdIndex = pathSegments.findIndex(segment => segment === 'order') + 1;
        const tableId = tableIdIndex > 0 && tableIdIndex < pathSegments.length ? 
          pathSegments[tableIdIndex] : null;
          
        if (tableId) {
          console.log('useCurrency: Found table ID in URL:', tableId);
          // Get restaurant ID from table data
          const { data: tableData } = await supabase
            .from('tables')
            .select('restaurant_id')
            .eq('tb_id', tableId)
            .maybeSingle();
            
          if (tableData?.restaurant_id) {
            restaurantId = tableData.restaurant_id;
            console.log('useCurrency: Retrieved restaurant ID from table:', restaurantId);
          }
        }
      } catch (error) {
        console.error('Error trying to get restaurant ID:', error);
      }
    }
    
    // Try to find restaurant ID in localStorage as a last resort
    if (!restaurantId) {
      const localStorageKeys = Object.keys(localStorage);
      const orderKey = localStorageKeys.find(key => key.startsWith('order-'));
      if (orderKey) {
        try {
          const orderData = JSON.parse(localStorage.getItem(orderKey) || '{}');
          if (orderData.restaurant_id) {
            restaurantId = orderData.restaurant_id;
            console.log('useCurrency: Retrieved restaurant ID from localStorage:', restaurantId);
          }
        } catch (error) {
          console.error('Error parsing order data from localStorage:', error);
        }
      }
    }
    
    // Default to first restaurant in the database if still not found
    if (!restaurantId) {
      try {
        const { data: firstRestaurant } = await supabase
          .from('restaurants')
          .select('restaurant_id')
          .limit(1)
          .single();
          
        if (firstRestaurant?.restaurant_id) {
          restaurantId = firstRestaurant.restaurant_id;
          console.log('useCurrency: Using first restaurant in database as fallback:', restaurantId);
        }
      } catch (error) {
        console.error('Error getting fallback restaurant:', error);
      }
    }
    
    if (!restaurantId) {
      console.warn('useCurrency: No restaurant ID available to fetch currency settings, using default ₹');
      setCurrency('₹'); // Default to Rupee if no restaurant found
      setIsLoading(false);
      return;
    }
    
    try {
      console.log('useCurrency: Fetching currency settings for restaurant:', restaurantId);
      
      // Fetch currency setting
      const { data: currencyData, error: currencyError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'currency')
        .maybeSingle();
      
      if (!currencyError && currencyData?.setting_value) {
        console.log('useCurrency: Currency set to:', currencyData.setting_value);
        setCurrency(currencyData.setting_value);
      } else if (currencyError) {
        console.error('useCurrency: Error fetching currency setting:', currencyError);
        setCurrency('₹'); // Default to Rupee if error
      } else {
        console.log('useCurrency: No custom currency found, using default ₹');
        setCurrency('₹'); // Default to Rupee if no setting
      }
      
      // Fetch service charge toggle setting
      const { data: serviceChargeData, error: serviceChargeError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'service_charge_enabled')
        .maybeSingle();
      
      if (!serviceChargeError && serviceChargeData?.setting_value) {
        setApplyServiceCharge(serviceChargeData.setting_value === 'true');
        console.log('useCurrency: Service charge enabled:', serviceChargeData.setting_value === 'true');
      }
      
      // Fetch service charge percentage setting
      const { data: serviceChargePercentageData, error: serviceChargePercentageError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'service_charge_percentage')
        .maybeSingle();
      
      if (!serviceChargePercentageError && serviceChargePercentageData?.setting_value) {
        setServiceChargePercentage(parseFloat(serviceChargePercentageData.setting_value));
        console.log('useCurrency: Service charge percentage:', parseFloat(serviceChargePercentageData.setting_value));
      }
      
      // Fetch tax toggle setting
      const { data: taxEnabledData, error: taxEnabledError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'tax_enabled')
        .maybeSingle();
      
      if (!taxEnabledError && taxEnabledData?.setting_value) {
        setApplyTax(taxEnabledData.setting_value === 'true');
        console.log('useCurrency: Tax enabled:', taxEnabledData.setting_value === 'true');
      }
      
      // Fetch tax percentage setting
      const { data: taxPercentageData, error: taxPercentageError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'tax_percentage')
        .maybeSingle();
      
      if (!taxPercentageError && taxPercentageData?.setting_value) {
        setTaxPercentage(parseFloat(taxPercentageData.setting_value));
        console.log('useCurrency: Tax percentage:', parseFloat(taxPercentageData.setting_value));
      }
      
      // Fetch inclusive tax setting
      const { data: inclusiveTaxData, error: inclusiveTaxError } = await supabase
        .from('settings')
        .select('setting_value')
        .eq('restaurant_id', restaurantId)
        .eq('setting_key', 'inclusive_tax')
        .maybeSingle();
      
      if (!inclusiveTaxError && inclusiveTaxData?.setting_value) {
        setInclusiveTax(inclusiveTaxData.setting_value === 'true');
        console.log('useCurrency: Inclusive tax:', inclusiveTaxData.setting_value === 'true');
      }
    } catch (error) {
      console.error('useCurrency: Error fetching settings:', error);
      setCurrency('₹'); // Default to Rupee if error
    } finally {
      setIsLoading(false);
    }
  }, [profile?.restaurant_id]);
  
  useEffect(() => {
    fetchSettings();
    
    // Set up an event listener for manual refreshes
    const handleCurrencyUpdate = () => {
      console.log('Currency update event received, refreshing settings');
      fetchSettings(true);
      setLastRefresh(Date.now()); // Update last refresh timestamp to trigger re-renders
    };
    
    window.addEventListener('refresh-currency', handleCurrencyUpdate);
    
    // Setup a polling mechanism to periodically check for currency updates
    const intervalId = setInterval(() => {
      console.log('Periodic currency refresh check');
      fetchSettings(true);
    }, 60000); // Check every minute
    
    return () => {
      window.removeEventListener('refresh-currency', handleCurrencyUpdate);
      clearInterval(intervalId);
    };
  }, [fetchSettings]);

  // Add a subscription to settings changes if profile and restaurant ID are available
  useEffect(() => {
    if (!profile?.restaurant_id) return;
    
    // Set up a realtime subscription to settings changes
    const settingsSubscription = supabase
      .channel('settings-changes')
      .on('postgres_changes', 
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'settings',
          filter: `restaurant_id=eq.${profile.restaurant_id}`
        }, 
        (payload) => {
          console.log('Settings changed:', payload);
          // Refresh settings when any setting changes
          fetchSettings(true);
          setLastRefresh(Date.now()); // Trigger re-renders
        }
      )
      .subscribe();
      
    return () => {
      settingsSubscription.unsubscribe();
    };
  }, [profile?.restaurant_id, fetchSettings]);

  // Log the current currency when it changes or on initial load
  useEffect(() => {
    console.log('useCurrency: Current currency value being used:', currency, 'Last refreshed:', new Date(lastRefresh).toISOString());
  }, [currency, lastRefresh]);

  return { 
    currency, 
    applyServiceCharge, 
    serviceChargePercentage, 
    applyTax,
    taxPercentage,
    inclusiveTax,
    isLoading 
  };
};
