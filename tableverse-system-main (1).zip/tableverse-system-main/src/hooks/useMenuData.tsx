
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { MenuItem, Category } from '@/types/tables';
import { useAuth } from '@/contexts/AuthContext';

export const useMenuData = () => {
  const { profile } = useAuth();
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredItems, setFilteredItems] = useState<MenuItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const fetchMenuItems = async () => {
    try {
      setIsLoading(true);
      
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID is missing. Please set up your restaurant first.',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }
      
      const { data, error } = await supabase
        .from('menu_items')
        .select(`
          mi_id,
          mi_name,
          mi_description,
          mi_price,
          mi_image_url,
          mi_category_id,
          mi_in_stock,
          mi_attributes,
          mi_variations,
          menu_categories(mc_id, mc_name)
        `)
        .eq('restaurant_id', profile.restaurant_id)
        .order('mi_name');

      if (error) throw error;
      
      const transformedData: MenuItem[] = data.map(item => {
        // Safely cast attributes
        let attributes = {};
        if (item.mi_attributes) {
          try {
            attributes = item.mi_attributes as any;
          } catch (e) {
            console.error('Error parsing attributes:', e);
          }
        }
        
        // Safely cast variations
        let variations = [];
        if (item.mi_variations) {
          try {
            // If mi_variations is already an array, map it to ensure it has the right structure
            if (Array.isArray(item.mi_variations)) {
              variations = item.mi_variations.map(variation => ({
                size: (variation as any).size || '',
                price: (variation as any).price || '0'
              }));
            }
          } catch (e) {
            console.error('Error parsing variations:', e);
          }
        }
        
        return {
          id: item.mi_id,
          name: item.mi_name,
          description: item.mi_description,
          price: item.mi_price,
          imageUrl: item.mi_image_url,
          categoryId: item.mi_category_id,
          categoryName: item.menu_categories ? item.menu_categories.mc_name : null,
          inStock: item.mi_in_stock !== false,
          attributes,
          variations
        };
      });
      
      setMenuItems(transformedData);
      setFilteredItems(transformedData);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to load menu items: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID is missing. Please set up your restaurant first.',
          variant: 'destructive',
        });
        return;
      }
      
      const { data, error } = await supabase
        .from('menu_categories')
        .select('mc_id, mc_name, mc_description, mc_order')
        .eq('restaurant_id', profile.restaurant_id)
        .order('mc_order', { ascending: true })
        .order('mc_name');
      
      if (error) throw error;
      
      const transformedCategories: Category[] = data.map(category => ({
        id: category.mc_id,
        name: category.mc_name,
        description: category.mc_description,
        order: category.mc_order || 0
      }));
      
      setCategories(transformedCategories);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to load categories: ' + error.message,
        variant: 'destructive',
      });
    }
  };

  const updateCategoriesOrder = async (updatedCategories: Category[]) => {
    try {
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID is missing. Please set up your restaurant first.',
          variant: 'destructive',
        });
        return;
      }

      // Create batch update data with ALL required fields
      const updates = updatedCategories.map((category) => ({
        mc_id: category.id,
        mc_name: category.name,
        mc_description: category.description,
        mc_order: category.order,
        restaurant_id: profile.restaurant_id
      }));
      
      const { error } = await supabase
        .from('menu_categories')
        .upsert(updates, { onConflict: 'mc_id' });
      
      if (error) throw error;
      
      // Update local state
      setCategories(updatedCategories);
      
      toast({
        title: 'Success',
        description: 'Category order has been updated',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update category order: ' + error.message,
        variant: 'destructive',
      });
    }
  };

  // Filter items based on search query and selected category
  useEffect(() => {
    let filtered = menuItems;
    
    if (searchQuery.trim() !== '') {
      filtered = filtered.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item => 
        selectedCategory === 'uncategorized' 
          ? item.categoryId === null 
          : item.categoryId === selectedCategory
      );
    }
    
    setFilteredItems(filtered);
  }, [searchQuery, selectedCategory, menuItems]);

  // Initial data loading
  useEffect(() => {
    if (profile?.restaurant_id) {
      fetchMenuItems();
      fetchCategories();
    }
  }, [profile?.restaurant_id]);

  return {
    menuItems,
    categories,
    filteredItems,
    isLoading,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    fetchMenuItems,
    fetchCategories,
    updateCategoriesOrder
  };
};
