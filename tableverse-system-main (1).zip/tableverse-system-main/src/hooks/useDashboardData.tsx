
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

export interface DashboardStats {
  totalRevenue: number;
  totalOrders: number;
  averageOrderValue: number;
  activeTables: {
    active: number;
    total: number;
  };
  revenueData: {
    name: string;
    revenue: number;
  }[];
  dailyOrdersData: {
    name: string;
    orders: number;
  }[];
  categoryData: {
    name: string;
    value: number;
  }[];
  performanceData: {
    name: string;
    performance: number;
  }[];
  recentActivity: {
    id: string;
    type: 'order' | 'menu';
    title: string;
    description: string;
    timestamp: Date;
  }[];
}

export const useDashboardData = () => {
  const { profile } = useAuth();
  const { currency } = useCurrency();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dashboardData, setDashboardData] = useState<DashboardStats>({
    totalRevenue: 0,
    totalOrders: 0,
    averageOrderValue: 0,
    activeTables: { active: 0, total: 0 },
    revenueData: [],
    dailyOrdersData: [],
    categoryData: [],
    performanceData: [],
    recentActivity: []
  });

  const fetchDashboardData = async () => {
    if (!profile?.restaurant_id) {
      setError('Restaurant ID is missing');
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Fetch total revenue and orders count
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('total, created_at')
        .eq('restaurant_id', profile.restaurant_id);

      if (ordersError) throw ordersError;

      // Calculate total revenue
      const totalRevenue = ordersData.reduce((sum, order) => sum + Number(order.total), 0);
      const totalOrders = ordersData.length;
      const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

      // Fetch active tables
      const { data: tablesData, error: tablesError } = await supabase
        .from('tables')
        .select('tb_id, tb_status')
        .eq('restaurant_id', profile.restaurant_id);

      if (tablesError) throw tablesError;

      const activeTables = {
        active: tablesData.filter(table => table.tb_status !== 'Available').length,
        total: tablesData.length
      };

      // Generate revenue data by month
      const revenueByMonth = generateRevenueByMonth(ordersData);
      
      // Generate daily orders data
      const dailyOrders = generateDailyOrdersData(ordersData);
      
      // Fetch menu categories for category data
      const { data: orderItems, error: orderItemsError } = await supabase
        .from('order_items')
        .select(`
          menu_items:menu_item_id (
            mi_category_id,
            menu_categories:mi_category_id (mc_name)
          )
        `)
        .eq('menu_items.restaurant_id', profile.restaurant_id);

      if (orderItemsError) throw orderItemsError;

      // Count orders by category
      const categoryData = generateCategoryData(orderItems);
      
      // Generate table performance data
      const performanceData = generateTablePerformanceData(tablesData, ordersData);
      
      // Fetch recent activity
      const recentActivity = await fetchRecentActivity(profile.restaurant_id);

      setDashboardData({
        totalRevenue,
        totalOrders,
        averageOrderValue,
        activeTables,
        revenueData: revenueByMonth,
        dailyOrdersData: dailyOrders,
        categoryData,
        performanceData,
        recentActivity
      });
    } catch (error: any) {
      console.error('Error fetching dashboard data:', error);
      setError(error.message);
      toast({
        title: 'Error',
        description: 'Failed to load dashboard data',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  // Helper function to generate revenue by month
  const generateRevenueByMonth = (orders: any[]) => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentYear = new Date().getFullYear();
    
    // Initialize revenue data with all months
    const revenueData = months.map(month => ({ name: month, revenue: 0 }));
    
    // Fill in actual revenue data
    orders.forEach(order => {
      const orderDate = new Date(order.created_at);
      if (orderDate.getFullYear() === currentYear) {
        const monthIndex = orderDate.getMonth();
        revenueData[monthIndex].revenue += Number(order.total);
      }
    });
    
    return revenueData;
  };

  // Helper function to generate daily orders data
  const generateDailyOrdersData = (orders: any[]) => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    // Initialize daily orders with all days
    const dailyOrders = days.map(day => ({ name: day, orders: 0 }));
    
    // Get orders from the past week
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    // Fill in actual orders data
    orders.forEach(order => {
      const orderDate = new Date(order.created_at);
      if (orderDate >= oneWeekAgo) {
        // JavaScript getDay() returns 0 for Sunday, we need 0 for Monday
        let dayIndex = orderDate.getDay() - 1;
        if (dayIndex === -1) dayIndex = 6; // Sunday becomes index 6
        dailyOrders[dayIndex].orders += 1;
      }
    });
    
    return dailyOrders;
  };

  // Helper function to generate category data
  const generateCategoryData = (orderItems: any[]) => {
    const categoryCounts: Record<string, number> = {};
    let totalItems = 0;
    
    // Count items by category
    orderItems.forEach(item => {
      if (item.menu_items?.menu_categories?.mc_name) {
        const categoryName = item.menu_items.menu_categories.mc_name;
        categoryCounts[categoryName] = (categoryCounts[categoryName] || 0) + 1;
        totalItems++;
      }
    });
    
    // Convert to percentage and format for chart
    return Object.entries(categoryCounts)
      .map(([name, count]) => ({
        name,
        value: Math.round((count / totalItems) * 100) || 0
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 4); // Get top 4 categories
  };

  // Helper function to generate table performance data
  const generateTablePerformanceData = (tables: any[], orders: any[]) => {
    // Create a map of table ID to order count
    const tableOrderCounts: Record<string, number> = {};
    
    // Count orders by table
    orders.forEach(order => {
      if (order.table_id) {
        tableOrderCounts[order.table_id] = (tableOrderCounts[order.table_id] || 0) + 1;
      }
    });
    
    // Find the max order count for normalization
    const maxOrders = Math.max(...Object.values(tableOrderCounts), 1);
    
    // Create performance data (normalize to 0-100%)
    return tables
      .filter((table, index) => index < 6) // Limit to 6 tables
      .map(table => {
        const orderCount = tableOrderCounts[table.tb_id] || 0;
        // Calculate performance as percentage of max orders
        const performance = Math.round((orderCount / maxOrders) * 100);
        return {
          name: table.tb_name || `Table ${table.tb_id.slice(0, 4)}`,
          performance
        };
      });
  };

  // Helper function to fetch recent activity
  const fetchRecentActivity = async (restaurantId: string) => {
    // Fetch latest orders
    const { data: recentOrders, error: ordersError } = await supabase
      .from('orders')
      .select('order_id, created_at, table_id, status, total, tables:table_id (tb_name)')
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: false })
      .limit(5);

    if (ordersError) throw ordersError;

    // Fetch latest menu updates
    const { data: recentMenuUpdates, error: menuError } = await supabase
      .from('menu_items')
      .select('mi_id, mi_name, mi_updated_at, mi_price')
      .eq('restaurant_id', restaurantId)
      .order('mi_updated_at', { ascending: false })
      .limit(5);

    if (menuError) throw menuError;

    // Combine and sort activity
    const activity = [
      ...recentOrders.map(order => ({
        id: order.order_id,
        type: 'order' as const,
        title: 'New order received',
        description: `Order #${order.order_id ? order.order_id.slice(-4) : 'Unknown'} for ${
          order.tables?.tb_name || (order.table_id ? `Table #${order.table_id.slice(-4)}` : 'Walk-in')
        }`,
        timestamp: new Date(order.created_at)
      })),
      ...recentMenuUpdates.map(item => ({
        id: item.mi_id,
        type: 'menu' as const,
        title: 'Menu item updated',
        description: `Updated price for ${item.mi_name || 'Unknown item'}`,
        timestamp: new Date(item.mi_updated_at)
      }))
    ];

    // Sort by timestamp, most recent first
    return activity
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, 5);
  };

  useEffect(() => {
    if (profile?.restaurant_id) {
      fetchDashboardData();
    }
  }, [profile?.restaurant_id]);

  return {
    dashboardData,
    loading,
    error,
    refetchDashboardData: fetchDashboardData,
    currency
  };
};
