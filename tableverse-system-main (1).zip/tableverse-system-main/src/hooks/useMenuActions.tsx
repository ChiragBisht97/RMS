
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { MenuItem, Category } from '@/types/tables';
import { useAuth } from '@/contexts/AuthContext';

export const useMenuActions = (
  onSuccess: () => void
) => {
  const { profile } = useAuth();
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [selectedCategoryForEdit, setSelectedCategoryForEdit] = useState<Category | null>(null);
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<MenuItem | null>(null);
  const [categoryDeleteDialogOpen, setCategoryDeleteDialogOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleAddItem = () => {
    setSelectedItem(null);
    setItemDialogOpen(true);
  };

  const handleEditItem = (item: MenuItem) => {
    setSelectedItem({
      ...item,
      description: item.description || ''
    });
    setItemDialogOpen(true);
  };

  const handleAddCategory = () => {
    setSelectedCategoryForEdit(null);
    setCategoryDialogOpen(true);
  };

  const handleEditCategory = (category: Category) => {
    setSelectedCategoryForEdit({
      ...category,
      description: category.description || ''
    });
    setCategoryDialogOpen(true);
  };

  const confirmDeleteItem = (item: MenuItem) => {
    setItemToDelete(item);
    setDeleteDialogOpen(true);
  };

  const toggleStockStatus = async (item: MenuItem) => {
    if (!profile?.restaurant_id) return;
    
    try {
      const newStockStatus = !item.inStock;
      
      const { error } = await supabase
        .from('menu_items')
        .update({ 
          mi_in_stock: newStockStatus,
          mi_updated_at: new Date().toISOString()
        })
        .eq('mi_id', item.id)
        .eq('restaurant_id', profile.restaurant_id);
      
      if (error) throw error;
      
      toast({
        title: newStockStatus ? 'Item is now in stock' : 'Item is now out of stock',
        description: `${item.name} has been updated successfully.`,
        variant: newStockStatus ? 'default' : 'destructive',
      });
      
      onSuccess();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update stock status: ' + error.message,
        variant: 'destructive',
      });
    }
  };

  const handleDeleteItem = async () => {
    if (!itemToDelete || !profile?.restaurant_id) return;
    
    try {
      const { error } = await supabase
        .from('menu_items')
        .delete()
        .eq('mi_id', itemToDelete.id)
        .eq('restaurant_id', profile.restaurant_id);
      
      if (error) throw error;
      
      toast({
        title: 'Item deleted',
        description: 'The menu item has been deleted successfully.'
      });
      
      onSuccess();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to delete item: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setDeleteDialogOpen(false);
      setItemToDelete(null);
    }
  };

  const confirmDeleteCategory = (category: Category) => {
    setCategoryToDelete(category);
    setCategoryDeleteDialogOpen(true);
  };

  const handleDeleteCategory = async () => {
    if (!categoryToDelete || !profile?.restaurant_id) return;
    
    try {
      setIsDeleting(true);
      
      // First, update any menu items in this category to have no category (uncategorized)
      const { error: updateError } = await supabase
        .from('menu_items')
        .update({ 
          mi_category_id: null,
          mi_updated_at: new Date().toISOString()
        })
        .eq('mi_category_id', categoryToDelete.id)
        .eq('restaurant_id', profile.restaurant_id);
      
      if (updateError) throw updateError;
      
      // Then delete the category
      const { error } = await supabase
        .from('menu_categories')
        .delete()
        .eq('mc_id', categoryToDelete.id)
        .eq('restaurant_id', profile.restaurant_id);
      
      if (error) throw error;
      
      toast({
        title: 'Category deleted',
        description: 'The category has been deleted successfully.'
      });
      
      // Call onSuccess to refresh data
      onSuccess();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to delete category: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      // IMPORTANT: Clean up state properly to prevent UI freeze
      setCategoryDeleteDialogOpen(false);
      setCategoryToDelete(null);
      setIsDeleting(false);
    }
  };

  return {
    selectedItem,
    selectedCategoryForEdit,
    categoryDialogOpen,
    setCategoryDialogOpen,
    itemDialogOpen,
    setItemDialogOpen,
    deleteDialogOpen,
    setDeleteDialogOpen,
    itemToDelete,
    categoryDeleteDialogOpen,
    setCategoryDeleteDialogOpen,
    categoryToDelete,
    handleAddItem,
    handleEditItem,
    handleAddCategory,
    handleEditCategory,
    confirmDeleteItem,
    handleDeleteItem,
    confirmDeleteCategory,
    handleDeleteCategory,
    toggleStockStatus,
    isDeleting,
  };
};
