import React, { useState, useEffect, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/dashboard/Dashboard";
import Menus from "./pages/dashboard/Menus";
import Orders from "./pages/dashboard/Orders";
import Tables from "./pages/dashboard/Tables";
import POS from "./pages/dashboard/POS";
import Users from "./pages/dashboard/Users";
import CustomerOrder from "./pages/dashboard/CustomerOrder";
import OrderPage from "./pages/OrderPage";
import DashboardLayout from "./components/layout/DashboardLayout";
import NotFound from "./pages/NotFound";
import { AuthProvider, useAuth, isPublicRouteOrOrderPage } from "./contexts/AuthContext";
import RestaurantDialog from "./components/restaurant/RestaurantDialog";
import Index from "./pages/Index";
import PricingPage from "./pages/PricingPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import Settings from "./pages/dashboard/Settings";
import Reports from "./pages/dashboard/Reports";
import { SidebarProvider } from "./hooks/useSidebarState";
import UserManagement from "./pages/dashboard/UserManagement";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      refetchOnWindowFocus: true, // Enable refetching on window focus to keep data fresh
      retry: 1, // Reduce retry attempts to prevent infinite loading
      retryDelay: 1000, // Add a slight delay between retries
    },
  },
});

function BasePath() {
  useEffect(() => {
    console.log("Current URL path:", window.location.pathname);
  }, []);
  
  return null;
}

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading, authChecked, profile } = useAuth();
  const [timeoutReached, setTimeoutReached] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  useEffect(() => {
    let timer: number | undefined;
    
    if (loading && !timeoutReached) {
      timer = window.setTimeout(() => {
        console.log('Authentication timeout reached after 8s, proceeding to login');
        setTimeoutReached(true);
      }, 8000);
    }
    
    return () => {
      if (timer) window.clearTimeout(timer);
    };
  }, [loading, timeoutReached]);
  
  useEffect(() => {
    console.log("Protected route - Auth state:", { 
      user: user?.email, 
      loading, 
      timeoutReached,
      authChecked,
      profile: !!profile,
      path: location.pathname
    });
    
    const isPublic = isPublicRouteOrOrderPage(location.pathname);
    
    if (!isPublic && (authChecked || timeoutReached) && !user) {
      console.log("No authenticated user, redirecting to login");
      navigate('/login', { replace: true, state: { from: location } });
    }
  }, [user, loading, timeoutReached, authChecked, profile, navigate, location]);
  
  if (loading && !timeoutReached && !authChecked && !isPublicRouteOrOrderPage(location.pathname)) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
        <p className="ml-3 text-lg">Verifying authentication...</p>
      </div>
    );
  }
  
  if (timeoutReached && !user && !isPublicRouteOrOrderPage(location.pathname)) {
    console.log("Timeout reached and no user, redirecting to login");
    navigate('/login', { replace: true });
    return null;
  }
  
  return (
    <>
      {children}
      <RestaurantDialog />
    </>
  );
};

function AppContent() {
  const location = useLocation();
  
  useEffect(() => {
    console.log("App component mounted - checking initialization");
    console.log("Current URL:", window.location.href);
    console.log("Base URL Path:", location.pathname);
    
    const hasAuthData = localStorage.getItem('supabase.auth.token') || 
                        localStorage.getItem('auth.timestamp');
    console.log("Has auth data in localStorage:", !!hasAuthData);
  }, [location]);

  return (
    <>
      <BasePath />
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/landing" element={<LandingPage />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/order/:tableId" element={<OrderPage />} />
          
          <Route path="/login" element={<LoginPage />} />
          <Route path="/auth/invite" element={<LoginPage />} />
          
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }>
            <Route index element={<Dashboard />} />
            <Route path="menus" element={<Menus />} />
            <Route path="orders" element={<Orders />} />
            <Route path="tables" element={<Tables />} />
            <Route path="pos" element={<POS />} />
            <Route path="users" element={<Users />} />
            <Route path="customer-order" element={<CustomerOrder />} />
            <Route path="settings" element={<Settings />} />
            <Route path="reports" element={<Reports />} />
            <Route path="user-management" element={<UserManagement />} />
          </Route>
          <Route path="/dashboard/*" element={
            <ProtectedRoute>
              <Navigate to="/dashboard" replace />
            </ProtectedRoute>
          } />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </TooltipProvider>
    </>
  );
}

function App() {
  useEffect(() => {
    const clearConflictingAuth = () => {
      const hasSupabaseToken = !!localStorage.getItem('sb-manbzlnzgpexyzsuvfek-auth-token');
      const hasCustomToken = !!localStorage.getItem('auth.session.minimal');
      
      if (hasSupabaseToken !== hasCustomToken) {
        console.log('Detected auth token conflict, clearing auth data on App mount');
        localStorage.removeItem('sb-manbzlnzgpexyzsuvfek-auth-token');
        localStorage.removeItem('auth.session.minimal');
      }
    };
    
    clearConflictingAuth();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthProvider>
          <SidebarProvider>
            <AppContent />
          </SidebarProvider>
        </AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
