import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Store } from 'lucide-react';
import { useCustomerOrder } from '@/hooks/useCustomerOrder';
import { toast } from '@/hooks/use-toast';
import { useCurrency } from '@/hooks/useCurrency';

// Components
import MenuCategories from '@/components/customer-order/MenuCategories';
import MenuList from '@/components/customer-order/MenuList';
import CartSummary from '@/components/customer-order/CartSummary';
import OrderStatus from '@/components/customer-order/OrderStatus';
import CustomerInfoForm from '@/components/customer-order/CustomerInfoForm';
import PendingOrdersView from '@/components/customer-order/PendingOrdersView';
import FloatingCartButton from '@/components/customer-order/FloatingCartButton';

const OrderPage = () => {
  const { tableId } = useParams<{ tableId: string }>();
  const [showPendingOrders, setShowPendingOrders] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    phone: ''
  });
  
  const { currency } = useCurrency();
  
  useEffect(() => {
    console.log("OrderPage mounted with tableId:", tableId);
    console.log("OrderPage - Currency from useCurrency:", currency);
    
    // Force a currency refresh when the page loads
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('refresh-currency'));
      console.log("Triggered currency refresh event");
    }, 500);
    
    return () => {
      console.log("OrderPage unmounted");
    };
  }, [tableId, currency]);
  
  const {
    table,
    loading,
    cart,
    currentOrderStatus,
    categories,
    menuItems,
    filteredItems,
    currentOrder,
    isMenuLoading,
    currentTab,
    setCurrentTab,
    subtotal,
    tax,
    serviceCharge,
    total,
    addToCart,
    updateQuantity,
    removeFromCart,
    placeOrder,
    resetOrder,
    pendingOrders,
    fetchPendingOrders,
    applyServiceCharge,
    serviceChargePercentage,
    isCreatingOrder
  } = useCustomerOrder(tableId);

  useEffect(() => {
    console.log("OrderPage - Table data:", !!table);
    console.log("OrderPage - Loading state:", loading);
    console.log("OrderPage - Categories count:", categories?.length);
    console.log("OrderPage - Menu items count:", menuItems?.length);
    console.log("OrderPage - Currency settings loaded:", {
      currency,
      applyServiceCharge,
      serviceChargePercentage
    });
  }, [table, loading, categories, menuItems, applyServiceCharge, serviceChargePercentage, currency]);

  const handleCustomerInfoChange = (name: string, value: string) => {
    setCustomerInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePlaceOrder = async () => {
    if (!customerInfo.name.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide your name before placing an order",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const result = await placeOrder(customerInfo.name, customerInfo.phone);
      
      if (result) {
        console.log('Order placed successfully:', result);
      }
    } catch (error) {
      console.error('Error in handlePlaceOrder:', error);
    }
  };

  const togglePendingOrders = () => {
    setShowPendingOrders(!showPendingOrders);
    if (!showPendingOrders && tableId) {
      console.log("Fetching pending orders for table:", tableId);
      fetchPendingOrders(tableId);
    }
  };

  const scrollToCart = () => {
    document.getElementById('cart-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        <p className="ml-3 text-lg font-medium">Loading table information...</p>
      </div>
    );
  }

  if (!table) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen p-4">
        <Store className="h-16 w-16 text-muted-foreground mb-4" />
        <h1 className="text-2xl font-bold mb-2">Table Not Found</h1>
        <p className="text-muted-foreground text-center mb-6">
          The table you're looking for doesn't exist or the QR code is invalid.
        </p>
        <Button onClick={() => window.location.reload()}>
          Try Again
        </Button>
      </div>
    );
  }

  const showAllItems = currentTab === 'all-items';
  
  const totalItemsInCart = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 animate-fade-in pb-20">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-display font-bold tracking-tight">{table.tb_name}</h1>
        <p className="text-muted-foreground">Place your order directly from your table</p>
        
        <div className="mt-4">
          <Button 
            variant="outline" 
            onClick={togglePendingOrders}
            className="mx-2"
          >
            {showPendingOrders ? "Back to Menu" : "View My Orders"}
          </Button>
        </div>
      </div>
      
      {showPendingOrders ? (
        <PendingOrdersView 
          orders={pendingOrders} 
          onBack={() => setShowPendingOrders(false)}
        />
      ) : currentOrderStatus ? (
        <OrderStatus 
          status={currentOrderStatus}
          orderId={currentOrder?.order_id}
          paymentStatus={currentOrder?.payment_status}
          onNewOrder={resetOrder}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {isMenuLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : categories.length > 0 ? (
              <>
                <MenuCategories 
                  categories={categories}
                  currentTab={currentTab}
                  onTabChange={setCurrentTab}
                  showAllItemsOption={true}
                />
                
                <div className="mt-6">
                  <MenuList 
                    items={showAllItems ? menuItems : filteredItems}
                    onAddToCart={addToCart}
                    showAllItems={showAllItems}
                  />
                </div>
              </>
            ) : (
              <div className="text-center py-12 border rounded-lg">
                <p className="text-muted-foreground">No menu categories found.</p>
              </div>
            )}
          </div>
          
          <div id="cart-section">
            <CustomerInfoForm 
              customerName={customerInfo.name}
              customerPhone={customerInfo.phone}
              onChange={handleCustomerInfoChange}
            />
            
            <CartSummary 
              cart={cart}
              tableName={table.tb_name}
              subtotal={subtotal}
              tax={tax}
              total={total}
              onUpdateQuantity={updateQuantity}
              onRemoveItem={removeFromCart}
              onPlaceOrder={handlePlaceOrder}
              onResetOrder={currentOrder ? resetOrder : undefined}
              applyServiceCharge={applyServiceCharge}
              serviceChargePercentage={serviceChargePercentage}
              serviceCharge={serviceCharge}
              isLoading={isCreatingOrder}
            />
          </div>
        </div>
      )}
      
      {!showPendingOrders && !currentOrderStatus && 
        <FloatingCartButton 
          itemCount={totalItemsInCart}
          total={total}
          onClick={scrollToCart}
        />
      }
    </div>
  );
};

export default OrderPage;
