
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { AlertTriangle, Home, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: Attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  useEffect(() => {
    // Check if we're in a production environment that might have base path issues
    if (window.location.hostname.includes("preview") || 
        window.location.hostname.includes("lovable.app")) {
      console.log("Production environment detected, adding special 404 handling");
    }
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        <div className="p-6 sm:p-8">
          <div className="flex justify-center mb-6">
            <div className="h-16 w-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center">
              <AlertTriangle className="h-8 w-8 text-red-500 dark:text-red-400" />
            </div>
          </div>
          
          <h1 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-2">
            Page Not Found
          </h1>
          
          <p className="text-gray-600 dark:text-gray-400 text-center mb-6">
            The page you're looking for doesn't exist or has been moved.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button 
              variant="default" 
              className="gap-2"
              onClick={() => window.history.back()}
            >
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </Button>
            
            <Link to="/">
              <Button variant="outline" className="gap-2 w-full sm:w-auto">
                <Home className="h-4 w-4" />
                Return Home
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-900/50 px-6 py-4 text-sm text-center text-gray-500 dark:text-gray-400">
          <div>Error path: {location.pathname}</div>
          <div className="mt-1">Current URL: {window.location.href}</div>
          <div className="mt-1 text-xs">Try refreshing or clearing your browser cache if issues persist.</div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
