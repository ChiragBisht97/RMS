
import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';

const TermsPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <div className="flex-1 pt-32 pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8">
              <Link to="/">
                <Button variant="ghost" className="pl-0 flex items-center text-muted-foreground">
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  Back to Home
                </Button>
              </Link>
            </div>
            
            <div className="prose prose-lg max-w-none">
              <h1 className="text-4xl font-display font-bold tracking-tight mb-8">Terms of Service</h1>
              
              <p className="text-muted-foreground mb-6">
                Last updated: August 1, 2023
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">1. Introduction</h2>
              <p>
                Welcome to PlateSync ("Company", "we", "our", "us")! These Terms of Service ("Terms", "Terms of Service") govern your use of our website and application operated by Grovention Tech Private Limited.
              </p>
              <p>
                By accessing or using the PlateSync application, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access our services.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">2. Use of Service</h2>
              <p>
                PlateSync is a restaurant management system designed to help restaurant owners and managers streamline their operations. Our services include menu management, order processing, table management, and reporting tools.
              </p>
              <p>
                You must provide accurate and complete information when creating an account. You are responsible for safeguarding the password and for all activities that occur under your account.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">3. Subscriptions</h2>
              <p>
                Some parts of our service are billed on a subscription basis. You will be billed in advance on a recurring and periodic basis, depending on the type of subscription plan you select.
              </p>
              <p>
                At the end of each period, your subscription will automatically renew under the same conditions unless you cancel it or Grovention Tech Private Limited cancels it.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">4. Free Trial</h2>
              <p>
                We may, at our sole discretion, offer a subscription with a free trial for a limited period of time. You may be required to enter your billing information to sign up for the free trial.
              </p>
              <p>
                If you do not cancel your subscription before the end of the free trial period, you will be automatically charged for the subscription plan you selected.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">5. Intellectual Property</h2>
              <p>
                Our service and its original content, features, and functionality are and will remain the exclusive property of Grovention Tech Private Limited and its licensors. The service is protected by copyright, trademark, and other laws.
              </p>
              <p>
                Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Grovention Tech Private Limited.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">6. Content</h2>
              <p>
                Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, or other material. You are responsible for the content that you post, including its legality, reliability, and appropriateness.
              </p>
              <p>
                By posting content, you grant us the right to use, modify, publicly perform, publicly display, reproduce, and distribute such content on and through our service.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">7. Termination</h2>
              <p>
                We may terminate or suspend your account and bar access to the service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever, including without limitation if you breach the Terms.
              </p>
              <p>
                If you wish to terminate your account, you may simply discontinue using the service, or contact us to have your account permanently deleted.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">8. Limitation of Liability</h2>
              <p>
                In no event shall Grovention Tech Private Limited, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the service.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">9. Changes</h2>
              <p>
                We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
              </p>
              <p>
                By continuing to access or use our service after any revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, you are no longer authorized to use the service.
              </p>
              
              <h2 className="text-2xl font-semibold mt-8 mb-4">10. Contact Us</h2>
              <p>
                If you have any questions about these Terms, please contact us:
              </p>
              <ul className="list-disc pl-6 mt-2">
                <li>By email: support@grovention.com</li>
                <li>By phone number: +91 98765 43210</li>
                <li>By mail: 123 Tech Park, Bangalore, India</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default TermsPage;
