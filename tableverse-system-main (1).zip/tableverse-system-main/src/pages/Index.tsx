
import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { AnimatedButton } from '@/components/ui/AnimatedButton';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-b from-background to-background/50 py-20 md:py-32">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold tracking-tighter">
                  Streamline Your Restaurant Operations with 
                  <span className="text-primary"> PlateSync</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-[600px]">
                  The all-in-one solution for modern restaurants. Manage orders, menus, and tables seamlessly.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 pt-4">
                  <Link to="/login">
                    <AnimatedButton variant="default" size="lg" glint>
                      Get Started
                    </AnimatedButton>
                  </Link>
                  <Link to="/pricing">
                    <AnimatedButton variant="outline" size="lg">
                      View Pricing
                    </AnimatedButton>
                  </Link>
                </div>
              </div>
              <div className="relative lg:pl-10">
                <div className="relative w-full h-[350px] md:h-[400px] lg:h-[500px] bg-gradient-to-br from-primary/5 to-primary/30 rounded-3xl overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <img
                      src="/placeholder.svg"
                      alt="PlateSync Dashboard"
                      className="w-[90%] h-auto shadow-2xl rounded-lg border border-border/50"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-muted/30">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="text-center max-w-[800px] mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight mb-4">
                Powerful Features for Modern Restaurants
              </h2>
              <p className="text-lg text-muted-foreground">
                Everything you need to simplify your restaurant management in one place.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="bg-background rounded-xl p-6 shadow-sm border border-border/50">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M16 6v2m2 2h2"></path><path d="M4 10h6"></path><path d="M4 14h6"></path><path d="M14 14h6"></path><path d="M4 18h16"></path><path d="M20 10v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h8"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Menu Management</h3>
                <p className="text-muted-foreground">
                  Create and manage your menu categories and items with ease. Update prices and availability in real-time.
                </p>
              </div>
              
              {/* Feature 2 */}
              <div className="bg-background rounded-xl p-6 shadow-sm border border-border/50">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M3 7h18"></path><path d="M3 11h18"></path><path d="M3 15h8"></path><path d="M3 19h8"></path><rect x="15" y="15" width="5" height="8" rx="1"></rect>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Order Processing</h3>
                <p className="text-muted-foreground">
                  Take orders quickly and efficiently. Send them directly to the kitchen and track their status in real-time.
                </p>
              </div>
              
              {/* Feature 3 */}
              <div className="bg-background rounded-xl p-6 shadow-sm border border-border/50">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M19 5h-7L9 2H5a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Z"></path><path d="M9 10h6"></path><path d="M12 7v6"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Table Management</h3>
                <p className="text-muted-foreground">
                  Organize your tables, create QR codes, and allow customers to place orders directly from their phones.
                </p>
              </div>
              
              {/* Feature 4 */}
              <div className="bg-background rounded-xl p-6 shadow-sm border border-border/50">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <rect width="20" height="14" x="2" y="5" rx="2"></rect><line x1="2" x2="22" y1="10" y2="10"></line>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Payment Processing</h3>
                <p className="text-muted-foreground">
                  Accept various payment methods, split bills, and process transactions quickly and securely.
                </p>
              </div>
              
              {/* Feature 5 */}
              <div className="bg-background rounded-xl p-6 shadow-sm border border-border/50">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <line x1="12" x2="12" y1="2" y2="22"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Sales Analytics</h3>
                <p className="text-muted-foreground">
                  Get detailed insights into your sales performance, popular items, and customer behavior.
                </p>
              </div>
              
              {/* Feature 6 */}
              <div className="bg-background rounded-xl p-6 shadow-sm border border-border/50">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">User Management</h3>
                <p className="text-muted-foreground">
                  Add staff members with different roles and permissions to streamline your operations.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-20">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="bg-gradient-to-r from-primary/20 to-primary/5 rounded-3xl p-10 text-center">
              <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight mb-4">
                Ready to Transform Your Restaurant?
              </h2>
              <p className="text-lg text-muted-foreground max-w-[600px] mx-auto mb-8">
                Join thousands of restaurants that are already using PlateSync to streamline their operations.
              </p>
              <Link to="/login">
                <AnimatedButton variant="default" size="lg" glint>
                  Get Started Today
                </AnimatedButton>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
