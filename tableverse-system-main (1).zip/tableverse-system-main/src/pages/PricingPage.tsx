
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, X, Check } from 'lucide-react';

const PricingPage = () => {
  const [billingCycle, setBillingCycle] = useState('monthly');
  
  const plans = [
    {
      name: 'Starter',
      monthlyPrice: 49,
      yearlyPrice: 490, // 20% off
      description: 'Perfect for small restaurants and cafes just getting started.',
      features: [
        'Up to 30 menu items',
        'Up to 10 tables',
        'Basic QR ordering',
        'Limited reporting',
        'Email support',
        'Mobile-friendly ordering',
      ],
      notIncluded: [
        'Table management',
        'Advanced analytics',
        'Multi-location support',
        'Custom branding',
        'API access',
        'Priority support',
      ],
      popular: false,
      buttonText: 'Get Started'
    },
    {
      name: 'Professional',
      monthlyPrice: 99,
      yearlyPrice: 990, // 20% off
      description: 'Ideal for growing restaurants that need more features.',
      features: [
        'Unlimited menu items',
        'Up to 50 tables',
        'Advanced QR ordering',
        'Comprehensive reporting',
        'Table management',
        'Mobile-friendly ordering',
        'Email & chat support',
        'Customer database',
        'Basic analytics',
      ],
      notIncluded: [
        'Multi-location support',
        'API access',
        'Custom branding',
      ],
      popular: true,
      buttonText: 'Get Started'
    },
    {
      name: 'Enterprise',
      monthlyPrice: 249,
      yearlyPrice: 2490, // 20% off
      description: 'Advanced features for established restaurants and chains.',
      features: [
        'Unlimited menu items',
        'Unlimited tables',
        'Premium QR ordering',
        'Advanced analytics & reporting',
        'Table management',
        'Mobile-friendly ordering',
        'Priority 24/7 support',
        'Customer relationship management',
        'Multi-location support',
        'API access',
        'Custom branding',
        'Dedicated account manager',
      ],
      notIncluded: [],
      popular: false,
      buttonText: 'Contact Sales'
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-display font-bold tracking-tight mb-4">
              Pricing Plans for Every Restaurant
            </h1>
            <p className="text-xl text-muted-foreground">
              Choose the perfect plan to support your restaurant's growth and success
            </p>
          </div>
          
          <div className="mx-auto max-w-md mb-12">
            <Tabs 
              defaultValue="monthly" 
              value={billingCycle} 
              onValueChange={setBillingCycle}
              className="mx-auto"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
                <TabsTrigger value="yearly" className="relative">
                  Annual Billing
                  <span className="absolute -top-3 -right-3 bg-primary/10 text-primary text-xs px-2 py-0.5 rounded-full">
                    Save 20%
                  </span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card 
                key={plan.name} 
                className={`flex flex-col ${plan.popular ? 'border-primary shadow-lg relative' : 'border-border shadow'}`}
              >
                {plan.popular && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}
                
                <CardHeader className={plan.popular ? 'pb-2' : ''}>
                  <CardTitle className="text-2xl font-display">{plan.name}</CardTitle>
                  <CardDescription className="mt-1">{plan.description}</CardDescription>
                </CardHeader>
                
                <CardContent className="flex-grow">
                  <div className="mb-6">
                    <p className="text-4xl font-display font-bold">
                      ${billingCycle === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice}
                    </p>
                    <p className="text-muted-foreground">
                      per {billingCycle === 'monthly' ? 'month' : 'year'}
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    {plan.features.map((feature) => (
                      <div key={feature} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary shrink-0 mr-2" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                    
                    {plan.notIncluded.map((feature) => (
                      <div key={feature} className="flex items-start text-muted-foreground">
                        <X className="h-5 w-5 shrink-0 mr-2" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
                
                <CardFooter>
                  <Link to="/login" className="w-full">
                    <AnimatedButton 
                      className="w-full" 
                      variant={plan.popular ? "default" : "outline"}
                      glint={plan.popular}
                    >
                      {plan.buttonText}
                    </AnimatedButton>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-primary/5 border-t border-border/40">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-display font-bold tracking-tight mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground">
              Everything you need to know about our pricing and features
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-background rounded-lg p-6 border border-border/50">
              <h3 className="text-xl font-medium mb-3">Can I switch plans later?</h3>
              <p className="text-muted-foreground">
                Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
              </p>
            </div>
            
            <div className="bg-background rounded-lg p-6 border border-border/50">
              <h3 className="text-xl font-medium mb-3">Do you offer a free trial?</h3>
              <p className="text-muted-foreground">
                Yes, all plans come with a 14-day free trial with no credit card required. Test all features before committing.
              </p>
            </div>
            
            <div className="bg-background rounded-lg p-6 border border-border/50">
              <h3 className="text-xl font-medium mb-3">What payment methods do you accept?</h3>
              <p className="text-muted-foreground">
                We accept all major credit cards, including Visa, Mastercard, and American Express. We also support payments via PayPal.
              </p>
            </div>
            
            <div className="bg-background rounded-lg p-6 border border-border/50">
              <h3 className="text-xl font-medium mb-3">Is there a setup fee?</h3>
              <p className="text-muted-foreground">
                No, there are no setup fees for any of our plans. You only pay the advertised monthly or annual subscription.
              </p>
            </div>
            
            <div className="bg-background rounded-lg p-6 border border-border/50">
              <h3 className="text-xl font-medium mb-3">Can I get a custom plan?</h3>
              <p className="text-muted-foreground">
                Absolutely! For larger restaurants or chains with specific needs, contact our sales team for a tailored solution.
              </p>
            </div>
            
            <div className="bg-background rounded-lg p-6 border border-border/50">
              <h3 className="text-xl font-medium mb-3">What support is included?</h3>
              <p className="text-muted-foreground">
                All plans include email support. Professional plans and above include chat support, while Enterprise plans have priority 24/7 support.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="bg-primary/10 rounded-2xl p-8 md:p-12 max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-display font-bold tracking-tight mb-4">
                Still have questions?
              </h2>
              <p className="text-lg text-muted-foreground">
                Our team is here to help. Contact us for personalized assistance.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/contact">
                <AnimatedButton size="lg" variant="outline" className="w-full sm:w-auto">
                  Contact Sales
                </AnimatedButton>
              </Link>
              <Link to="/login">
                <AnimatedButton size="lg" glint className="w-full sm:w-auto">
                  Start Free Trial
                </AnimatedButton>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default PricingPage;
