
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import BlurCard from '@/components/ui/BlurCard';
import { Check, ChevronRight, ClipboardList, Utensils, Users, CreditCard, QrCode, Calendar, BarChart4 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const LandingPage = () => {
  const features = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-scale-in');
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersection, {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    });

    document.querySelectorAll('.reveal-item').forEach(item => {
      observer.observe(item);
      // Initially hide
      item.classList.add('opacity-0');
    });

    return () => observer.disconnect();
  }, []);

  const scrollToFeatures = () => {
    features.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute left-1/2 top-0 -translate-x-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-3xl opacity-30" />
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold tracking-tight mb-6 animate-fade-in">
              Elevate Your Restaurant Management with
              <span className="text-primary"> PlateSync</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-fade-in animate-delay-100">
              A beautifully designed, intuitive system for managing menus, orders, tables, 
              staff, and more—all in one elegant platform.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12 animate-fade-in animate-delay-200">
              <Link to="/login">
                <AnimatedButton size="lg" glint className="w-full sm:w-auto">
                  Get Started <ChevronRight className="ml-2 h-4 w-4" />
                </AnimatedButton>
              </Link>
              <AnimatedButton size="lg" variant="outline" onClick={scrollToFeatures} className="w-full sm:w-auto">
                Explore Features
              </AnimatedButton>
            </div>
            
            <div className="relative mx-auto max-w-4xl rounded-2xl border border-border overflow-hidden shadow-xl animate-fade-in animate-delay-300">
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/10 to-background/10 opacity-50" />
              <img 
                src="https://placehold.co/1200x800/e4e9f6/404e8f?text=PlateSync+Dashboard" 
                alt="PlateSync Dashboard" 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Clients Section */}
      <section className="py-12 bg-secondary/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground mb-6">TRUSTED BY RESTAURANTS WORLDWIDE</p>
            <div className="flex flex-wrap justify-center gap-x-12 gap-y-8 opacity-70">
              <div className="h-8 text-muted-foreground font-display font-bold">FINE DINING CO</div>
              <div className="h-8 text-muted-foreground font-display font-bold">BISTRO GROUP</div>
              <div className="h-8 text-muted-foreground font-display font-bold">CAFE CHAIN</div>
              <div className="h-8 text-muted-foreground font-display font-bold">CULINARY EXPERTS</div>
              <div className="h-8 text-muted-foreground font-display font-bold">RESTAURANT ALLIANCE</div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section ref={features} className="py-20 md:py-32 bg-background" id="features">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight mb-4 reveal-item">
              Comprehensive Features for Modern Restaurants
            </h2>
            <p className="text-xl text-muted-foreground reveal-item">
              Everything you need to streamline operations and enhance customer experience
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlurCard className="p-6 reveal-item">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Utensils className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Menu Management</h3>
              <p className="text-muted-foreground">
                Create, edit, and organize your menus with an intuitive interface. Add images, descriptions, prices and more.
              </p>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <ClipboardList className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Order Processing</h3>
              <p className="text-muted-foreground">
                Manage orders in real-time with a beautiful interface that keeps your kitchen and staff in sync.
              </p>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <QrCode className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">QR Code Tables</h3>
              <p className="text-muted-foreground">
                Enable contactless ordering with unique QR codes for each table that customers can scan with their phones.
              </p>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <CreditCard className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Point of Sale</h3>
              <p className="text-muted-foreground">
                Streamlined POS system with intuitive checkout flow, payment processing, and receipt generation.
              </p>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">User Management</h3>
              <p className="text-muted-foreground">
                Manage staff accounts with tailored permissions for servers, chefs, managers, and administrators.
              </p>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <BarChart4 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Analytics & Insights</h3>
              <p className="text-muted-foreground">
                Gain valuable business insights with beautiful reports and dashboards for sales, inventory, and more.
              </p>
            </BlurCard>
          </div>
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-20 md:py-32 bg-subtle-gradient">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight mb-4 reveal-item">
              How PlateSync Works
            </h2>
            <p className="text-xl text-muted-foreground reveal-item">
              A seamless experience from setup to daily operations
            </p>
          </div>
          
          <div className="relative max-w-4xl mx-auto">
            {/* Connecting line */}
            <div className="absolute left-[50%] top-0 bottom-0 w-px bg-border hidden md:block" />
            
            <div className="space-y-12 md:space-y-0">
              <div className="md:grid md:grid-cols-2 md:gap-8 items-center reveal-item">
                <div className="md:text-right md:pr-12 mb-6 md:mb-0">
                  <div className="bg-primary/10 text-primary text-sm font-medium px-3 py-1 rounded-full inline-block mb-2">Step 1</div>
                  <h3 className="text-2xl font-medium mb-2">Set Up Your Restaurant</h3>
                  <p className="text-muted-foreground">Easily configure your restaurant profile, layout, and menu items in minutes.</p>
                </div>
                <div className="md:pl-12 relative">
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-medium z-10 hidden md:flex">1</div>
                  <div className="bg-white p-1 rounded-xl shadow-sm">
                    <img 
                      src="https://placehold.co/600x400/e4e9f6/404e8f?text=Setup" 
                      alt="Setup Process" 
                      className="rounded-lg w-full"
                    />
                  </div>
                </div>
              </div>
              
              <div className="md:grid md:grid-cols-2 md:gap-8 items-center reveal-item">
                <div className="md:order-2 md:pl-12 mb-6 md:mb-0">
                  <div className="bg-primary/10 text-primary text-sm font-medium px-3 py-1 rounded-full inline-block mb-2">Step 2</div>
                  <h3 className="text-2xl font-medium mb-2">Create QR Codes</h3>
                  <p className="text-muted-foreground">Generate unique QR codes for each table to enable contactless ordering.</p>
                </div>
                <div className="md:order-1 md:pr-12 relative">
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-medium z-10 hidden md:flex">2</div>
                  <div className="bg-white p-1 rounded-xl shadow-sm">
                    <img 
                      src="https://placehold.co/600x400/e4e9f6/404e8f?text=QR+Codes" 
                      alt="QR Code Generation" 
                      className="rounded-lg w-full"
                    />
                  </div>
                </div>
              </div>
              
              <div className="md:grid md:grid-cols-2 md:gap-8 items-center reveal-item">
                <div className="md:text-right md:pr-12 mb-6 md:mb-0">
                  <div className="bg-primary/10 text-primary text-sm font-medium px-3 py-1 rounded-full inline-block mb-2">Step 3</div>
                  <h3 className="text-2xl font-medium mb-2">Manage Orders</h3>
                  <p className="text-muted-foreground">Process orders in real-time with automated kitchen notifications and status tracking.</p>
                </div>
                <div className="md:pl-12 relative">
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-medium z-10 hidden md:flex">3</div>
                  <div className="bg-white p-1 rounded-xl shadow-sm">
                    <img 
                      src="https://placehold.co/600x400/e4e9f6/404e8f?text=Orders" 
                      alt="Order Management" 
                      className="rounded-lg w-full"
                    />
                  </div>
                </div>
              </div>
              
              <div className="md:grid md:grid-cols-2 md:gap-8 items-center reveal-item">
                <div className="md:order-2 md:pl-12">
                  <div className="bg-primary/10 text-primary text-sm font-medium px-3 py-1 rounded-full inline-block mb-2">Step 4</div>
                  <h3 className="text-2xl font-medium mb-2">Analyze & Optimize</h3>
                  <p className="text-muted-foreground">Review performance metrics and insights to improve service and increase revenue.</p>
                </div>
                <div className="md:order-1 md:pr-12 relative">
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-medium z-10 hidden md:flex">4</div>
                  <div className="bg-white p-1 rounded-xl shadow-sm">
                    <img 
                      src="https://placehold.co/600x400/e4e9f6/404e8f?text=Analytics" 
                      alt="Analytics Dashboard" 
                      className="rounded-lg w-full"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight mb-4 reveal-item">
              Trusted by Restaurant Owners
            </h2>
            <p className="text-xl text-muted-foreground reveal-item">
              Hear what our customers have to say about PlateSync
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlurCard className="p-6 reveal-item">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                  <span className="text-primary font-medium">JD</span>
                </div>
                <div>
                  <h4 className="font-medium">John Doe</h4>
                  <p className="text-sm text-muted-foreground">Fine Dining Owner</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                "PlateSync has completely transformed how we manage our restaurant. The interface is beautiful and intuitive, and our staff picked it up in no time."
              </p>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg key={star} className="h-5 w-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                  <span className="text-primary font-medium">JS</span>
                </div>
                <div>
                  <h4 className="font-medium">Jane Smith</h4>
                  <p className="text-sm text-muted-foreground">Bistro Manager</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                "The QR code ordering system has been a game-changer for our bistro. Customers love the convenience, and it's significantly reduced order errors."
              </p>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg key={star} className="h-5 w-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </BlurCard>
            
            <BlurCard className="p-6 reveal-item">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                  <span className="text-primary font-medium">RJ</span>
                </div>
                <div>
                  <h4 className="font-medium">Robert Johnson</h4>
                  <p className="text-sm text-muted-foreground">Restaurant Chain Owner</p>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                "Managing multiple locations has never been easier. The analytics help us identify trends across all our restaurants and optimize accordingly."
              </p>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg key={star} className="h-5 w-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </BlurCard>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 md:py-32 relative">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-primary/5" />
          <div className="absolute left-0 right-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
          <div className="absolute left-0 right-0 bottom-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight mb-4 reveal-item">
              Ready to Transform Your Restaurant Management?
            </h2>
            <p className="text-xl text-muted-foreground mb-8 reveal-item">
              Join thousands of restaurants using PlateSync to streamline operations and enhance customer experience.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 reveal-item">
              <Link to="/login">
                <AnimatedButton size="lg" glint className="w-full sm:w-auto">
                  Get Started
                </AnimatedButton>
              </Link>
              <Link to="/contact">
                <AnimatedButton size="lg" variant="outline" className="w-full sm:w-auto">
                  Contact Sales
                </AnimatedButton>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default LandingPage;
