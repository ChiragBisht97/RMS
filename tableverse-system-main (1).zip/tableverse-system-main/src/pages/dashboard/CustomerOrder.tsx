
import React from 'react';
import { useServerOrder } from '@/hooks/useServerOrder';

// Imported components
import TableSelection from '@/components/dashboard/customer-order/TableSelection';
import OrderStatusSection from '@/components/dashboard/customer-order/OrderStatusSection';
import MenuSection from '@/components/dashboard/customer-order/MenuSection';
import CartSection from '@/components/dashboard/customer-order/CartSection';
import MobileCartSummary from '@/components/dashboard/customer-order/MobileCartSummary';

const CustomerOrder = () => {
  const {
    cart,
    isLoading,
    categories,
    menuItems,
    currentOrderStatus,
    selectedTable,
    setSelectedTable,
    tables,
    currentTab,
    setCurrentTab,
    subtotal,
    tax,
    serviceCharge,
    total,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    placeOrder,
    resetOrder,
    applyServiceCharge,
    serviceChargePercentage
  } = useServerOrder();

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 pb-20 md:pb-8 animate-fade-in">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-display font-bold tracking-tight">Server Order System</h1>
        <p className="text-muted-foreground">Place orders on behalf of customers</p>
      </div>
      
      {/* Table selection */}
      <div className="mb-6 flex justify-center">
        <TableSelection 
          selectedTable={selectedTable} 
          setSelectedTable={setSelectedTable} 
          tables={tables} 
        />
      </div>
      
      {currentOrderStatus ? (
        <OrderStatusSection 
          currentOrderStatus={currentOrderStatus}
          selectedTable={selectedTable}
          tables={tables}
          resetOrder={resetOrder}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Menu Section */}
          <div className="lg:col-span-2">
            <MenuSection 
              categories={categories}
              currentTab={currentTab}
              setCurrentTab={setCurrentTab}
              menuItems={menuItems}
              addToCart={addToCart}
              isLoading={isLoading}
            />
          </div>
          
          {/* Cart Section */}
          <div id="cart-section">
            <CartSection 
              cart={cart}
              selectedTable={selectedTable}
              tables={tables}
              subtotal={subtotal}
              tax={tax}
              serviceCharge={serviceCharge}
              total={total}
              updateQuantity={updateQuantity}
              removeFromCart={removeFromCart}
              clearCart={clearCart}
              placeOrder={placeOrder}
              applyServiceCharge={applyServiceCharge}
              serviceChargePercentage={serviceChargePercentage}
            />
          </div>
        </div>
      )}
      
      {/* Mobile Cart Summary */}
      {!currentOrderStatus && 
        <MobileCartSummary 
          cart={cart} 
          total={total} 
          clearCart={clearCart} 
        />
      }
    </div>
  );
};

export default CustomerOrder;
