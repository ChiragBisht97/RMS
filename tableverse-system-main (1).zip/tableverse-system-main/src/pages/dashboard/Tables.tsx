import React, { useState, useEffect } from 'react';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { TableItem } from '@/types/tables';
import TableHeader from '@/components/tables/TableHeader';
import TableStats from '@/components/tables/TableStats';
import TableGridView from '@/components/tables/TableGridView';
import TableListView from '@/components/tables/TableListView';
import TableFormDialog from '@/components/tables/TableFormDialog';
import TableDialog from '@/components/tables/TableDialog';
import DeleteConfirmationDialog from '@/components/tables/DeleteConfirmationDialog';
import { generateTableQrCode } from '@/utils/qrCode';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TableLayout from '@/components/tables/TableLayout';
import { useAuth } from '@/contexts/AuthContext';
const Tables = () => {
  // State declarations
  const [tables, setTables] = useState<TableItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [tableFormDialog, setTableFormDialog] = useState<{
    open: boolean;
    table: TableItem | null;
  }>({
    open: false,
    table: null
  });
  const [qrDialog, setQRDialog] = useState<{
    open: boolean;
    qrCode: string | null;
    tableName: string | null;
    tableId: string | null;
  }>({
    open: false,
    qrCode: null,
    tableName: null,
    tableId: null
  });
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean;
    tableId: string | null;
    tableName: string | null;
  }>({
    open: false,
    tableId: null,
    tableName: null
  });
  const {
    profile
  } = useAuth();

  // Data fetching
  const fetchTables = async () => {
    setIsLoading(true);
    try {
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID is missing. Please set up your restaurant first.',
          variant: 'destructive'
        });
        setIsLoading(false);
        return;
      }
      const {
        data,
        error
      } = await supabase.from('tables').select('*').eq('restaurant_id', profile.restaurant_id).order('tb_created_at', {
        ascending: false
      });
      if (error) throw error;
      setTables(data.map(table => ({
        id: table.tb_id,
        name: table.tb_name,
        capacity: table.tb_capacity,
        status: table.tb_status,
        location: table.tb_location,
        qr_code: table.tb_qr_code,
        created_at: table.tb_created_at,
        updated_at: table.tb_updated_at
      })));
    } catch (error) {
      console.error('Error fetching tables:', error);
      toast({
        title: 'Error',
        description: 'Failed to load tables',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Initial data loading
  useEffect(() => {
    if (profile?.restaurant_id) {
      fetchTables();
    }
  }, [profile?.restaurant_id]);

  // Handler functions
  const handleEditTable = (table: TableItem) => {
    setTableFormDialog({
      open: true,
      table
    });
  };
  const handleTableSaved = () => {
    fetchTables();
  };
  const handleUpdateStatus = async (tableId: string, newStatus: string) => {
    try {
      if (!profile?.restaurant_id) return;

      // If trying to mark table as Available, check for active orders first
      if (newStatus === 'Available') {
        // Check for active orders on this table
        const {
          data: activeOrders,
          error: checkError
        } = await supabase.from('orders').select('order_id').eq('table_id', tableId).in('status', ['Pending', 'In Progress', 'Ready']).limit(1);
        if (checkError) throw checkError;

        // If there are active orders, prevent status change
        if (activeOrders && activeOrders.length > 0) {
          toast({
            title: "Cannot Release Table",
            description: "This table has active orders that need to be completed first.",
            variant: "destructive"
          });
          return;
        }
      }

      // If no active orders or changing to another status, proceed with update
      const {
        error
      } = await supabase.from('tables').update({
        tb_status: newStatus
      }).eq('tb_id', tableId).eq('restaurant_id', profile.restaurant_id);
      if (error) throw error;
      setTables(tables.map(table => table.id === tableId ? {
        ...table,
        status: newStatus
      } : table));
      toast({
        title: 'Table Updated',
        description: `Table status updated to ${newStatus}`
      });
    } catch (error) {
      console.error('Error updating table status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update table status',
        variant: 'destructive'
      });
    }
  };
  const handleGenerateQR = async (tableId: string, tableName: string) => {
    try {
      if (!profile?.restaurant_id) return;
      const qrCodeDataUrl = await generateTableQrCode(tableId);

      // Update the table in the database with the QR code
      const {
        error
      } = await supabase.from('tables').update({
        tb_qr_code: qrCodeDataUrl
      }).eq('tb_id', tableId).eq('restaurant_id', profile.restaurant_id);
      if (error) throw error;

      // Update local state
      setTables(tables.map(table => table.id === tableId ? {
        ...table,
        qr_code: qrCodeDataUrl
      } : table));
      toast({
        title: 'QR Code Generated',
        description: `QR code generated for ${tableName}`
      });
    } catch (error) {
      console.error('Error generating QR code:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate QR code',
        variant: 'destructive'
      });
    }
  };
  const openQRDialog = (qrCode: string, tableName: string, tableId: string) => {
    setQRDialog({
      open: true,
      qrCode,
      tableName,
      tableId
    });
  };
  const handleDeleteTable = async (tableId: string, tableName: string) => {
    setDeleteDialog({
      open: true,
      tableId,
      tableName
    });
  };
  const handleQRDialogDelete = () => {
    if (qrDialog.tableId && qrDialog.tableName) {
      setQRDialog({
        ...qrDialog,
        open: false
      });
      handleDeleteTable(qrDialog.tableId, qrDialog.tableName);
    }
  };
  const handleTableDeleted = () => {
    fetchTables();
  };
  return <div className="space-y-6">
      <TableHeader handleAddTable={() => setTableFormDialog({
      open: true,
      table: null
    })} tables={tables} fetchTables={fetchTables} />
      
      <TableStats tables={tables} isLoading={isLoading} />
      
      <Tabs defaultValue="grid" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="grid">Grid View</TabsTrigger>
          <TabsTrigger value="list" className="text-slate-400">List View</TabsTrigger>
          <TabsTrigger value="floor">Floor Layout</TabsTrigger>
        </TabsList>
        <TabsContent value="grid">
          <TableGridView tables={tables} isLoading={isLoading} handleAddTable={() => setTableFormDialog({
          open: true,
          table: null
        })} handleEditTable={handleEditTable} handleUpdateStatus={handleUpdateStatus} generateQRCode={handleGenerateQR} viewQRCode={(qrCode, tableName, tableId) => openQRDialog(qrCode, tableName, tableId)} handleDeleteTable={handleDeleteTable} />
        </TabsContent>
        <TabsContent value="list">
          <TableListView tables={tables} isLoading={isLoading} handleAddTable={() => setTableFormDialog({
          open: true,
          table: null
        })} handleEditTable={handleEditTable} handleDeleteTable={handleDeleteTable} generateQRCode={handleGenerateQR} viewQRCode={(qrCode, tableName, tableId) => openQRDialog(qrCode, tableName, tableId)} />
        </TabsContent>
        <TabsContent value="floor">
          <TableLayout tables={tables} onTableDeleted={handleTableDeleted} />
        </TabsContent>
      </Tabs>
      
      {tableFormDialog.open && <TableFormDialog open={tableFormDialog.open} onOpenChange={open => setTableFormDialog({
      ...tableFormDialog,
      open
    })} table={tableFormDialog.table} onTableSaved={handleTableSaved} />}
      
      {qrDialog.open && qrDialog.qrCode && <TableDialog open={qrDialog.open} onOpenChange={open => setQRDialog({
      ...qrDialog,
      open
    })} qrCodeUrl={qrDialog.qrCode} tableName={qrDialog.tableName || ''} tableId={qrDialog.tableId || ''} onSuccess={() => fetchTables()} onDelete={handleQRDialogDelete} />}

      {deleteDialog.open && deleteDialog.tableId && <DeleteConfirmationDialog open={deleteDialog.open} onOpenChange={open => setDeleteDialog({
      ...deleteDialog,
      open
    })} tableId={deleteDialog.tableId} tableName={deleteDialog.tableName || ''} onSuccess={handleTableDeleted} />}
    </div>;
};
export default Tables;