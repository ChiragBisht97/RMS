
import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { toast as sonnerToast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import UserTable from "@/components/user-management/UserTable";
import CreateUserDialog from "@/components/user-management/CreateUserDialog";
import ResetPasswordDialog from "@/components/user-management/ResetPasswordDialog";
import EditProfileDialog from "@/components/user-management/EditProfileDialog";

const roleOptions = [
  { value: "admin", label: "Admin" },
  { value: "manager", label: "Manager" },
  { value: "staff", label: "Staff" },
];

const Users = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, profile } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false);
  const [isEditProfileDialogOpen, setIsEditProfileDialogOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState("staff");
  const [selectedUserId, setSelectedUserId] = useState("");
  const [selectedUserEmail, setSelectedUserEmail] = useState("");
  const [selectedProfileDetails, setSelectedProfileDetails] = useState({
    firstName: "",
    lastName: ""
  });
  const [isCreating, setIsCreating] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const { data: users, isLoading, refetch } = useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      if (!profile?.restaurant_id) {
        console.error("No restaurant ID available");
        return [];
      }
      
      console.log("Fetching users for restaurant:", profile.restaurant_id);
      
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("restaurant_id", profile.restaurant_id);
  
        if (error) {
          console.error("Error fetching users:", error);
          throw error;
        }
  
        console.log("Fetched users count:", data?.length || 0);
        console.log("Fetched users:", data);
        return data || [];
      } catch (error) {
        console.error("Exception in fetchUsers:", error);
        toast({
          title: "Error fetching users",
          description: "Failed to load user data",
          variant: "destructive",
        });
        return [];
      }
    },
    enabled: !!profile?.restaurant_id,
    staleTime: 30000, // Refetch after 30 seconds
    retry: 3, // Retry failed requests up to 3 times
  });

  // Force refetch on component mount to ensure we have the latest data
  useEffect(() => {
    if (profile?.restaurant_id) {
      refetch();
    }
  }, [profile?.restaurant_id, refetch]);

  const handleCreateUser = async (formData: { email: string, firstName: string, lastName: string }) => {
    try {
      setIsCreating(true);
      
      if (!formData.email || !formData.email.includes('@')) {
        toast({
          title: "Invalid email",
          description: "Please enter a valid email address",
          variant: "destructive",
        });
        setIsCreating(false);
        return;
      }

      if (!formData.firstName || !formData.lastName) {
        toast({
          title: "Missing information",
          description: "First name and last name are required",
          variant: "destructive",
        });
        setIsCreating(false);
        return;
      }

      const { data, error } = await supabase.functions.invoke('create-restaurant-user', {
        body: { 
          email: formData.email,
          firstName: formData.firstName,
          lastName: formData.lastName,
          role: selectedRole,
          restaurantId: profile?.restaurant_id
        }
      });
      
      if (error) {
        throw error;
      }
      
      sonnerToast.success("User created successfully", {
        description: `An email with temporary login credentials has been sent to ${formData.email}.`,
      });
      
      handleCloseCreateDialog();
      queryClient.invalidateQueries({ queryKey: ["users"] });
    } catch (error: any) {
      console.error("User creation error:", error);
      toast({
        title: "Failed to create user",
        description: error.message || "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const resetUserPassword = useMutation({
    mutationFn: async ({ userId, email, newPassword }: { userId: string, email: string, newPassword: string }) => {
      try {
        const { data, error } = await supabase.functions.invoke('create-restaurant-user', {
          body: { 
            action: 'reset-password', 
            userId, 
            email,
            newPassword
          }
        });
        
        if (error) throw new Error(error.message);
        if (!data || data.error) throw new Error(data?.error || 'Failed to reset password');
        
        return data;
      } catch (error: any) {
        console.error("Reset password error:", error);
        throw new Error(error.message || "Failed to reset password");
      }
    },
    onSuccess: () => {
      sonnerToast.success("Password reset successful", {
        description: `The password has been updated.`,
      });
      handleCloseResetPasswordDialog();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to reset password",
        description: error.message || "An unknown error occurred",
        variant: "destructive",
      });
    },
  });

  const updateUserProfile = useMutation({
    mutationFn: async ({ userId, firstName, lastName }: { userId: string, firstName: string, lastName: string }) => {
      try {
        const { data, error } = await supabase.functions.invoke('create-restaurant-user', {
          body: { 
            action: 'update-profile', 
            userId,
            firstName,
            lastName
          }
        });
        
        if (error) throw new Error(error.message);
        if (!data || data.error) throw new Error(data?.error || 'Failed to update profile');
        
        return data;
      } catch (error: any) {
        console.error("Profile update error:", error);
        throw new Error(error.message || "Failed to update profile");
      }
    },
    onSuccess: () => {
      sonnerToast.success("Profile updated successfully", {
        description: `The user profile has been updated.`,
      });
      handleCloseEditDialog();
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update profile",
        description: error.message || "An unknown error occurred",
        variant: "destructive",
      });
    },
  });

  const handleResetPassword = async (formData: { newPassword: string }) => {
    if (!selectedUserId || !selectedUserEmail) {
      toast({
        title: "Error",
        description: "No user selected for password reset",
        variant: "destructive",
      });
      return;
    }

    if (formData.newPassword.length < 6) {
      toast({
        title: "Invalid password",
        description: "Password must be at least 6 characters long",
        variant: "destructive",
      });
      return;
    }

    setIsResetting(true);
    
    try {
      await resetUserPassword.mutateAsync({
        userId: selectedUserId,
        email: selectedUserEmail,
        newPassword: formData.newPassword
      });
    } finally {
      setIsResetting(false);
    }
  };
  
  const handleUpdateProfile = async (formData: { firstName: string, lastName: string }) => {
    if (!selectedUserId) {
      toast({
        title: "Error",
        description: "No user selected for profile update",
        variant: "destructive",
      });
      return;
    }

    if (!formData.firstName || !formData.lastName) {
      toast({
        title: "Missing information",
        description: "First name and last name are required",
        variant: "destructive",
      });
      return;
    }

    setIsEditing(true);
    
    try {
      await updateUserProfile.mutateAsync({
        userId: selectedUserId,
        firstName: formData.firstName,
        lastName: formData.lastName
      });
    } finally {
      setIsEditing(false);
    }
  };

  const openResetPasswordDialog = (userId: string, email: string) => {
    setSelectedUserId(userId);
    setSelectedUserEmail(email);
    setIsResetPasswordDialogOpen(true);
  };
  
  const openEditProfileDialog = (userId: string, firstName: string, lastName: string) => {
    setSelectedUserId(userId);
    setSelectedProfileDetails({ firstName, lastName });
    setIsEditProfileDialogOpen(true);
  };

  const getInitials = (firstName: string | null, lastName: string | null) => {
    const first = firstName ? firstName.charAt(0).toUpperCase() : "?";
    const last = lastName ? lastName.charAt(0).toUpperCase() : "";
    return `${first}${last}`;
  };

  const changeUserRole = async (userId: string, newRole: string) => {
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ pro_role: newRole })
        .eq("pro_id", userId);

      if (error) throw error;

      sonnerToast.success("Role updated", {
        description: "User role has been updated successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ["users"] });
    } catch (error: any) {
      toast({
        title: "Failed to update role",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Handle dialog close events properly
  const handleCloseEditDialog = () => {
    setIsEditProfileDialogOpen(false);
  };
  
  const handleCloseResetPasswordDialog = () => {
    setIsResetPasswordDialogOpen(false);
  };
  
  const handleCloseCreateDialog = () => {
    setIsCreateDialogOpen(false);
  };

  const isNotAdmin = profile && !profile.is_owner && profile.pro_role !== 'admin';

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Users Management</h1>
        {!isNotAdmin && (
          <CreateUserDialog 
            isOpen={isCreateDialogOpen} 
            onOpenChange={setIsCreateDialogOpen}
            onSubmit={handleCreateUser}
            isCreating={isCreating}
            roleOptions={roleOptions}
            selectedRole={selectedRole}
            setSelectedRole={setSelectedRole}
          />
        )}
      </div>

      {isNotAdmin && (
        <Alert className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You are viewing the users in your restaurant. Contact an administrator to make changes.
          </AlertDescription>
        </Alert>
      )}

      <ResetPasswordDialog 
        isOpen={isResetPasswordDialogOpen}
        onOpenChange={handleCloseResetPasswordDialog}
        onSubmit={handleResetPassword}
        isResetting={isResetting}
      />
      
      <EditProfileDialog 
        isOpen={isEditProfileDialogOpen}
        onOpenChange={handleCloseEditDialog}
        onSubmit={handleUpdateProfile}
        isEditing={isEditing}
        defaultValues={selectedProfileDetails}
      />

      <UserTable 
        users={users || []}
        isNotAdmin={!!isNotAdmin}
        getInitials={getInitials}
        openEditProfileDialog={openEditProfileDialog}
        openResetPasswordDialog={openResetPasswordDialog}
        changeUserRole={changeUserRole}
        roleOptions={roleOptions}
        currentUserId={profile?.pro_id}
      />
    </div>
  );
};

export default Users;
