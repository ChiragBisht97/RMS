import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowUpRight, DollarSign, ShoppingCart, Users, ArrowRight, ActivitySquare, RefreshCw } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useDashboardData } from '@/hooks/useDashboardData';
import { formatTimeAgo } from '@/utils/orders';
import { formatCurrency } from '@/utils/formatCurrency';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, CartesianGrid, XAxis, YAxis } from 'recharts';

const Dashboard = () => {
  const { dashboardData, loading, currency, refetchDashboardData } = useDashboardData();

  const COLORS = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'order':
        return <ShoppingCart className="h-4 w-4 mr-2 text-blue-500" />;
      case 'menu':
        return <ActivitySquare className="h-4 w-4 mr-2 text-orange-500" />;
      default:
        return <ArrowRight className="h-4 w-4 mr-2" />;
    }
  };

  const handleRefresh = () => {
    refetchDashboardData();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <Button variant="outline" size="sm" onClick={handleRefresh} className="flex items-center gap-1">
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
              <DollarSign className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-28" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {formatCurrency(dashboardData.totalRevenue, currency)}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center">
                  <ArrowUpRight className="mr-1 h-3 w-3 text-green-500" />
                  <span>+20.1% from last month</span>
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
              <ShoppingCart className="h-4 w-4 text-blue-600" />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold">{dashboardData.totalOrders}</div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center">
                  <ArrowUpRight className="mr-1 h-3 w-3 text-green-500" />
                  <span>+12% from last month</span>
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Order Value</CardTitle>
            <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
              <DollarSign className="h-4 w-4 text-green-600" />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {formatCurrency(dashboardData.averageOrderValue, currency)}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center">
                  <ArrowUpRight className="mr-1 h-3 w-3 text-red-500" />
                  <span>-7.4% from last month</span>
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Tables</CardTitle>
            <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center">
              <Users className="h-4 w-4 text-amber-600" />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {dashboardData.activeTables.active} / {dashboardData.activeTables.total}
                </div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center">
                  <ArrowUpRight className="mr-1 h-3 w-3 text-green-500" />
                  <span>+3% from last month</span>
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader>
            <CardTitle>Revenue</CardTitle>
            <CardDescription>Monthly revenue overview</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : (
              <ChartContainer 
                className="h-[200px]" 
                config={{
                  revenue: { 
                    color: "#4f46e5",
                    label: "Revenue" 
                  }
                }}
              >
                <BarChart data={dashboardData.revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                    tickFormatter={(value) => formatCurrency(value, currency)}
                    width={80}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent 
                        formatter={(value) => formatCurrency(Number(value), currency)}
                      />
                    }
                  />
                  <Bar 
                    dataKey="revenue" 
                    fill="var(--color-revenue)" 
                    radius={[4, 4, 0, 0]}
                    name="Revenue" 
                  />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader>
            <CardTitle>Daily Orders</CardTitle>
            <CardDescription>Orders placed per day</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : (
              <ChartContainer 
                className="h-[200px]" 
                config={{
                  orders: { 
                    color: "#10b981",
                    label: "Orders" 
                  }
                }}
              >
                <LineChart data={dashboardData.dailyOrdersData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                    width={30}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent />
                    }
                  />
                  <Line 
                    type="monotone" 
                    dataKey="orders" 
                    stroke="var(--color-orders)" 
                    strokeWidth={2} 
                    dot={{ fill: 'var(--color-orders)', r: 4 }}
                    activeDot={{ r: 6 }}
                    name="Orders" 
                  />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader>
            <CardTitle>Category Popularity</CardTitle>
            <CardDescription>Distribution of orders by category</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : dashboardData.categoryData.length > 0 ? (
              <ChartContainer 
                className="h-[300px]" 
                config={
                  dashboardData.categoryData.reduce((acc, item, index) => {
                    acc[item.name] = { color: COLORS[index % COLORS.length] };
                    return acc;
                  }, {})
                }
              >
                <PieChart>
                  <Pie
                    data={dashboardData.categoryData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    innerRadius={60}
                    fill="#8884d8"
                    paddingAngle={2}
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    labelLine={false}
                  >
                    {dashboardData.categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <ChartTooltip 
                    content={
                      <ChartTooltipContent
                        formatter={(value) => `${value}%`}
                      />
                    }
                  />
                </PieChart>
              </ChartContainer>
            ) : (
              <div className="text-center py-16 text-muted-foreground">No category data available.</div>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader>
            <CardTitle>Table Performance</CardTitle>
            <CardDescription>Performance metrics for each table</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : dashboardData.performanceData.length > 0 ? (
              <ChartContainer 
                className="h-[300px]" 
                config={{
                  performance: { 
                    color: "#0ea5e9",
                    label: "Performance" 
                  }
                }}
              >
                <BarChart data={dashboardData.performanceData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#e5e7eb" />
                  <XAxis 
                    type="number" 
                    domain={[0, 100]} 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                  />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                    width={80}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent 
                        formatter={(value) => `${value}%`}
                      />
                    }
                  />
                  <Bar 
                    dataKey="performance" 
                    fill="var(--color-performance)" 
                    radius={[0, 4, 4, 0]}
                    name="Performance" 
                  />
                </BarChart>
              </ChartContainer>
            ) : (
              <div className="text-center py-16 text-muted-foreground">No table performance data available.</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest activities in your restaurant</CardDescription>
        </CardHeader>
        <CardContent className="pl-2">
          <ul className="list-none space-y-3">
            {loading ? (
              <>
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </>
            ) : dashboardData.recentActivity.length > 0 ? (
              dashboardData.recentActivity.map((activity) => (
                <li key={activity.id} className="flex items-center p-2 hover:bg-accent/10 rounded-md transition-colors">
                  <div className="p-2 rounded-full bg-primary/10 mr-2">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div>
                    <span className="font-medium">{activity.title}</span>
                    <p className="text-muted-foreground text-sm">
                      {activity.description} • {formatTimeAgo(activity.timestamp.toString())}
                    </p>
                  </div>
                </li>
              ))
            ) : (
              <div className="text-center py-16 text-muted-foreground">No recent activity.</div>
            )}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
