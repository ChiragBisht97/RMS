import React, { useState, useEffect } from 'react';
import { TableIcon, Users, History } from 'lucide-react';
import { Sheet } from '@/components/ui/sheet';
import CreateOrderDialog from '@/components/orders/CreateOrderDialog';

// Custom hooks
import { usePOSData } from '@/hooks/usePOSData';
import { useCart } from '@/hooks/useCart';

// Components
import POSHeader from '@/components/pos/POSHeader';
import MenuItemsGrid from '@/components/pos/MenuItemsGrid';
import CartSection from '@/components/pos/CartSection';
import TableSelectionSheet from '@/components/pos/TableSelectionSheet';
import PaymentDialog from '@/components/pos/PaymentDialog';
import OrderHistoryDialog from '@/components/pos/OrderHistoryDialog';
import ItemVariationDialog from '@/components/pos/ItemVariationDialog';
import { Button } from '@/components/ui/button';

const POS = () => {
  const {
    filteredItems,
    tables,
    loading,
    searchQuery,
    setSearchQuery,
    currentTab,
    setCurrentTab,
    categories,
    taxPercentage,
    fetchData
  } = usePOSData();

  const {
    cart,
    selectedTable,
    orderType,
    isCreateOrderOpen,
    setIsCreateOrderOpen,
    subtotal,
    tax,
    serviceCharge,
    total,
    applyServiceCharge,
    serviceChargePercentage,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    handleOrderCreated,
    handleTableSelect,
    setWalkInOrder,
    currentOrder,
    isPaymentModalOpen,
    setIsPaymentModalOpen,
    isLoading,
    processPayment,
    voidLineItem,
    voidOrder
  } = useCart(taxPercentage);

  const [isTablesSheetOpen, setIsTablesSheetOpen] = useState(false);
  const [isOrderHistoryOpen, setIsOrderHistoryOpen] = useState(false);
  
  // Item variation selection state
  const [itemForVariation, setItemForVariation] = useState<any | null>(null);
  const [isVariationDialogOpen, setIsVariationDialogOpen] = useState(false);
  
  useEffect(() => {
    if (isTablesSheetOpen) {
      fetchData();
    }
  }, [isTablesSheetOpen, fetchData]);

  const closeTableSheet = () => {
    setIsTablesSheetOpen(false);
  };

  const renderSelectedOrderType = () => {
    if (orderType === 'walkin' || selectedTable === 'walkin') {
      return (
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-primary" />
          <span>Walk-in Customer</span>
        </div>
      );
    }
    
    if (selectedTable) {
      const table = tables.find(t => t.id === selectedTable);
      return table ? (
        <div className="flex items-center gap-2">
          <TableIcon className="h-4 w-4 text-primary" />
          <span>{table.name}</span>
        </div>
      ) : null;
    }
    
    return <span className="text-muted-foreground">Select a table or walk-in</span>;
  };

  const getSelectedTableName = () => {
    if (selectedTable === 'walkin') {
      return 'Walk-in Customer';
    }
    
    if (selectedTable) {
      const table = tables.find(t => t.id === selectedTable);
      return table ? table.name : '';
    }
    return '';
  };

  const handlePaymentCompleted = (method: 'cash' | 'card' | 'mobile') => {
    processPayment(method);
    fetchData(); // Refresh tables data after payment
  };
  
  const handleOrderCreatedWithRefresh = () => {
    handleOrderCreated();
    fetchData(); // Refresh tables data after order creation
  };

  const getOrderTableId = () => {
    return orderType === 'walkin' ? null : selectedTable;
  };
  
  // Improved item click handler
  const handleMenuItemClick = (item: any) => {
    if (item.variations && item.variations.length > 0) {
      setItemForVariation(item);
      setIsVariationDialogOpen(true);
    } else {
      addToCart(item);
    }
  };
  
  // Improved variation selection handler
  const handleVariationSelect = (item: any, variation: any) => {
    // Generate a unique ID for this item+variation combination
    const variationId = `${item.id}-${variation.size}`;
    
    // Create a modified item with the selected variation and unique ID
    const itemWithVariation = {
      ...item,
      id: variationId, // This ensures each size variation can be added separately to cart
      price: Number(variation.price),
      selectedVariation: variation.size,
      // Add a note with the variation size that will be saved with the order
      notes: `Size: ${variation.size}`
    };
    
    addToCart(itemWithVariation);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <POSHeader 
        isTablesSheetOpen={isTablesSheetOpen}
        setIsTablesSheetOpen={setIsTablesSheetOpen}
        selectedTable={selectedTable}
        orderType={orderType}
        tables={tables}
        taxPercentage={taxPercentage}
        renderSelectedOrderType={renderSelectedOrderType}
      />
      
      <div className="flex justify-end mb-4">
        <Button
          variant="outline"
          onClick={() => setIsOrderHistoryOpen(true)}
          className="flex items-center gap-2"
        >
          <History className="h-4 w-4" />
          Order History
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <MenuItemsGrid 
          loading={loading}
          filteredItems={filteredItems}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          categories={categories}
          addToCart={handleMenuItemClick}
        />
        
        <div>
          <CartSection 
            cart={cart}
            updateQuantity={updateQuantity}
            removeFromCart={removeFromCart}
            clearCart={clearCart}
            subtotal={subtotal}
            tax={tax}
            total={total}
            taxPercentage={taxPercentage}
            setIsCreateOrderOpen={setIsCreateOrderOpen}
            setIsPaymentModalOpen={setIsPaymentModalOpen}
            selectedTable={selectedTable}
            orderType={orderType}
            renderSelectedOrderType={renderSelectedOrderType}
            currentOrder={currentOrder}
            voidLineItem={voidLineItem}
            voidOrder={voidOrder}
            applyServiceCharge={applyServiceCharge}
            serviceChargePercentage={serviceChargePercentage}
            serviceCharge={serviceCharge}
          />
        </div>
      </div>
      
      <Sheet open={isTablesSheetOpen} onOpenChange={setIsTablesSheetOpen}>
        <TableSelectionSheet 
          tables={[
            ...tables,
            ...(currentOrder && currentOrder.table_id === null ? [{
              id: 'walkin',
              name: 'Walk-in Customer',
              status: 'Occupied',
              capacity: 0
            }] : [])
          ]}
          handleTableSelect={handleTableSelect}
          setWalkInOrder={setWalkInOrder}
          onClose={closeTableSheet}
          refreshTables={fetchData}
        />
      </Sheet>
      
      <CreateOrderDialog
        open={isCreateOrderOpen}
        onOpenChange={setIsCreateOrderOpen}
        items={cart}
        onOrderCreated={handleOrderCreatedWithRefresh}
        tableId={getOrderTableId()}
      />
      
      <PaymentDialog
        open={isPaymentModalOpen}
        onOpenChange={setIsPaymentModalOpen}
        onPayment={handlePaymentCompleted}
        orderTotal={total}
        tableNumber={getSelectedTableName()}
        orderId={currentOrder?.order_id}
        isLoading={isLoading}
      />
      
      <OrderHistoryDialog 
        open={isOrderHistoryOpen}
        onOpenChange={setIsOrderHistoryOpen}
      />
      
      <ItemVariationDialog
        open={isVariationDialogOpen}
        onOpenChange={setIsVariationDialogOpen}
        item={itemForVariation}
        onSelectVariation={handleVariationSelect}
      />
    </div>
  );
};

export default POS;
