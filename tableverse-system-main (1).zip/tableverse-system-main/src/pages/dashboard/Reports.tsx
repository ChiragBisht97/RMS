
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useReportsData } from '@/hooks/useReportsData';
import ReportFilters from '@/components/reports/ReportFilters';
import SalesReport from '@/components/reports/SalesReport';
import PopularItemsReport from '@/components/reports/PopularItemsReport';
import CategoryReport from '@/components/reports/CategoryReport';
import TableReport from '@/components/reports/TableReport';
import { Card } from '@/components/ui/card';

const Reports = () => {
  const [currentTab, setCurrentTab] = useState('sales');
  const [dateRange, setDateRange] = useState({
    from: new Date(new Date().setDate(new Date().getDate() - 7)),
    to: new Date()
  });
  const [searchQuery, setSearchQuery] = useState('');
  
  const { reportData, loading, currency } = useReportsData(
    currentTab,
    dateRange.from,
    dateRange.to,
    searchQuery
  );
  
  const handleDateRangeChange = (dates: { from?: Date; to?: Date }) => {
    setDateRange({
      from: dates.from || dateRange.from,
      to: dates.to || dateRange.to
    });
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
  };

  // Create a filters object to match ReportFilters component props
  const filters = {
    startDate: dateRange.from,
    endDate: dateRange.to,
    reportType: currentTab,
    searchQuery: searchQuery
  };

  const handleFilterChange = (newFilters: any) => {
    setDateRange({
      from: newFilters.startDate || dateRange.from,
      to: newFilters.endDate || dateRange.to
    });
    setCurrentTab(newFilters.reportType);
    setSearchQuery(newFilters.searchQuery);
  };

  const handleRunReport = () => {
    // This function can be used to trigger a report refresh if needed
    console.log("Running report with filters:", filters);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
      </div>
      
      <Card className="p-4 overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <ReportFilters 
          filters={filters}
          onFilterChange={handleFilterChange}
          onRunReport={handleRunReport}
        />
      </Card>
      
      <Tabs defaultValue="sales" value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="sales">Sales</TabsTrigger>
          <TabsTrigger value="items">Popular Items</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="tables">Tables</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sales" className="animate-fade-in">
          <SalesReport 
            salesData={reportData.sales.data}
            totalRevenue={reportData.sales.totalRevenue}
            totalOrders={reportData.sales.totalOrders}
            averageOrderValue={reportData.sales.averageOrderValue}
            loading={loading}
            currency={currency}
          />
        </TabsContent>
        
        <TabsContent value="items" className="animate-fade-in">
          <PopularItemsReport 
            items={reportData.popularItems.data}
            loading={loading}
            currency={currency}
          />
        </TabsContent>
        
        <TabsContent value="categories" className="animate-fade-in">
          <CategoryReport 
            categories={reportData.categories.data}
            loading={loading}
            currency={currency}
          />
        </TabsContent>
        
        <TabsContent value="tables" className="animate-fade-in">
          <TableReport 
            tables={reportData.tables.data}
            loading={loading}
            currency={currency}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;
