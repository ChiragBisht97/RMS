import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import KitchenView from '@/components/orders/KitchenView';
import OrderDetails from '@/components/orders/OrderDetails';
import OrdersFilters from '@/components/orders/OrdersFilters';
import OrdersTable from '@/components/orders/OrdersTable';
import { getFilteredOrders, isValidOrderStatus } from '@/components/orders/OrderUtils';
import { supabase } from '@/integrations/supabase/client';
import { Order, OrderStatus, PaymentStatus, OrderWithItems } from '@/types/orders';
import { useAuth } from '@/contexts/AuthContext';

const Orders = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<OrderWithItems | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const { profile } = useAuth();

  const fetchOrders = async () => {
    setLoading(true);
    setIsRefreshing(true);
    
    try {
      if (!profile?.restaurant_id) {
        console.error('No restaurant ID associated with the current user');
        setOrders([]);
        setLoading(false);
        setIsRefreshing(false);
        return;
      }
      
      // Join with tables to get table names and filter by restaurant_id
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          tables:table_id (tb_name)
        `)
        .eq('restaurant_id', profile.restaurant_id) // Filter by restaurant_id
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      // Map the data to the Order type, ensuring status is of type OrderStatus
      const mappedOrders = data.map(order => {
        // Validate that the status is a valid OrderStatus
        let orderStatus: OrderStatus = 'Pending'; // Default fallback
        if (isValidOrderStatus(order.status)) {
          orderStatus = order.status as OrderStatus;
        }
        
        // Set payment status
        let paymentStatus: PaymentStatus = order.payment_status as PaymentStatus || 'Unpaid';
        
        return {
          ...order,
          table_name: order.tables?.tb_name,
          status: orderStatus,
          payment_status: paymentStatus
        };
      });
      
      setOrders(mappedOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast({
        title: 'Error',
        description: 'Failed to load orders',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    
    // Set up real-time subscription for the current restaurant's orders
    const channel = supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        { 
          event: '*', 
          schema: 'public', 
          table: 'orders',
          filter: profile?.restaurant_id ? `restaurant_id=eq.${profile.restaurant_id}` : undefined
        },
        (payload) => {
          console.log('Orders change received:', payload);
          fetchOrders(); // Refresh orders when changes occur
        }
      )
      .subscribe();
      
    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile?.restaurant_id]);

  const viewOrderDetails = async (order: Order) => {
    try {
      const { data: items, error } = await supabase
        .from('order_items')
        .select(`
          *,
          menu_items:menu_item_id (mi_name, mi_description)
        `)
        .eq('order_id', order.order_id);
      
      if (error) throw error;
      
      const mappedItems = items.map(item => ({
        ...item,
        name: item.menu_items?.mi_name,
        description: item.menu_items?.mi_description
      }));
      
      setSelectedOrder({
        ...order,
        items: mappedItems
      });
      
      setIsDetailOpen(true);
    } catch (error) {
      console.error('Error fetching order details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load order details',
        variant: 'destructive'
      });
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const filteredOrders = getFilteredOrders(orders, searchQuery, statusFilter, dateFilter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Orders</h2>
          <p className="text-muted-foreground">
            Manage and view all orders
          </p>
        </div>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={handleTabChange}>
        <TabsList className="flex items-center space-x-4">
          <TabsTrigger value="all" className="relative">
            All Orders
          </TabsTrigger>
          <TabsTrigger value="kitchen">Kitchen View</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <OrdersFilters
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            dateFilter={dateFilter}
            setDateFilter={setDateFilter}
            isRefreshing={isRefreshing}
            onRefresh={fetchOrders}
          />

          <OrdersTable
            orders={filteredOrders}
            loading={loading}
            onViewDetails={viewOrderDetails}
          />
        </TabsContent>
        <TabsContent value="kitchen">
          <KitchenView />
        </TabsContent>
      </Tabs>

      <Dialog open={isDetailOpen} onOpenChange={() => setIsDetailOpen(false)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedOrder && (
            <OrderDetails order={selectedOrder} onClose={() => setIsDetailOpen(false)} onStatusChange={fetchOrders} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Orders;
