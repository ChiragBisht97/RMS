
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import RestaurantInfoForm from '@/components/settings/RestaurantInfoForm';
import RestaurantSettingsForm from '@/components/settings/RestaurantSettingsForm';
import TaxSettingsForm from '@/components/settings/TaxSettingsForm';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Users } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

const Settings = () => {
  const [activeTab, setActiveTab] = useState("restaurant");
  const { profile } = useAuth();
  const [restaurantData, setRestaurantData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  // Only admin and owner can access user management
  const canManageUsers = profile?.is_owner || profile?.pro_role === 'admin';
  const isOwner = profile?.is_owner === true;

  // Fetch restaurant data
  useEffect(() => {
    const fetchRestaurantData = async () => {
      if (!profile?.restaurant_id) return;
      
      try {
        const { data, error } = await supabase
          .from('restaurants')
          .select('*')
          .eq('restaurant_id', profile.restaurant_id)
          .single();
          
        if (error) throw error;
        setRestaurantData(data);
      } catch (error: any) {
        console.error('Error fetching restaurant data:', error);
        toast({
          title: "Failed to load restaurant data",
          description: error.message || "Please try again later",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchRestaurantData();
  }, [profile?.restaurant_id]);

  // Handler for when forms update data
  const handleDataUpdate = () => {
    // Refetch restaurant data after update
    if (profile?.restaurant_id) {
      setLoading(true);
      supabase
        .from('restaurants')
        .select('*')
        .eq('restaurant_id', profile.restaurant_id)
        .single()
        .then(({ data, error }) => {
          if (!error && data) {
            setRestaurantData(data);
          }
          setLoading(false);
        });
    }
  };

  if (loading) {
    return (
      <div className="container p-6 mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Settings</h1>
        </div>
        <Card className="w-full p-8 flex justify-center items-center">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
          <p className="ml-3">Loading settings...</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="container p-6 mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        
        {canManageUsers && (
          <Link to="/dashboard/user-management">
            <Button className="flex items-center gap-2">
              <Users size={16} />
              User Permissions
            </Button>
          </Link>
        )}
      </div>

      <Card className="w-full">
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="restaurant">Restaurant Info</TabsTrigger>
            <TabsTrigger value="tax">Tax Settings</TabsTrigger>
            <TabsTrigger value="settings">System Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="restaurant" className="p-4">
            {restaurantData && (
              <RestaurantInfoForm 
                initialData={restaurantData}
                isOwner={isOwner}
                onUpdate={handleDataUpdate}
              />
            )}
          </TabsContent>
          
          <TabsContent value="tax" className="p-4">
            {restaurantData && (
              <TaxSettingsForm 
                restaurantId={restaurantData.restaurant_id}
                isOwner={isOwner}
                onUpdate={handleDataUpdate}
              />
            )}
          </TabsContent>
          
          <TabsContent value="settings" className="p-4">
            {restaurantData && (
              <RestaurantSettingsForm 
                restaurantId={restaurantData.restaurant_id}
                isOwner={isOwner}
                onUpdate={handleDataUpdate}
              />
            )}
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
};

export default Settings;
