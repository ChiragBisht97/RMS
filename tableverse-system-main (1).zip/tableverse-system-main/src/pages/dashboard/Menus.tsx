
import React, { useState } from 'react';
import { Sheet } from '@/components/ui/sheet';

// Hooks
import { useMenuData } from '@/hooks/useMenuData';
import { useMenuActions } from '@/hooks/useMenuActions';

// Component imports
import MenuHeader from '@/components/menus/MenuHeader';
import MenuSearch from '@/components/menus/MenuSearch';
import CategoryTabs from '@/components/menus/CategoryTabs';
import MenuGrid from '@/components/menus/MenuGrid';
import CategorySheet from '@/components/menus/CategorySheet';
import MenuCategoryDialog from '@/components/menus/MenuCategoryDialog';
import MenuItemDialog from '@/components/menus/MenuItemDialog';
import DeleteConfirmationDialogs from '@/components/menus/DeleteConfirmationDialogs';

const Menus = () => {
  // Get menu data and filtering functionality
  const {
    filteredItems,
    isLoading,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    categories,
    fetchMenuItems,
    fetchCategories,
    updateCategoriesOrder
  } = useMenuData();

  // Sheet state
  const [categoriesSheetOpen, setCategoriesSheetOpen] = useState(false);
  
  // Actions for menu items and categories
  const {
    selectedItem,
    selectedCategoryForEdit,
    categoryDialogOpen,
    setCategoryDialogOpen,
    itemDialogOpen,
    setItemDialogOpen,
    deleteDialogOpen,
    setDeleteDialogOpen,
    itemToDelete,
    categoryDeleteDialogOpen,
    setCategoryDeleteDialogOpen,
    categoryToDelete,
    handleAddItem,
    handleEditItem,
    handleAddCategory,
    handleEditCategory,
    confirmDeleteItem,
    handleDeleteItem,
    confirmDeleteCategory,
    handleDeleteCategory,
    toggleStockStatus,
    isDeleting
  } = useMenuActions(() => {
    // Refresh data after successful operations
    fetchMenuItems();
    fetchCategories();
    
    // If the categories sheet is open, ensure it's properly updated
    if (categoriesSheetOpen) {
      setCategoriesSheetOpen(false);
      setTimeout(() => setCategoriesSheetOpen(true), 100);
    }
  });

  return (
    <div className="space-y-8 animate-fade-in">
      <MenuHeader 
        handleAddItem={handleAddItem}
        categoriesSheetOpen={categoriesSheetOpen}
        setCategoriesSheetOpen={setCategoriesSheetOpen}
      />
      
      <MenuSearch 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />
      
      <CategoryTabs 
        selectedCategory={selectedCategory} 
        setSelectedCategory={setSelectedCategory}
        categories={categories}
      >
        <MenuGrid 
          isLoading={isLoading}
          filteredItems={filteredItems}
          searchQuery={searchQuery}
          handleAddItem={handleAddItem}
          handleEditItem={handleEditItem}
          confirmDeleteItem={confirmDeleteItem}
          toggleStockStatus={toggleStockStatus}
        />
      </CategoryTabs>
      
      <Sheet open={categoriesSheetOpen} onOpenChange={setCategoriesSheetOpen}>
        <CategorySheet 
          categories={categories}
          handleAddCategory={handleAddCategory}
          handleEditCategory={handleEditCategory}
          confirmDeleteCategory={confirmDeleteCategory}
          updateCategoriesOrder={updateCategoriesOrder}
        />
      </Sheet>
      
      <MenuCategoryDialog 
        open={categoryDialogOpen} 
        onOpenChange={setCategoryDialogOpen}
        onSuccess={() => {
          fetchCategories();
          fetchMenuItems();
        }}
        category={selectedCategoryForEdit ? {
          id: selectedCategoryForEdit.id,
          name: selectedCategoryForEdit.name,
          description: selectedCategoryForEdit.description,
        } : null}
      />
      
      <MenuItemDialog 
        open={itemDialogOpen} 
        onOpenChange={setItemDialogOpen}
        onSuccess={() => fetchMenuItems()}
        item={selectedItem ? {
          id: selectedItem.id,
          name: selectedItem.name,
          description: selectedItem.description,
          price: selectedItem.price,
          imageUrl: selectedItem.imageUrl,
          categoryId: selectedItem.categoryId,
          inStock: selectedItem.inStock,
          attributes: selectedItem.attributes,
          variations: selectedItem.variations,
        } : null}
        categories={categories}
      />
      
      <DeleteConfirmationDialogs
        deleteDialogOpen={deleteDialogOpen}
        setDeleteDialogOpen={setDeleteDialogOpen}
        itemToDelete={itemToDelete}
        handleDeleteItem={handleDeleteItem}
        categoryDeleteDialogOpen={categoryDeleteDialogOpen}
        setCategoryDeleteDialogOpen={setCategoryDeleteDialogOpen}
        categoryToDelete={categoryToDelete}
        handleDeleteCategory={handleDeleteCategory}
        isDeleting={isDeleting}
      />
    </div>
  );
};

export default Menus;
