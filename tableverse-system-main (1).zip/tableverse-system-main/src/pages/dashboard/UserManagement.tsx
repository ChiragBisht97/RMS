
import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Loader2, AlertCircle } from "lucide-react";
import { toast as sonnerToast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { fetchUserPermissions, updateUserPermission } from "@/utils/supabaseHelpers";
import { supabase } from "@/integrations/supabase/client";
import PermissionsTable from "@/components/user-management/PermissionsTable";
import { PermissionModule, UserWithPermissions } from "@/components/user-management/types";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Define the permission modules
const PERMISSION_MODULES: PermissionModule[] = [
  { id: "menus", name: "Menus", description: "Manage restaurant menus and items" },
  { id: "orders", name: "Orders", description: "View and manage customer orders" },
  { id: "tables", name: "Tables", description: "Manage restaurant tables and seating" },
  { id: "pos", name: "Point of Sale", description: "Access the POS system" },
  { id: "customer_order", name: "Customer Order", description: "Handle customer ordering system" },
  { id: "reports", name: "Reports", description: "Access sales and analytics reports" },
];

const UserManagement = () => {
  const { toast } = useToast();
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();
  const [isUpdating, setIsUpdating] = useState<Record<string, boolean>>({});

  // Check if current user is admin or owner
  const isAdminOrOwner = profile?.is_owner || profile?.pro_role === 'admin';

  // Fetch users with their permissions
  const { data: users, isLoading, refetch } = useQuery({
    queryKey: ["users-with-permissions"],
    queryFn: async () => {
      try {
        if (!profile?.restaurant_id) {
          console.log("No restaurant ID available in profile");
          return [];
        }
        
        console.log("Fetching profiles for restaurant:", profile.restaurant_id);
        
        // First get all profiles for this restaurant
        const { data: profiles, error: profilesError } = await supabase
          .from("profiles")
          .select("*")
          .eq("restaurant_id", profile.restaurant_id);

        if (profilesError) {
          console.error("Error fetching profiles:", profilesError);
          throw profilesError;
        }

        if (!profiles || profiles.length === 0) {
          console.log("No profiles returned for restaurant");
          return [];
        }
        
        console.log("Fetched profiles for permissions:", profiles.length);

        // For each profile, get their permissions
        const usersWithPermissions: UserWithPermissions[] = await Promise.all(
          profiles.map(async (profile) => {
            // Get permissions using the helper function
            const permissions = await fetchUserPermissions(profile.pro_id) || {};
            
            // Initialize with default permissions
            const permissionsWithDefaults: Record<string, boolean> = {};
            PERMISSION_MODULES.forEach(module => {
              // Owners and admins have access to everything by default
              permissionsWithDefaults[module.id] = profile.is_owner || profile.pro_role === 'admin';
            });
            
            // Override with stored permissions
            Object.assign(permissionsWithDefaults, permissions);

            return {
              ...profile,
              permissions: permissionsWithDefaults,
            };
          })
        );

        console.log("Users with permissions:", usersWithPermissions.length);
        return usersWithPermissions;
      } catch (error: any) {
        console.error("Error fetching users with permissions:", error);
        toast({
          title: "Error fetching users",
          description: error.message,
          variant: "destructive",
        });
        return [];
      }
    },
    enabled: !!profile?.restaurant_id,
    staleTime: 30000 // Refetch after 30 seconds to keep data fresh
  });

  // Force refetch on component mount to ensure we have the latest data
  useEffect(() => {
    if (profile?.restaurant_id) {
      refetch();
    }
  }, [profile?.restaurant_id, refetch]);

  // Update user permission mutation
  const updatePermissionMutation = useMutation({
    mutationFn: async ({
      userId,
      module,
      enabled,
    }: {
      userId: string;
      module: string;
      enabled: boolean;
    }) => {
      // Mark this user/module combination as updating
      setIsUpdating(prev => ({ ...prev, [`${userId}-${module}`]: true }));
      
      try {
        const success = await updateUserPermission(userId, module, enabled);
        if (!success) throw new Error("Failed to update permission");
        
        return { userId, module, enabled };
      } finally {
        // Clear updating state
        setIsUpdating(prev => {
          const updated = { ...prev };
          delete updated[`${userId}-${module}`];
          return updated;
        });
      }
    },
    onSuccess: (data) => {
      // Update the cache optimistically
      queryClient.setQueryData(
        ["users-with-permissions"],
        (oldData: UserWithPermissions[] | undefined) => {
          if (!oldData) return [];
          
          return oldData.map((user) => {
            if (user.pro_id === data.userId) {
              return {
                ...user,
                permissions: {
                  ...user.permissions,
                  [data.module]: data.enabled,
                },
              };
            }
            return user;
          });
        }
      );
      
      sonnerToast.success("Permission updated", {
        description: `Module access has been ${data.enabled ? "granted" : "revoked"}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update permission",
        description: error.message || "An unknown error occurred",
        variant: "destructive",
      });
    },
  });

  const handleTogglePermission = (userId: string, module: string, currentValue: boolean) => {
    if (!isAdminOrOwner) {
      toast({
        title: "Permission denied",
        description: "Only administrators can modify user permissions",
        variant: "destructive",
      });
      return;
    }
    
    updatePermissionMutation.mutate({
      userId,
      module,
      enabled: !currentValue,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="w-full">
      <Card className="w-full">
        <CardHeader>
          <CardTitle>User Module Permissions</CardTitle>
          <CardDescription>
            Manage which modules each user can access in the system
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isAdminOrOwner && (
            <Alert className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                You are viewing the permissions in your restaurant. Only administrators can modify permissions.
              </AlertDescription>
            </Alert>
          )}
          
          <PermissionsTable
            users={users || []}
            permissionModules={PERMISSION_MODULES}
            isUpdating={isUpdating}
            currentUserId={profile?.pro_id}
            onTogglePermission={handleTogglePermission}
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;
