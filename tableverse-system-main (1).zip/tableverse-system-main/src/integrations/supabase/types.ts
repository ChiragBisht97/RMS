export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      menu_categories: {
        Row: {
          mc_created_at: string
          mc_description: string | null
          mc_id: string
          mc_name: string
          mc_order: number | null
          mc_updated_at: string
          restaurant_id: string | null
        }
        Insert: {
          mc_created_at?: string
          mc_description?: string | null
          mc_id?: string
          mc_name: string
          mc_order?: number | null
          mc_updated_at?: string
          restaurant_id?: string | null
        }
        Update: {
          mc_created_at?: string
          mc_description?: string | null
          mc_id?: string
          mc_name?: string
          mc_order?: number | null
          mc_updated_at?: string
          restaurant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "menu_categories_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["restaurant_id"]
          },
        ]
      }
      menu_items: {
        Row: {
          mi_active: boolean
          mi_attributes: Json | null
          mi_category_id: string | null
          mi_created_at: string
          mi_description: string | null
          mi_id: string
          mi_image_url: string | null
          mi_in_stock: boolean | null
          mi_name: string
          mi_price: number
          mi_updated_at: string
          mi_variations: Json | null
          restaurant_id: string | null
        }
        Insert: {
          mi_active?: boolean
          mi_attributes?: Json | null
          mi_category_id?: string | null
          mi_created_at?: string
          mi_description?: string | null
          mi_id?: string
          mi_image_url?: string | null
          mi_in_stock?: boolean | null
          mi_name: string
          mi_price: number
          mi_updated_at?: string
          mi_variations?: Json | null
          restaurant_id?: string | null
        }
        Update: {
          mi_active?: boolean
          mi_attributes?: Json | null
          mi_category_id?: string | null
          mi_created_at?: string
          mi_description?: string | null
          mi_id?: string
          mi_image_url?: string | null
          mi_in_stock?: boolean | null
          mi_name?: string
          mi_price?: number
          mi_updated_at?: string
          mi_variations?: Json | null
          restaurant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "menu_items_mi_category_id_fkey"
            columns: ["mi_category_id"]
            isOneToOne: false
            referencedRelation: "menu_categories"
            referencedColumns: ["mc_id"]
          },
          {
            foreignKeyName: "menu_items_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["restaurant_id"]
          },
        ]
      }
      order_items: {
        Row: {
          created_at: string | null
          item_id: string
          menu_item_id: string | null
          notes: string | null
          order_id: string | null
          price: number
          quantity: number
        }
        Insert: {
          created_at?: string | null
          item_id?: string
          menu_item_id?: string | null
          notes?: string | null
          order_id?: string | null
          price: number
          quantity?: number
        }
        Update: {
          created_at?: string | null
          item_id?: string
          menu_item_id?: string | null
          notes?: string | null
          order_id?: string | null
          price?: number
          quantity?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_menu_item_id_fkey"
            columns: ["menu_item_id"]
            isOneToOne: false
            referencedRelation: "menu_items"
            referencedColumns: ["mi_id"]
          },
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["order_id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string | null
          customer_name: string | null
          customer_phone: string | null
          items_count: number
          order_id: string
          payment_status: string
          restaurant_id: string | null
          status: string
          table_id: string | null
          total: number
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          items_count?: number
          order_id?: string
          payment_status?: string
          restaurant_id?: string | null
          status?: string
          table_id?: string | null
          total?: number
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          items_count?: number
          order_id?: string
          payment_status?: string
          restaurant_id?: string | null
          status?: string
          table_id?: string | null
          total?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "orders_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["restaurant_id"]
          },
          {
            foreignKeyName: "orders_table_id_fkey"
            columns: ["table_id"]
            isOneToOne: false
            referencedRelation: "tables"
            referencedColumns: ["tb_id"]
          },
        ]
      }
      profiles: {
        Row: {
          is_owner: boolean | null
          pro_avatar_url: string | null
          pro_created_at: string
          pro_first_name: string | null
          pro_id: string
          pro_last_name: string | null
          pro_role: string | null
          pro_updated_at: string
          restaurant_id: string | null
        }
        Insert: {
          is_owner?: boolean | null
          pro_avatar_url?: string | null
          pro_created_at?: string
          pro_first_name?: string | null
          pro_id: string
          pro_last_name?: string | null
          pro_role?: string | null
          pro_updated_at?: string
          restaurant_id?: string | null
        }
        Update: {
          is_owner?: boolean | null
          pro_avatar_url?: string | null
          pro_created_at?: string
          pro_first_name?: string | null
          pro_id?: string
          pro_last_name?: string | null
          pro_role?: string | null
          pro_updated_at?: string
          restaurant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["restaurant_id"]
          },
        ]
      }
      restaurants: {
        Row: {
          active: boolean
          address: string | null
          created_at: string | null
          logo_url: string | null
          name: string
          phone: string | null
          restaurant_id: string
          updated_at: string | null
        }
        Insert: {
          active?: boolean
          address?: string | null
          created_at?: string | null
          logo_url?: string | null
          name: string
          phone?: string | null
          restaurant_id?: string
          updated_at?: string | null
        }
        Update: {
          active?: boolean
          address?: string | null
          created_at?: string | null
          logo_url?: string | null
          name?: string
          phone?: string | null
          restaurant_id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      settings: {
        Row: {
          created_at: string | null
          id: string
          restaurant_id: string | null
          setting_key: string
          setting_value: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          restaurant_id?: string | null
          setting_key: string
          setting_value: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          restaurant_id?: string | null
          setting_key?: string
          setting_value?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "settings_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["restaurant_id"]
          },
        ]
      }
      tables: {
        Row: {
          restaurant_id: string | null
          tb_capacity: number
          tb_created_at: string
          tb_id: string
          tb_location: string | null
          tb_name: string
          tb_qr_code: string | null
          tb_status: string
          tb_updated_at: string
        }
        Insert: {
          restaurant_id?: string | null
          tb_capacity: number
          tb_created_at?: string
          tb_id?: string
          tb_location?: string | null
          tb_name: string
          tb_qr_code?: string | null
          tb_status?: string
          tb_updated_at?: string
        }
        Update: {
          restaurant_id?: string | null
          tb_capacity?: number
          tb_created_at?: string
          tb_id?: string
          tb_location?: string | null
          tb_name?: string
          tb_qr_code?: string | null
          tb_status?: string
          tb_updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tables_restaurant_id_fkey"
            columns: ["restaurant_id"]
            isOneToOne: false
            referencedRelation: "restaurants"
            referencedColumns: ["restaurant_id"]
          },
        ]
      }
      user_permissions: {
        Row: {
          created_at: string
          enabled: boolean
          id: string
          module: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: string
          module: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: string
          module?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_restaurant_and_assign_user: {
        Args: {
          restaurant_name: string
          restaurant_address: string
          restaurant_phone: string
          user_id: string
        }
        Returns: string
      }
      get_user_restaurant: {
        Args: { user_id: string }
        Returns: {
          restaurant_id: string
          name: string
          address: string
          phone: string
          logo_url: string
          active: boolean
          created_at: string
          updated_at: string
          is_owner: boolean
        }[]
      }
      invite_user_to_restaurant: {
        Args: {
          email: string
          first_name: string
          last_name: string
          role: string
          inviter_id: string
        }
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
