
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';
import { useAuthState } from '@/hooks/useAuthState';
import { signInUser, signUpUser, signOutUser, inviteUserByEmail } from '@/utils/auth.utils';
import { SignInData, SignUpData, RestaurantData } from '@/types/auth.types';
import { supabase } from '@/integrations/supabase/client';

// Helper function to check if a route is public
export const isPublicRouteOrOrderPage = (path: string): boolean => {
  const publicRoutes = ['/', '/login', '/landing', '/signup', '/auth', '/privacy', '/terms', '/pricing'];
  
  if (path.startsWith('/order/')) {
    console.log('Public route detected: order page');
    return true;
  }
  
  const isPublic = publicRoutes.includes(path);
  console.log(`Path ${path} is${isPublic ? '' : ' not'} a public route`);
  return isPublic;
};

// Create the context
export type AuthContextType = {
  user: any;
  profile: any;
  loading: boolean;
  signIn: (data: SignInData) => Promise<void>;
  signUp: (data: SignUpData) => Promise<void>;
  signOut: () => Promise<void>;
  inviteUser: (email: string, role: string) => Promise<void>;
  authChecked: boolean;
  createRestaurant: (data: RestaurantData) => Promise<string | undefined>;
  isRestaurantDialogOpen: boolean;
  setIsRestaurantDialogOpen: (open: boolean) => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Define the provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, session, profile, loading, authChecked } = useAuthState();
  const [isRestaurantDialogOpen, setIsRestaurantDialogOpen] = useState(false);
  
  useEffect(() => {
    if (profile && !profile.restaurant_id && !isRestaurantDialogOpen) {
      setIsRestaurantDialogOpen(true);
    }
    
    if (profile) {
      console.log("Profile loaded in AuthContext:", profile);
    }
  }, [profile, isRestaurantDialogOpen]);
  
  useEffect(() => {
    const isPublic = isPublicRouteOrOrderPage(location.pathname);
    
    console.log("Auth state loaded:", { 
      isAuthenticated: !!user, 
      userEmail: user?.email, 
      userProfile: profile,
      currentPath: location.pathname,
      isPublic
    });
  }, [user, profile, location.pathname]);
  
  const createRestaurant = async (data: RestaurantData): Promise<string | undefined> => {
    try {
      if (!user) {
        throw new Error("You must be logged in to create a restaurant");
      }
      
      const { data: restaurantData, error: restaurantError } = await supabase
        .from('restaurants')
        .insert({
          name: data.name,
          address: data.address,
          phone: data.phone
        })
        .select('restaurant_id')
        .single();
      
      if (restaurantError) {
        throw restaurantError;
      }
      
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ 
          restaurant_id: restaurantData.restaurant_id,
          is_owner: true 
        })
        .eq('pro_id', user.id);
      
      if (profileError) {
        throw profileError;
      }
      
      toast({
        title: "Restaurant Created",
        description: `${data.name} has been successfully set up!`,
      });
      
      setIsRestaurantDialogOpen(false);
      
      window.location.reload();
      
      return restaurantData.restaurant_id;
    } catch (error: any) {
      console.error("Create restaurant failed:", error.message);
      toast({
        title: "Failed to create restaurant",
        description: error.message || "An error occurred while creating the restaurant",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const signIn = async (data: SignInData): Promise<void> => {
    try {
      const { session, user } = await signInUser(data);
      
      if (!session || !user) {
        throw new Error("Failed to sign in");
      }
      
      localStorage.setItem('auth.timestamp', Date.now().toString());
      localStorage.setItem('auth.rememberMe', data.rememberMe ? 'true' : 'false');
      
      toast({
        title: "Login successful",
        description: "You've been successfully logged in.",
      });
      
      setTimeout(() => {
        console.log("Redirecting to dashboard after successful login");
        navigate('/dashboard');
      }, 500);
    } catch (error: any) {
      console.error("Login failed:", error.message);
      toast({
        title: "Login failed",
        description: error.message || "An error occurred during login",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const signUp = async (data: SignUpData): Promise<void> => {
    try {
      await signUpUser(data);
      
      toast({
        title: "Registration successful",
        description: "Please check your email to verify your account.",
      });
      
      navigate('/login');
    } catch (error: any) {
      console.error("Registration failed:", error.message);
      toast({
        title: "Registration failed",
        description: error.message || "An error occurred during registration",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const signOut = async (): Promise<void> => {
    try {
      await signOutUser();
      navigate('/login');
    } catch (error: any) {
      console.error("Sign out failed:", error.message);
      toast({
        title: "Sign out failed",
        description: error.message || "An error occurred while signing out",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const inviteUser = async (email: string, role: string): Promise<void> => {
    try {
      if (!user) {
        throw new Error("You must be logged in to invite users");
      }
      
      // Extract a name from the email address as a fallback
      const emailName = email.split('@')[0];
      const firstName = emailName || "New";
      const lastName = "User";
      
      await inviteUserByEmail(email, firstName, lastName, role, user.id);
      
      toast({
        title: "Invitation sent",
        description: `An invitation has been sent to ${email}`,
      });
    } catch (error: any) {
      console.error("Invitation failed:", error.message);
      toast({
        title: "Invitation failed",
        description: error.message || "An error occurred while sending the invitation",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  const contextValue: AuthContextType = {
    user,
    profile,
    loading,
    signIn,
    signUp,
    signOut,
    inviteUser,
    authChecked,
    createRestaurant,
    isRestaurantDialogOpen,
    setIsRestaurantDialogOpen,
  };
  
  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  
  return context;
};
