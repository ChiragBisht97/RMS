
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Clear any stale auth data on startup
console.log('Application starting - checking for stale auth data');

// More robust approach to auth data cleaning
const clearStaleAuthData = () => {
  try {
    // If there are errors during login that prevent proper auth flow,
    // clear all auth-related storage to start fresh
    if (window.location.pathname === '/login' && 
        (window.location.search.includes('error') || 
        window.location.hash.includes('error'))) {
      console.log('Detected error in login URL, clearing all auth data');
      localStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('auth.timestamp');
      localStorage.removeItem('auth.session.minimal');
      localStorage.removeItem('auth.rememberMe');
      sessionStorage.removeItem('supabase.auth.token');
      return;
    }
    
    // Check if the current path is a public route
    const isLoginPath = window.location.pathname === '/login';
    const isPublicPath = ['/landing', '/order', '/pricing', '/terms', '/privacy', '/'].some(
      path => window.location.pathname.startsWith(path)
    );
    
    // Don't clear auth data for public paths unless it's explicitly a login page
    if (isPublicPath && !isLoginPath) {
      console.log('Public path detected, not clearing auth data');
      return;
    }
    
    // Check for Supabase credentials directly - if they exist but session data doesn't 
    // match, there could be a conflict that's causing the loading issue
    const hasSupabaseToken = !!localStorage.getItem('sb-manbzlnzgpexyzsuvfek-auth-token');
    const hasMinimalSession = !!localStorage.getItem('auth.session.minimal');
    
    // If we have a Supabase token but no minimal session data (or vice versa),
    // clear everything to resolve potential conflicts
    if (hasSupabaseToken !== hasMinimalSession) {
      console.log('Detected potential auth data conflict, resetting...');
      localStorage.removeItem('sb-manbzlnzgpexyzsuvfek-auth-token');
      localStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('auth.timestamp');
      localStorage.removeItem('auth.session.minimal');
      localStorage.removeItem('auth.rememberMe');
      sessionStorage.removeItem('supabase.auth.token');
      return;
    }
    
    // Attempt to restore session from minimal session data if possible
    const minimalSessionStr = localStorage.getItem('auth.session.minimal');
    if (minimalSessionStr) {
      try {
        const minimalSession = JSON.parse(minimalSessionStr);
        const now = Math.floor(Date.now() / 1000);
        
        // If session isn't expired yet, make sure we have the tokens needed
        if (minimalSession.expiresAt && minimalSession.expiresAt > now) {
          console.log('Found valid minimal session, not clearing auth data');
          return;
        } else {
          console.log('Minimal session is expired, clearing auth data');
          localStorage.removeItem('sb-manbzlnzgpexyzsuvfek-auth-token');
          localStorage.removeItem('supabase.auth.token');
          localStorage.removeItem('auth.timestamp');
          localStorage.removeItem('auth.session.minimal');
          localStorage.removeItem('auth.rememberMe');
          sessionStorage.removeItem('supabase.auth.token');
        }
      } catch (e) {
        console.error('Error parsing minimal session data:', e);
      }
    }
    
    // Only check timestamp if no valid minimal session was found
    if (!minimalSessionStr) {
      // Check if there's a timestamp stored for the last login
      const lastLogin = localStorage.getItem('auth.timestamp');
      const rememberMe = localStorage.getItem('auth.rememberMe') === 'true';
      const now = Date.now();
      
      // If rememberMe is true, keep session for 7 days, otherwise 1 day
      const maxAge = rememberMe ? 7 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000; // 7 days or 1 day
      
      // If no timestamp or more than the allowed time has passed since last login
      if (!lastLogin || (now - parseInt(lastLogin)) > maxAge) {
        console.log('Clearing stale auth data - session expired or missing timestamp');
        localStorage.removeItem('sb-manbzlnzgpexyzsuvfek-auth-token');
        localStorage.removeItem('supabase.auth.token');
        localStorage.removeItem('auth.timestamp');
        localStorage.removeItem('auth.session.minimal');
        localStorage.removeItem('auth.rememberMe');
        sessionStorage.removeItem('supabase.auth.token');
      } else {
        console.log('Auth data is fresh, last login:', new Date(parseInt(lastLogin)).toLocaleString());
        console.log('Session will expire:', rememberMe ? '7 days after login' : '1 day after login');
      }
    }
  } catch (error) {
    console.error('Error checking stale auth data:', error);
  }
};

// Run cleanup before mounting the app
clearStaleAuthData();

// Add error handling to root rendering
try {
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error("Root element not found in document");
  }
  
  const root = createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
  
  console.log("Application successfully rendered");
} catch (error) {
  console.error("Failed to render application:", error);
  // Display a fallback error message on the page
  document.body.innerHTML = `
    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; font-family: sans-serif; text-align: center; padding: 20px;">
      <h1 style="color: #e11d48; margin-bottom: 16px;">Something went wrong</h1>
      <p style="max-width: 500px; margin-bottom: 24px;">We encountered an error while loading the application. Please try refreshing the page or clearing your browser cache.</p>
      <button onclick="window.location.reload()" style="background: #2563eb; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">
        Refresh Page
      </button>
    </div>
  `;
}
