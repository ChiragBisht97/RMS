
export const formatCurrency = (amount: number | string, currencySymbol: string = '₹'): string => {
  // Check if we have a valid currency symbol, log it for debugging
  console.log(`formatCurrency called with symbol: "${currencySymbol}"`);
  
  // Always ensure a valid currency symbol by providing a default if empty
  const symbol = currencySymbol && currencySymbol.trim() ? currencySymbol.trim() : '₹';
  
  const numericAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  
  if (isNaN(numericAmount)) {
    console.log(`formatCurrency: Invalid amount ${amount}, using 0`);
    return `${symbol}0.00`;
  }
  
  // This is now just for logging, not forcing a refresh
  console.log(`Formatting ${numericAmount} with currency symbol: ${symbol}`);
  
  return `${symbol}${numericAmount.toFixed(2)}`;
};

export const calculateOrderTotals = (
  subtotal: number,
  taxPercentage: number = 8,
  serviceChargePercentage: number = 0,
  applyServiceCharge: boolean = false
) => {
  // Calculate tax
  const tax = subtotal * (taxPercentage / 100);
  
  // Calculate service charge (only if enabled)
  const serviceCharge = applyServiceCharge ? subtotal * (serviceChargePercentage / 100) : 0;
  
  // Calculate total (subtotal + tax + service charge)
  const total = subtotal + tax + serviceCharge;
  
  return {
    subtotal,
    tax,
    serviceCharge,
    total
  };
};
