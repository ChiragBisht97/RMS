
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { SignInData, SignUpData } from '@/types/auth.types';

export const fetchUserProfile = async (userId: string) => {
  try {
    console.log('Fetching user profile for ID:', userId);
    
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('pro_id', userId)
      .maybeSingle();
    
    if (profileError) {
      console.error('Profile fetch error:', profileError);
      throw profileError;
    }
    
    console.log('Profile data fetched:', profileData);
    
    if (profileData && profileData.restaurant_id) {
      const { data: restaurantData, error: restaurantError } = await supabase
        .from('restaurants')
        .select('*')
        .eq('restaurant_id', profileData.restaurant_id)
        .maybeSingle();
      
      if (restaurantError) {
        console.error('Restaurant fetch error:', restaurantError);
        throw restaurantError;
      }
      
      console.log('Restaurant data fetched:', restaurantData);
      
      // Combine profile and restaurant data
      const enrichedProfileData = {
        ...profileData,
        restaurant_name: restaurantData?.name,
        restaurant_address: restaurantData?.address,
        restaurant_phone: restaurantData?.phone,
        restaurant_logo: restaurantData?.logo_url,
        subscription_status: 'trial',
        trial_days_left: 14
      };
      
      console.log('Enriched profile data:', enrichedProfileData);
      return enrichedProfileData;
    }
    
    return profileData;
  } catch (error) {
    console.error('Error fetching profile:', error);
    return null;
  }
};

export const signUpUser = async (data: SignUpData) => {
  try {
    // Create the user account with metadata that the trigger will use
    const { data: authData, error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          first_name: data.firstName,
          last_name: data.lastName,
        },
      },
    });

    if (error) {
      throw error;
    }

    toast({
      title: "Registration successful",
      description: "Please check your email to verify your account.",
    });
    
    return authData;
  } catch (error) {
    console.error("Registration error:", error);
    throw error;
  }
};

export const signInUser = async (data: SignInData) => {
  try {
    console.log("SignInUser utility function called with:", data.email);
    
    // Use persistSession option to help with session persistence
    const { data: signInData, error } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    });

    if (error) {
      console.error("Sign in error from Supabase:", error);
      throw error;
    }

    // Store session timestamp and remember me preference
    localStorage.setItem('auth.timestamp', Date.now().toString());
    localStorage.setItem('auth.rememberMe', data.rememberMe ? 'true' : 'false');
    
    // Store minimal session data with expiration time based on remember me preference
    try {
      if (signInData.session) {
        // Calculate expiration time - 7 days or 1 day based on rememberMe
        const expiresAt = Math.floor(Date.now() / 1000) + 
          (data.rememberMe ? 60 * 60 * 24 * 7 : 60 * 60 * 24);
        
        const minimalSession = {
          userId: signInData.session.user.id,
          email: signInData.session.user.email,
          expiresAt: expiresAt,
          refreshToken: signInData.session.refresh_token
        };
        localStorage.setItem('auth.session.minimal', JSON.stringify(minimalSession));
      }
    } catch (error) {
      console.error("Failed to store minimal session data:", error);
    }
    
    console.log("Sign in successful, returning session data");
    return signInData;
  } catch (error) {
    console.error("Error in signInUser:", error);
    throw error;
  }
};

export const signOutUser = async () => {
  try {
    // First, clear all local storage and session storage tokens
    localStorage.removeItem('supabase.auth.token');
    localStorage.removeItem('auth.timestamp');
    localStorage.removeItem('auth.session.minimal');
    localStorage.removeItem('auth.rememberMe');
    sessionStorage.removeItem('supabase.auth.token');
    
    // Find and clear all Supabase-related storage items
    const allLocalStorageKeys = Object.keys(localStorage);
    const allSessionStorageKeys = Object.keys(sessionStorage);
    
    allLocalStorageKeys.forEach(key => {
      if (key.includes('supabase') || key.includes('auth') || key.includes('sb-')) {
        localStorage.removeItem(key);
      }
    });
    
    allSessionStorageKeys.forEach(key => {
      if (key.includes('supabase') || key.includes('auth') || key.includes('sb-')) {
        sessionStorage.removeItem(key);
      }
    });
    
    // Then, perform the supabase signout
    const { error } = await supabase.auth.signOut({
      scope: 'global' // This ensures a complete signout from all devices
    });
    
    if (error) {
      throw error;
    }
    
    // Force page reload to ensure all state is cleared
    window.location.href = '/login';
  } catch (error) {
    console.error('Error in signOutUser:', error);
    // Even if there was an error, try to force a redirect
    window.location.href = '/login';
    throw error;
  }
};

export const inviteUserByEmail = async (email: string, firstName: string, lastName: string, role: string, currentUserId: string) => {
  if (!currentUserId) {
    throw new Error("You must be logged in to invite users");
  }

  try {
    // Get the current user's profile to get their name and restaurant info
    const { data: inviterProfile, error: profileError } = await supabase
      .from('profiles')
      .select('pro_first_name, pro_last_name, restaurant_id')
      .eq('pro_id', currentUserId)
      .single();

    if (profileError) {
      throw profileError;
    }

    if (!inviterProfile.restaurant_id) {
      throw new Error("You must have a restaurant to invite users");
    }

    // Call our edge function to create the user
    const { data, error } = await supabase.functions.invoke('create-restaurant-user', {
      body: {
        email,
        firstName,
        lastName,
        role,
        restaurantId: inviterProfile.restaurant_id,
        inviterId: currentUserId
      }
    });

    if (error) {
      console.error('Error creating user:', error);
      throw error;
    }

    toast({
      title: "User created successfully",
      description: `An email with temporary login credentials has been sent to ${email}`,
    });
    
    return true;
  } catch (error: any) {
    console.error('Error in inviteUserByEmail:', error);
    throw error;
  }
};

// For compatibility with existing code
export const inviteUser = async (email: string, role: string) => {
  const currentUser = supabase.auth.getUser();
  const userId = (await currentUser).data.user?.id;
  
  if (!userId) {
    throw new Error("You must be logged in to invite users");
  }
  
  // Extract a name from the email address as a fallback
  const emailName = email.split('@')[0];
  const firstName = emailName || "New";
  const lastName = "User";
  
  return inviteUserByEmail(email, firstName, lastName, role, userId);
};

export const fetchRestaurantData = async (userId: string) => {
  try {
    if (!userId) {
      console.error('fetchRestaurantData: No userId provided');
      return null;
    }
    
    console.log('Fetching restaurant data for user:', userId);
    
    const { data, error } = await supabase.rpc('get_user_restaurant', {
      user_id: userId
    });
    
    if (error) {
      console.error('Error in fetchRestaurantData RPC call:', error);
      throw error;
    }
    
    console.log('Restaurant data fetched:', data ? data.length : 0, 'records');
    return data;
  } catch (error) {
    console.error('Error fetching restaurant data:', error);
    return null;
  }
};

export const updateTaxPercentage = async (restaurantId: string, percentage: string) => {
  try {
    if (!restaurantId) {
      throw new Error('No restaurant ID provided');
    }
    
    const { data, error } = await supabase
      .from('settings')
      .upsert({
        restaurant_id: restaurantId,
        setting_key: 'tax_percentage',
        setting_value: percentage,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'restaurant_id,setting_key'
      });
    
    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error updating tax percentage:', error);
    throw error;
  }
};

export const fetchTaxPercentage = async (restaurantId: string) => {
  try {
    if (!restaurantId) {
      return 8; // Default tax percentage
    }
    
    const { data, error } = await supabase
      .from('settings')
      .select('setting_value')
      .eq('restaurant_id', restaurantId)
      .eq('setting_key', 'tax_percentage')
      .maybeSingle();
    
    if (error) throw error;
    
    return data ? parseFloat(data.setting_value) : 8;
  } catch (error) {
    console.error('Error fetching tax percentage:', error);
    return 8; // Default to 8% if there's an error
  }
};
