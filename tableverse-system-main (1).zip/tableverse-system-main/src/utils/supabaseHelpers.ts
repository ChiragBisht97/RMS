
/**
 * Helper functions for working with Supabase
 */

import { supabase } from "@/integrations/supabase/client";

/**
 * Gets a strongly-typed query builder for the user_permissions table
 * This is a temporary workaround until types are updated
 */
export const getUserPermissionsTable = () => {
  return supabase.from('user_permissions') as any;
};

/**
 * Fetches user permissions for a specific user
 * @param userId User ID to fetch permissions for
 * @returns Object mapping module names to boolean enabled status
 */
export const fetchUserPermissions = async (userId: string): Promise<Record<string, boolean> | null> => {
  if (!userId) return null;
  
  try {
    const { data, error } = await getUserPermissionsTable()
      .select('module, enabled')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error fetching user permissions:', error);
      return null;
    }
    
    const permissionsMap: Record<string, boolean> = {};
    
    if (data && Array.isArray(data)) {
      data.forEach((item: any) => {
        permissionsMap[item.module] = item.enabled;
      });
    }
    
    return permissionsMap;
  } catch (error) {
    console.error('Exception fetching user permissions:', error);
    return null;
  }
};

/**
 * Updates a user's permission for a specific module
 */
export const updateUserPermission = async (
  userId: string, 
  module: string, 
  enabled: boolean
): Promise<boolean> => {
  try {
    const { error } = await getUserPermissionsTable()
      .upsert(
        {
          user_id: userId,
          module,
          enabled,
          updated_at: new Date().toISOString(),
        },
        {
          onConflict: 'user_id,module',
        }
      );
    
    return !error;
  } catch (error) {
    console.error('Error updating user permission:', error);
    return false;
  }
};
