
import QRCode from 'qrcode';

// Generate a QR code for a table that points to the customer order page
export async function generateTableQrCode(tableId: string): Promise<string> {
  try {
    // Create an absolute URL for customer ordering
    // This is critical to ensure the QR code points to the correct location
    let baseUrl = window.location.origin;
    
    // If we're in development mode but expecting a production URL
    // you might need to override this with your deployed domain
    // For example:
    // baseUrl = "https://yourdomain.com";
    
    console.log("QR Code base URL:", baseUrl);
    const orderUrl = `${baseUrl}/order/${tableId}`;
    console.log("QR Code full URL:", orderUrl);
    
    // Generate a QR code as a data URL
    const qrDataUrl = await QRCode.toDataURL(orderUrl, {
      margin: 1,
      width: 200,
      color: {
        dark: '#000000',
        light: '#ffffff'
      }
    });
    
    return qrDataUrl;
  } catch (error) {
    console.error('Error generating QR code:', error);
    throw error;
  }
}
