
import React from 'react';
import { OrderWithItems } from '@/types/orders';
import { getStatusColor } from '@/utils/orders';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Check, Clock, ClipboardList, AlertCircle, XCircle, Users, Table as TableIcon } from 'lucide-react';
import { formatTimeAgo } from '@/utils/orders';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency, calculateOrderTotals } from '@/utils/formatCurrency';

interface OrderDetailsProps {
  order: OrderWithItems;
  onStatusChange: () => void;
  onClose: () => void;
  view?: 'default' | 'kitchen';
}

const OrderDetails: React.FC<OrderDetailsProps> = ({ 
  order, 
  onStatusChange, 
  onClose,
  view = 'default'
}) => {
  const [isUpdating, setIsUpdating] = React.useState(false);
  const { currency, applyServiceCharge, serviceChargePercentage } = useCurrency();

  const getNextStatus = (currentStatus: string): string => {
    switch (currentStatus) {
      case 'Pending':
        return 'In Progress';
      case 'In Progress':
        return 'Ready';
      case 'Ready':
        return 'Completed';
      default:
        return currentStatus;
    }
  };

  const getStatusButton = (status: string) => {
    switch (status) {
      case 'Pending':
        return { label: 'Start Preparing', color: 'bg-blue-500 hover:bg-blue-600' };
      case 'In Progress':
        return { label: 'Mark as Ready', color: 'bg-green-500 hover:bg-green-600' };
      case 'Ready':
        return { label: 'Complete Order', color: 'bg-purple-500 hover:bg-purple-600' };
      default:
        return null;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pending':
        return <Clock className="h-5 w-5" />;
      case 'In Progress':
        return <ClipboardList className="h-5 w-5" />;
      case 'Ready':
        return <Check className="h-5 w-5" />;
      case 'Completed':
        return <Check className="h-5 w-5" />;
      case 'Cancelled':
        return <XCircle className="h-5 w-5" />;
      default:
        return <AlertCircle className="h-5 w-5" />;
    }
  };

  const updateOrderStatus = async () => {
    if (order.status === 'Completed' || order.status === 'Cancelled') {
      return;
    }

    const nextStatus = getNextStatus(order.status);
    
    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('orders')
        .update({ 
          status: nextStatus,
          updated_at: new Date().toISOString()
        })
        .eq('order_id', order.order_id);

      if (error) throw error;
      
      if (nextStatus === 'Completed' && 
          (order.payment_status === 'Paid' || order.payment_status === 'Prepaid') && 
          order.table_id) {
        const { error: tableError } = await supabase
          .from('tables')
          .update({ tb_status: 'Available' })
          .eq('tb_id', order.table_id);
        
        if (tableError) {
          console.error('Error updating table status:', tableError);
          toast({
            title: 'Order Updated',
            description: `Order #${order.order_id.slice(0, 8)} status changed to ${nextStatus}`,
          });
        }
      }
      
      toast({
        title: 'Order Updated',
        description: `Order #${order.order_id.slice(0, 8)} status changed to ${nextStatus}`,
      });
      
      onStatusChange();
    } catch (error) {
      console.error('Error updating order:', error);
      toast({
        title: 'Update Failed',
        description: 'There was a problem updating the order status.',
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const cancelOrder = async () => {
    if (order.status === 'Completed' || order.status === 'Cancelled') {
      return;
    }

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('orders')
        .update({ 
          status: 'Cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('order_id', order.order_id);

      if (error) throw error;
      
      toast({
        title: 'Order Cancelled',
        description: `Order #${order.order_id.slice(0, 8)} has been cancelled`,
      });
      
      onStatusChange();
    } catch (error) {
      console.error('Error cancelling order:', error);
      toast({
        title: 'Action Failed',
        description: 'There was a problem cancelling the order.',
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const statusButton = getStatusButton(order.status);

  const subtotal = order.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const { tax, serviceCharge, total } = calculateOrderTotals(
    subtotal, 
    8, // Tax is fixed at 8% for now
    serviceChargePercentage,
    applyServiceCharge
  );

  // Determine if this is a walk-in order
  const isWalkIn = !order.table_id;
  
  // Format order ID to be consistent - last 4 characters
  const formattedOrderId = order.order_id ? order.order_id.slice(-4) : "????";

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl">
            Order #{formattedOrderId}
          </CardTitle>
          <div className="text-sm text-muted-foreground mt-1 flex items-center">
            {isWalkIn ? (
              <>
                <Users className="h-4 w-4 mr-1 text-blue-500" />
                Walk-in Customer
              </>
            ) : (
              <>
                <TableIcon className="h-4 w-4 mr-1 text-primary" />
                Table: {order.table_name || `#${order.table_id ? order.table_id.slice(0, 8) : 'Walk-in'}`}
              </>
            )}
          </div>
        </div>
        <Badge className={`${getStatusColor(order.status)} flex items-center gap-1 px-3 py-1.5`}>
          {getStatusIcon(order.status)}
          {order.status}
        </Badge>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div>
          <div className="text-sm text-muted-foreground mb-2">
            Ordered {formatTimeAgo(order.created_at)}
          </div>
          
          <div className="rounded-md border">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr className="border-b">
                  <th className="h-10 px-4 text-left font-medium text-muted-foreground">Item</th>
                  <th className="h-10 px-4 text-center font-medium text-muted-foreground">Qty</th>
                  <th className="h-10 px-4 text-right font-medium text-muted-foreground">Price</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map((item) => (
                  <tr key={item.item_id} className="border-b">
                    <td className="p-4">
                      <div className="font-medium">{item.name || 'Unknown Item'}</div>
                      {item.notes && (
                        <div className="text-sm text-muted-foreground mt-1">
                          Note: {item.notes}
                        </div>
                      )}
                    </td>
                    <td className="p-4 text-center">{item.quantity}</td>
                    <td className="p-4 text-right">{formatCurrency(item.price * item.quantity, currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="flex flex-col gap-1 pt-2">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Subtotal</span>
            <span>{formatCurrency(subtotal, currency)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tax (8%)</span>
            <span>{formatCurrency(tax, currency)}</span>
          </div>
          {applyServiceCharge && serviceCharge > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Service Charge ({serviceChargePercentage}%)</span>
              <span>{formatCurrency(serviceCharge, currency)}</span>
            </div>
          )}
          <Separator className="my-2" />
          <div className="flex justify-between font-medium">
            <span>Total</span>
            <span>{formatCurrency(total, currency)}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex flex-col sm:flex-row gap-2 pt-6">
        <Button 
          variant="outline" 
          className="w-full sm:w-auto" 
          onClick={onClose}
        >
          Close
        </Button>
        
        <div className="flex-1"></div>
        
        {view === 'kitchen' && order.status !== 'Completed' && order.status !== 'Cancelled' && (
          <div className="flex gap-2 w-full sm:w-auto">
            <Button 
              variant="outline" 
              className="flex-1 text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
              disabled={isUpdating}
              onClick={cancelOrder}
            >
              Cancel Order
            </Button>
            
            {statusButton && (
              <Button 
                className={`flex-1 ${statusButton.color}`}
                disabled={isUpdating}
                onClick={updateOrderStatus}
              >
                {statusButton.label}
              </Button>
            )}
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default OrderDetails;
