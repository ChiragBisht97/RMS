
import React from 'react';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Order } from '@/types/orders';
import { formatTimeAgo, getStatusColor } from '@/utils/orders';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface OrdersTableProps {
  orders: Order[];
  loading: boolean;
  onViewDetails: (order: Order) => void;
}

const OrdersTable: React.FC<OrdersTableProps> = ({ orders, loading, onViewDetails }) => {
  const { currency } = useCurrency();
  
  if (loading) {
    return (
      <div className="flex justify-center p-6">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center p-6">
        <p className="text-muted-foreground">No orders found.</p>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-[100px]">Order ID</TableHead>
          <TableHead>Table</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Total</TableHead>
          <TableHead>Items</TableHead>
          <TableHead>Created At</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {orders.map((order, index) => (
          <TableRow 
            key={order.order_id} 
            className={`cursor-pointer hover:bg-muted/50 ${index % 2 === 1 ? 'bg-slate-300 dark:bg-slate-600' : ''}`} 
            onClick={() => onViewDetails(order)}
          >
            <TableCell className="font-medium">#{order.order_id.slice(-4)}</TableCell>
            <TableCell>
              {order.table_id ? (order.table_name || `#${order.table_id.slice(0, 8)}`) : 'Walk-in'}
            </TableCell>
            <TableCell>
              <Badge className={getStatusColor(order.status)}>
                {order.status}
              </Badge>
            </TableCell>
            <TableCell>{formatCurrency(order.total, currency)}</TableCell>
            <TableCell>{order.items_count}</TableCell>
            <TableCell className="text-muted-foreground">
              {formatTimeAgo(order.created_at || '')}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default OrdersTable;
