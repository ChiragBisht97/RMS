
import React from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Order, OrderStatus } from '@/types/orders';
import OrderCard from './OrderCard';

interface KitchenViewTabsProps {
  activeTab: string;
  setActiveTab: (value: string) => void;
  orders: Order[];
  statusCounts: {
    pending: number;
    inProgress: number;
    ready: number;
    active: number;
  };
  loading: boolean;
  error: string | null;
  filteredOrders: Order[];
  viewOrderDetails: (order: Order) => void;
  updateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  getNextStatus: (currentStatus: OrderStatus) => OrderStatus | null;
  getStatusIcon: (status: string) => React.ReactNode;
}

const KitchenViewTabs: React.FC<KitchenViewTabsProps> = ({
  activeTab,
  setActiveTab,
  orders,
  statusCounts,
  loading,
  error,
  filteredOrders,
  viewOrderDetails,
  updateOrderStatus,
  getNextStatus,
  getStatusIcon
}) => {
  return (
    <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="grid grid-cols-5">
        <TabsTrigger value="active">
          Active ({statusCounts.active})
        </TabsTrigger>
        <TabsTrigger value="Pending">
          Pending ({statusCounts.pending})
        </TabsTrigger>
        <TabsTrigger value="In Progress">
          In Progress ({statusCounts.inProgress})
        </TabsTrigger>
        <TabsTrigger value="Ready">
          Ready ({statusCounts.ready})
        </TabsTrigger>
        <TabsTrigger value="all">All</TabsTrigger>
      </TabsList>
      
      <TabsContent value={activeTab} className="mt-6">
        {loading ? (
          <div className="flex justify-center p-6">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : error ? (
          <div className="text-center p-6 text-red-500">{error}</div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center p-12 border rounded-lg bg-muted/20">
            <p className="text-muted-foreground">No orders found</p>
          </div>
        ) : (
          <ScrollArea className="h-[60vh]">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pr-4">
              {filteredOrders.map((order, index) => (
                <OrderCard
                  key={order.order_id}
                  order={order}
                  index={index}
                  viewOrderDetails={viewOrderDetails}
                  updateOrderStatus={updateOrderStatus}
                  getNextStatus={getNextStatus}
                  getStatusIcon={getStatusIcon}
                />
              ))}
            </div>
          </ScrollArea>
        )}
      </TabsContent>
    </Tabs>
  );
};

export default KitchenViewTabs;
