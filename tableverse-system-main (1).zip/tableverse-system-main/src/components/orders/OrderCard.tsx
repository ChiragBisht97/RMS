
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatTimeAgo, getStatusColor } from '@/utils/orders';
import { Order, OrderStatus } from '@/types/orders';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface OrderCardProps {
  order: Order;
  index: number;
  viewOrderDetails: (order: Order) => void;
  updateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  getNextStatus: (currentStatus: OrderStatus) => OrderStatus | null;
  getStatusIcon: (status: string) => React.ReactNode;
}

const OrderCard: React.FC<OrderCardProps> = ({
  order,
  index,
  viewOrderDetails,
  updateOrderStatus,
  getNextStatus,
  getStatusIcon
}) => {
  const { currency } = useCurrency();
  
  return (
    <Card 
      key={order.order_id} 
      className={`overflow-hidden ${index % 2 === 1 ? 'bg-slate-200 dark:bg-slate-700' : ''}`}
    >
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-base">
            Order #{order.order_id.slice(-4)}
          </CardTitle>
          <div className="flex gap-1">
            <Badge className={`${getStatusColor(order.status)} flex items-center gap-1`}>
              {getStatusIcon(order.status)}
              {order.status}
            </Badge>
            
            {order.payment_status && (
              <Badge variant={
                order.payment_status === 'Unpaid' ? 'outline' : 
                order.payment_status === 'Prepaid' ? 'secondary' : 'default'
              }>
                {order.payment_status}
              </Badge>
            )}
          </div>
        </div>
        <div className="text-sm text-muted-foreground">
          Table: {order.table_name || `#${order.table_id ? order.table_id.slice(0, 8) : 'Walk-in'}`}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="text-sm text-muted-foreground">
            {formatTimeAgo(order.created_at)}
          </div>
          <div className="text-sm">
            <span className="font-medium">{order.items_count}</span> items • 
            <span className="font-medium ml-1">{formatCurrency(order.total, currency)}</span>
          </div>
          
          <div className="flex flex-col gap-2 mt-3">
            {getNextStatus(order.status) && (
              <Button
                onClick={() => updateOrderStatus(order.order_id, getNextStatus(order.status) as OrderStatus)}
                variant="default"
                size="sm"
                className="w-full"
              >
                Mark as {getNextStatus(order.status)}
              </Button>
            )}
            
            <Button 
              onClick={() => viewOrderDetails(order)} 
              className="w-full"
              variant="outline"
              size="sm"
            >
              View Details
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OrderCard;
