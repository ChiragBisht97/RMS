import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface CreateOrderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: any[];
  onOrderCreated: () => void;
  tableId?: string | null;
}

const CreateOrderDialog: React.FC<CreateOrderDialogProps> = ({
  open,
  onOpenChange,
  items,
  onOrderCreated,
  tableId
}) => {
  const [tables, setTables] = useState<any[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(tableId || null);
  const [loading, setLoading] = useState(false);
  const [isTableRequired, setIsTableRequired] = useState(false);
  const { profile } = useAuth();
  const { currency } = useCurrency();

  useEffect(() => {
    if (open) {
      setSelectedTable(tableId || null);
      
      if (!tableId) {
        fetchTables();
      }
      
      setIsTableRequired(tableId !== null);
    }
  }, [open, tableId]);

  const fetchTables = async () => {
    try {
      setLoading(true);
      
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID not found',
          variant: 'destructive',
        });
        return;
      }
      
      const { data, error } = await supabase
        .from('tables')
        .select('*')
        .eq('restaurant_id', profile.restaurant_id)
        .eq('tb_status', 'Available')
        .order('tb_name');
      
      if (error) throw error;
      setTables(data || []);
    } catch (error) {
      console.error('Error fetching tables:', error);
      toast({
        title: 'Error',
        description: 'Failed to load available tables',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTableSelect = (value: string) => {
    setSelectedTable(value);
  };

  const calculateOrderTotal = () => {
    return items.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const handleCreateOrder = async () => {
    if (isTableRequired && !selectedTable) {
      toast({
        title: 'Select a table',
        description: 'Please select a table to create an order',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      setLoading(true);
      
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID not found',
          variant: 'destructive',
        });
        return;
      }
      
      const orderTotal = calculateOrderTotal();
      
      const { data: order, error } = await supabase
        .from('orders')
        .insert({
          table_id: selectedTable,
          restaurant_id: profile.restaurant_id,
          total: orderTotal,
          status: 'Pending',
          items_count: items.reduce((count, item) => count + item.quantity, 0),
          payment_status: 'Unpaid'
        })
        .select()
        .single();
      
      if (error) throw error;
      
      const orderItems = items.map(item => ({
        order_id: order.order_id,
        menu_item_id: item.id,
        quantity: item.quantity,
        price: item.price
      }));
      
      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);
      
      if (itemsError) throw itemsError;
      
      if (selectedTable) {
        const { error: tableError } = await supabase
          .from('tables')
          .update({ tb_status: 'Occupied' })
          .eq('tb_id', selectedTable);
        
        if (tableError) {
          console.error('Error updating table status:', tableError);
        }
      }
      
      onOrderCreated();
      onOpenChange(false);
      
      toast({
        title: 'Order created',
        description: `Order has been created successfully${selectedTable ? ' for ' + tables.find(t => t.tb_id === selectedTable)?.tb_name : ''}`,
      });
    } catch (error) {
      console.error('Error creating order:', error);
      toast({
        title: 'Error',
        description: 'Failed to create order',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Order</DialogTitle>
        </DialogHeader>
        
        {isTableRequired && (
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Table</label>
            <Select value={selectedTable || ""} onValueChange={handleTableSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Select a table" />
              </SelectTrigger>
              <SelectContent>
                {tables.map(table => (
                  <SelectItem key={table.tb_id} value={table.tb_id}>
                    {table.tb_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Order Summary</label>
          <div className="border rounded-lg overflow-hidden">
            <div className="max-h-[200px] overflow-y-auto">
              <div className="divide-y">
                {items.map((item, index) => (
                  <div key={index} className="px-4 py-2 flex justify-between items-center">
                    <span>
                      {item.name} <span className="text-sm text-muted-foreground">x{item.quantity}</span>
                    </span>
                    <span>{formatCurrency(item.price * item.quantity, currency)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="px-4 py-2 bg-muted flex justify-between items-center font-medium">
              <span>Total</span>
              <span>{formatCurrency(calculateOrderTotal(), currency)}</span>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline" disabled={loading}>Cancel</Button>
          </DialogClose>
          <Button onClick={handleCreateOrder} disabled={loading}>
            {loading ? 'Creating...' : 'Create Order'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CreateOrderDialog;
