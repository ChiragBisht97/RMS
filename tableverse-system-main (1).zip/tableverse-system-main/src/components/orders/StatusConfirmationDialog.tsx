
import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { OrderStatus } from '@/types/orders';

interface StatusConfirmationDialogProps {
  isOpen: boolean;
  orderId: string;
  currentStatus: string;
  newStatus: OrderStatus;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
}

const StatusConfirmationDialog: React.FC<StatusConfirmationDialogProps> = ({
  isOpen,
  orderId,
  currentStatus,
  newStatus,
  onOpenChange,
  onConfirm
}) => {
  const getStatusDescription = () => {
    switch (newStatus) {
      case 'Ready':
        return 'Are you sure you want to mark this order as Ready? This will notify staff that the order is ready for pickup.';
      case 'Completed':
        return 'Are you sure you want to mark this order as Completed? This will move it to the completed orders list.';
      case 'In Progress':
        return 'Are you sure you want to mark this order as In Progress? This will show that kitchen staff is working on the order.';
      case 'Cancelled':
        return 'Are you sure you want to cancel this order? This action cannot be undone.';
      default:
        return `Are you sure you want to change the status from ${currentStatus} to ${newStatus}?`;
    }
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Confirm Order Status Change</AlertDialogTitle>
          <AlertDialogDescription>
            {getStatusDescription()}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm}>
            Confirm
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default StatusConfirmationDialog;
