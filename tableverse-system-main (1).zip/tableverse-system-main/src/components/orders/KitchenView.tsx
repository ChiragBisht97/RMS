import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Order, OrderWithItems, OrderStatus, PaymentStatus } from '@/types/orders';
import OrderDetails from './OrderDetails';
import { toast } from '@/hooks/use-toast';
import KitchenViewTabs from './KitchenViewTabs';
import StatusConfirmationDialog from './StatusConfirmationDialog';
import { getStatusIcon, getNextStatus, filterOrdersByStatus, getOrderStatusCounts } from './KitchenViewUtils';
import { useAuth } from '@/contexts/AuthContext';

const KitchenView: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('active');
  const [selectedOrder, setSelectedOrder] = useState<OrderWithItems | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [hasInitiallyLoaded, setHasInitiallyLoaded] = useState(false);
  const [confirmationDialog, setConfirmationDialog] = useState({
    isOpen: false,
    orderId: '',
    currentStatus: '',
    newStatus: '' as OrderStatus
  });
  const { profile } = useAuth();

  const fetchOrders = useCallback(async () => {
    setIsRefreshing(true);
    setError(null);
    
    try {
      if (!profile?.restaurant_id) {
        console.error('No restaurant ID associated with the current user');
        setOrders([]);
        setLoading(false);
        setIsRefreshing(false);
        setHasInitiallyLoaded(true);
        return;
      }
      
      // Join with tables to get table names and filter by restaurant_id
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          tables:table_id (tb_name)
        `)
        .eq('restaurant_id', profile.restaurant_id) // Filter by restaurant_id
        .not('status', 'eq', 'Cancelled') // Don't show cancelled orders
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const mappedOrders = data.map(order => ({
        ...order,
        table_name: order.tables?.tb_name,
        status: order.status as OrderStatus,
        payment_status: order.payment_status as PaymentStatus
      }));
      
      setOrders(mappedOrders);
      setHasInitiallyLoaded(true);
    } catch (error) {
      console.error('Error fetching orders:', error);
      setError('Failed to load orders. Please try again.');
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  }, [profile?.restaurant_id]);

  useEffect(() => {
    fetchOrders();
    
    // Set up real-time subscription filtered by restaurant_id
    const channel = supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        { 
          event: '*', 
          schema: 'public', 
          table: 'orders',
          filter: profile?.restaurant_id ? `restaurant_id=eq.${profile.restaurant_id}` : undefined
        },
        (payload) => {
          console.log('Orders change received:', payload);
          fetchOrders();
        }
      )
      .subscribe();
      
    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchOrders, profile?.restaurant_id]);
  
  useEffect(() => {
    if (!hasInitiallyLoaded) {
      fetchOrders();
    }
  }, [fetchOrders, hasInitiallyLoaded]);

  const viewOrderDetails = async (order: Order) => {
    try {
      // Fetch order items
      const { data: items, error } = await supabase
        .from('order_items')
        .select(`
          *,
          menu_items:menu_item_id (mi_name, mi_description)
        `)
        .eq('order_id', order.order_id);
      
      if (error) throw error;
      
      const mappedItems = items.map(item => ({
        ...item,
        name: item.menu_items?.mi_name,
        description: item.menu_items?.mi_description
      }));
      
      setSelectedOrder({
        ...order,
        items: mappedItems
      });
      
      setIsDetailOpen(true);
    } catch (error) {
      console.error('Error fetching order details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load order details',
        variant: 'destructive'
      });
    }
  };

  const handleStatusChange = async () => {
    await fetchOrders();
    
    if (selectedOrder) {
      // Refresh the selected order details
      const updatedOrder = orders.find(o => o.order_id === selectedOrder.order_id);
      if (updatedOrder) {
        viewOrderDetails(updatedOrder);
      }
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      const orderToUpdate = orders.find(o => o.order_id === orderId);
      
      if (!orderToUpdate) {
        throw new Error('Order not found');
      }
      
      // If changing to Ready status, show confirmation dialog
      if (newStatus === 'Ready') {
        setConfirmationDialog({
          isOpen: true,
          orderId,
          currentStatus: orderToUpdate.status,
          newStatus
        });
        return;
      }
      
      // If changing to Completed status, update payment_status if it's prepaid
      let updateData: any = { status: newStatus };
      
      // If completing an order that was prepaid, change payment_status to Paid
      if (newStatus === 'Completed' && orderToUpdate.payment_status === 'Prepaid') {
        updateData.payment_status = 'Paid';
      }
      
      // For other statuses, proceed directly
      const { error } = await supabase
        .from('orders')
        .update(updateData)
        .eq('order_id', orderId);
        
      if (error) throw error;
      
      toast({
        title: 'Order Updated',
        description: `Order status changed to ${newStatus}`,
      });
      
      fetchOrders();
      
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update order status',
        variant: 'destructive'
      });
    }
  };
  
  const confirmStatusChange = async () => {
    try {
      const { orderId, newStatus } = confirmationDialog;
      const orderToUpdate = orders.find(o => o.order_id === orderId);
      
      if (!orderToUpdate) {
        throw new Error('Order not found');
      }
      
      let updateData: any = { status: newStatus };
      
      // If completing an order that was prepaid, change payment_status to Paid
      if (newStatus === 'Completed' && orderToUpdate.payment_status === 'Prepaid') {
        updateData.payment_status = 'Paid';
      }
      
      const { error } = await supabase
        .from('orders')
        .update(updateData)
        .eq('order_id', orderId);
        
      if (error) throw error;
      
      toast({
        title: 'Order Updated',
        description: `Order status changed to ${newStatus}`,
      });
      
      setConfirmationDialog({ isOpen: false, orderId: '', currentStatus: '', newStatus: '' as OrderStatus });
      fetchOrders();
      
    } catch (error) {
      console.error('Error confirming order status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update order status',
        variant: 'destructive'
      });
    }
  };

  const handleConfirmationDialogOpenChange = (open: boolean) => {
    setConfirmationDialog(prev => ({ ...prev, isOpen: open }));
  };

  const filteredOrders = filterOrdersByStatus(orders, activeTab);
  const statusCounts = getOrderStatusCounts(orders);

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button 
          onClick={fetchOrders} 
          variant="outline" 
          disabled={isRefreshing}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Refreshing...' : 'Refresh Kitchen View'}
        </Button>
      </div>
      
      <KitchenViewTabs
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        orders={orders}
        statusCounts={statusCounts}
        loading={loading}
        error={error}
        filteredOrders={filteredOrders}
        viewOrderDetails={viewOrderDetails}
        updateOrderStatus={updateOrderStatus}
        getNextStatus={getNextStatus}
        getStatusIcon={getStatusIcon}
      />
      
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedOrder && (
            <OrderDetails 
              order={selectedOrder} 
              onStatusChange={handleStatusChange}
              onClose={() => setIsDetailOpen(false)}
              view="kitchen"
            />
          )}
        </DialogContent>
      </Dialog>
      
      <StatusConfirmationDialog
        isOpen={confirmationDialog.isOpen}
        orderId={confirmationDialog.orderId}
        currentStatus={confirmationDialog.currentStatus}
        newStatus={confirmationDialog.newStatus}
        onOpenChange={handleConfirmationDialogOpenChange}
        onConfirm={confirmStatusChange}
      />
    </div>
  );
};

export default KitchenView;
