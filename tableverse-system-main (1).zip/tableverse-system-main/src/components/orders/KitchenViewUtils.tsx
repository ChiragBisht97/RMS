
import React from 'react';
import { Order, OrderStatus } from '@/types/orders';
import { Check, Clock, ClipboardList, AlertCircle, XCircle } from 'lucide-react';

export const getStatusIcon = (status: string) => {
  switch (status) {
    case 'Pending':
      return <Clock className="h-4 w-4" />;
    case 'In Progress':
      return <ClipboardList className="h-4 w-4" />;
    case 'Ready':
      return <Check className="h-4 w-4" />;
    case 'Completed':
      return <Check className="h-4 w-4" />;
    case 'Cancelled':
      return <XCircle className="h-4 w-4" />;
    default:
      return <AlertCircle className="h-4 w-4" />;
  }
};

export const getNextStatus = (currentStatus: OrderStatus): OrderStatus | null => {
  switch (currentStatus) {
    case 'Pending':
      return 'In Progress';
    case 'In Progress':
      return 'Ready';
    case 'Ready':
      return 'Completed';
    default:
      return null;
  }
};

export const filterOrdersByStatus = (orders: Order[], status: string | null) => {
  if (!status || status === 'all') return orders;
  if (status === 'active') {
    return orders.filter(order => 
      order.status !== 'Completed' && order.status !== 'Cancelled'
    );
  }
  return orders.filter(order => order.status === status);
};

export const getOrderStatusCounts = (orders: Order[]) => {
  return {
    pending: orders.filter(order => order.status === 'Pending').length,
    inProgress: orders.filter(order => order.status === 'In Progress').length,
    ready: orders.filter(order => order.status === 'Ready').length,
    active: orders.filter(order => 
      order.status !== 'Completed' && order.status !== 'Cancelled'
    ).length
  };
};
