
import { Order, OrderStatus } from '@/types/orders';

// Function to validate if a string is a valid OrderStatus
export const isValidOrderStatus = (status: string): status is OrderStatus => {
  return ['Pending', 'In Progress', 'Ready', 'Completed', 'Cancelled'].includes(status);
};

export const getFilteredOrders = (
  orders: Order[],
  searchQuery: string,
  statusFilter: string,
  dateFilter: string
): Order[] => {
  let filtered = [...orders];
  
  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    filtered = filtered.filter(order => 
      order.order_id.toLowerCase().includes(query) ||
      (order.table_name && order.table_name.toLowerCase().includes(query))
    );
  }
  
  if (statusFilter !== 'all') {
    filtered = filtered.filter(order => order.status === statusFilter);
  }
  
  if (dateFilter !== 'all') {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    filtered = filtered.filter(order => {
      const orderDate = new Date(order.created_at);
      
      switch (dateFilter) {
        case 'today':
          return orderDate >= today;
        case 'week':
          const weekAgo = new Date(today);
          weekAgo.setDate(weekAgo.getDate() - 7);
          return orderDate >= weekAgo;
        case 'month':
          const monthAgo = new Date(today);
          monthAgo.setMonth(monthAgo.getMonth() - 1);
          return orderDate >= monthAgo;
        default:
          return true;
      }
    });
  }
  
  return filtered;
};
