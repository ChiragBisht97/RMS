
import React from 'react';
import { cn } from '@/lib/utils';

type BlurCardProps = React.HTMLAttributes<HTMLDivElement> & {
  intensity?: 'light' | 'medium' | 'heavy';
  glassmorphism?: boolean;
  className?: string;
  children: React.ReactNode;
};

const BlurCard = ({ 
  intensity = 'medium',
  glassmorphism = true,
  className,
  children,
  ...props
}: BlurCardProps) => {
  const blurIntensity = {
    light: 'backdrop-blur-sm',
    medium: 'backdrop-blur-md',
    heavy: 'backdrop-blur-lg',
  };

  const glassStyles = glassmorphism 
    ? 'bg-white bg-opacity-10 border border-white border-opacity-20' 
    : 'bg-background/80';

  return (
    <div 
      className={cn(
        'rounded-xl shadow-glass transition-all duration-300 ease-in-out',
        blurIntensity[intensity],
        glassStyles,
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};

export default BlurCard;
