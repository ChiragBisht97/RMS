
import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { cva, type VariantProps } from 'class-variance-authority';

const buttonVariants = cva(
  'relative overflow-hidden transition-all duration-300 ease-in-out active:scale-95',
  {
    variants: {
      variant: {
        default: 'bg-primary text-primary-foreground hover:brightness-110',
        outline: 'border border-primary/50 text-foreground hover:bg-primary/10',
        ghost: 'text-foreground hover:bg-primary/10',
        glass: 'bg-white bg-opacity-20 backdrop-blur-md border border-white border-opacity-20 text-foreground hover:bg-opacity-30',
      },
      size: {
        default: 'h-10 px-4 py-2',
        sm: 'h-9 px-3 rounded-md',
        lg: 'h-11 px-8 rounded-md',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

export interface AnimatedButtonProps 
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  ripple?: boolean;
  glint?: boolean;
  children: React.ReactNode;
}

const AnimatedButton = React.forwardRef<HTMLButtonElement, AnimatedButtonProps>(
  ({ ripple = true, glint = false, className, variant, size, children, ...props }, ref) => {
    const [coords, setCoords] = React.useState({ x: -1, y: -1 });
    const [isRippling, setIsRippling] = React.useState(false);

    React.useEffect(() => {
      if (coords.x !== -1 && coords.y !== -1) {
        setIsRippling(true);
        setTimeout(() => setIsRippling(false), 500);
      } else {
        setIsRippling(false);
      }
    }, [coords]);

    React.useEffect(() => {
      if (!isRippling) setCoords({ x: -1, y: -1 });
    }, [isRippling]);

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (ripple) {
        const rect = e.currentTarget.getBoundingClientRect();
        setCoords({ x: e.clientX - rect.left, y: e.clientY - rect.top });
      }
      props.onClick && props.onClick(e);
    };

    return (
      <Button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className, 'group')}
        onClick={handleClick}
        {...props}
      >
        {ripple && isRippling && (
          <span
            className="absolute rounded-full bg-white/30 animate-ripple"
            style={{
              left: coords.x,
              top: coords.y,
              width: '500px',
              height: '500px',
              marginLeft: '-250px',
              marginTop: '-250px',
            }}
          />
        )}
        {glint && (
          <span className="absolute top-0 left-0 w-full h-full overflow-hidden">
            <span className="absolute top-0 left-[-100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform skew-x-[20deg] transition-all duration-1000 ease-out group-hover:left-[200%]" />
          </span>
        )}
        {children}
      </Button>
    );
  }
);

AnimatedButton.displayName = 'AnimatedButton';

export { AnimatedButton };
