
import React from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { PriceVariation } from '@/types/tables';
import PriceVariationList from './PriceVariationList';
import SinglePriceInput from './SinglePriceInput';

interface MenuItemPricingProps {
  useVariations: boolean;
  variations: PriceVariation[];
  onToggleVariations: () => void;
  onVariationsChange: (variations: PriceVariation[]) => void;
  price: number | string;
  onPriceChange: (value: string) => void;
  priceError?: string;
}

const MenuItemPricing: React.FC<MenuItemPricingProps> = ({
  useVariations,
  variations,
  onToggleVariations,
  onVariationsChange,
  price,
  onPriceChange,
  priceError
}) => {
  return (
    <div className="border rounded-md p-4">
      <div className="flex items-center justify-between mb-4">
        <Label htmlFor="useVariations" className="font-medium">Price Options</Label>
        <div className="flex items-center space-x-2">
          <span className="text-sm">Single Price</span>
          <Switch 
            id="useVariations" 
            checked={useVariations}
            onCheckedChange={onToggleVariations}
          />
          <span className="text-sm">Size Variations</span>
        </div>
      </div>
      
      {!useVariations ? (
        <SinglePriceInput
          price={price}
          onPriceChange={onPriceChange}
          priceError={priceError}
        />
      ) : (
        <PriceVariationList
          variations={variations}
          onVariationsChange={onVariationsChange}
        />
      )}
    </div>
  );
};

export default MenuItemPricing;
