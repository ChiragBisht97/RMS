
import React, { useRef, useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { X, Loader2 } from 'lucide-react';

interface MenuItemImageUploadProps {
  imagePreview: string | null;
  onImageChange: (imageFile: File | null, imagePreview: string | null) => void;
  restaurantId: string | null;
}

const MenuItemImageUpload: React.FC<MenuItemImageUploadProps> = ({
  imagePreview,
  onImageChange,
  restaurantId
}) => {
  const [uploadLoading, setUploadLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): boolean => {
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Please select an image smaller than 5MB',
        variant: 'destructive',
      });
      return false;
    }
    
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please select an image file',
        variant: 'destructive',
      });
      return false;
    }

    return true;
  };
  
  const showLocalPreview = (file: File): void => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      onImageChange(file, result);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    if (!validateFile(file)) {
      return;
    }
    
    // Only show preview, don't upload yet
    showLocalPreview(file);
  };

  const clearImage = () => {
    onImageChange(null, null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const renderImagePreview = () => {
    if (!imagePreview) return null;
    
    return (
      <div className="relative border rounded-md p-4 mt-2 flex flex-col items-center">
        <Button 
          type="button" 
          size="icon" 
          variant="destructive" 
          className="absolute right-2 top-2 h-6 w-6"
          onClick={clearImage}
        >
          <X className="h-4 w-4" />
        </Button>
        
        <img 
          src={imagePreview} 
          alt="Preview" 
          className="max-w-full max-h-[300px] object-contain"
        />
        
        <Alert className="mt-2 bg-muted/50">
          <AlertDescription>
            For best results, use images with 1:1 aspect ratio (square). Recommended resolution: 500x500 pixels. 
            Maximum file size: 5MB.
          </AlertDescription>
        </Alert>
      </div>
    );
  };

  return (
    <div className="grid gap-2">
      <div className="flex flex-col">
        <Input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          onChange={handleFileChange}
          disabled={uploadLoading || !restaurantId}
          className="cursor-pointer"
        />
        
        {!restaurantId && (
          <Alert className="mt-2 bg-amber-50">
            <AlertDescription>
              Restaurant ID is required for image uploads. Please create a restaurant profile first.
            </AlertDescription>
          </Alert>
        )}
      </div>
      
      {uploadLoading && (
        <div className="mt-2 flex items-center gap-2 text-primary">
          <Loader2 className="h-4 w-4 animate-spin" />
          <p className="text-sm">Uploading image...</p>
        </div>
      )}

      {renderImagePreview()}
    </div>
  );
};

export default MenuItemImageUpload;
