
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Save } from 'lucide-react';
import { Category } from '@/types/tables';
import { 
  SheetContent, 
  SheetDescription, 
  SheetHeader, 
  SheetTitle,
  SheetFooter
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import DraggableCategoryItem from './DraggableCategoryItem';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { arrayMove } from '@dnd-kit/sortable';

interface CategorySheetProps {
  categories: Category[];
  handleAddCategory: () => void;
  handleEditCategory: (category: Category) => void;
  confirmDeleteCategory: (category: Category) => void;
  updateCategoriesOrder?: (categories: Category[]) => Promise<void>;
}

const CategorySheet: React.FC<CategorySheetProps> = ({
  categories,
  handleAddCategory,
  handleEditCategory,
  confirmDeleteCategory,
  updateCategoriesOrder
}) => {
  const [localCategories, setLocalCategories] = useState<Category[]>(categories);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Update local categories when props change
  React.useEffect(() => {
    setLocalCategories(categories);
    setHasChanges(false);
  }, [categories]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      setLocalCategories((items) => {
        const oldIndex = items.findIndex(item => item.id === active.id);
        const newIndex = items.findIndex(item => item.id === over.id);
        
        const newItems = arrayMove(items, oldIndex, newIndex);
        // Update the order field based on new positions
        const updatedItems = newItems.map((item, index) => ({
          ...item,
          order: index + 1
        }));
        
        setHasChanges(true);
        return updatedItems;
      });
    }
  };

  const saveOrder = async () => {
    if (updateCategoriesOrder && hasChanges) {
      setIsSaving(true);
      try {
        await updateCategoriesOrder(localCategories);
        setHasChanges(false);
      } catch (error) {
        console.error('Error saving category order:', error);
      } finally {
        setIsSaving(false);
      }
    }
  };

  return (
    <SheetContent className="flex flex-col h-full">
      <SheetHeader className="flex-shrink-0">
        <SheetTitle>Menu Categories</SheetTitle>
        <SheetDescription>
          Organize your menu with categories. Drag to reorder.
        </SheetDescription>
      </SheetHeader>
      
      <div className="flex-1 flex flex-col min-h-0 py-4">
        <Button onClick={handleAddCategory} className="w-full mb-4 flex-shrink-0">
          <Plus className="mr-2 h-4 w-4" /> New Category
        </Button>
        
        <ScrollArea className="flex-1 overflow-y-auto pr-4">
          {localCategories.length === 0 ? (
            <div className="text-center p-4 border rounded-md">
              <p className="text-muted-foreground">No categories yet. Create your first one!</p>
            </div>
          ) : (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={localCategories.map(cat => cat.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-2">
                  {localCategories.map((category) => (
                    <DraggableCategoryItem
                      key={category.id}
                      category={category}
                      onEdit={handleEditCategory}
                      onDelete={confirmDeleteCategory}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          )}
        </ScrollArea>
      </div>
      
      <SheetFooter className="mt-4 border-t pt-4 flex-shrink-0">
        <Button 
          onClick={saveOrder} 
          className="w-full" 
          disabled={!hasChanges || isSaving}
          variant={hasChanges ? "default" : "outline"}
        >
          <Save className="mr-2 h-4 w-4" />
          {isSaving ? "Saving..." : "Save Order"}
        </Button>
      </SheetFooter>
    </SheetContent>
  );
};

export default CategorySheet;
