
import React from 'react';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { PriceVariation } from '@/types/tables';
import PriceVariationItem from './PriceVariationItem';

interface PriceVariationListProps {
  variations: PriceVariation[];
  onVariationsChange: (variations: PriceVariation[]) => void;
}

const PriceVariationList: React.FC<PriceVariationListProps> = ({
  variations,
  onVariationsChange
}) => {
  const addPriceVariation = () => {
    const newVariations = [...variations, { size: '', price: '' }];
    onVariationsChange(newVariations);
  };

  const removePriceVariation = (index: number) => {
    if (variations.length > 1) {
      const newVariations = variations.filter((_, i) => i !== index);
      onVariationsChange(newVariations);
    }
  };

  const updatePriceVariation = (index: number, field: 'size' | 'price', value: string) => {
    const newVariations = [...variations];
    newVariations[index][field] = value;
    onVariationsChange(newVariations);
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-[1fr_1fr_auto] gap-2 items-center font-medium text-sm">
        <div>Size</div>
        <div>Price ($)</div>
        <div></div>
      </div>
      
      {variations.map((variation, index) => (
        <PriceVariationItem
          key={index}
          variation={variation}
          index={index}
          canRemove={variations.length > 1}
          onUpdate={updatePriceVariation}
          onRemove={removePriceVariation}
        />
      ))}
      
      <Button 
        type="button" 
        variant="outline" 
        size="sm" 
        className="w-full mt-2"
        onClick={addPriceVariation}
      >
        <PlusCircle className="h-4 w-4 mr-2" /> Add Size Option
      </Button>
    </div>
  );
};

export default PriceVariationList;
