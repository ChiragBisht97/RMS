
import React, { useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { MenuItem, Category } from '@/types/tables';
import { useAuth } from '@/contexts/AuthContext';
import { useMenuItemForm } from '@/hooks/useMenuItemForm';
import MenuItemForm from './MenuItemForm';

interface MenuItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  item?: MenuItem | null;
  categories?: Category[];
}

const MenuItemDialog: React.FC<MenuItemDialogProps> = ({
  open,
  onOpenChange,
  onSuccess,
  item,
  categories = [],
}) => {
  const { profile } = useAuth();
  const isEditing = !!item;
  
  const {
    isSubmitting,
    imagePreview,
    useVariations,
    variations,
    setVariations,
    handleImageChange,
    toggleUseVariations,
    onSubmit
  } = useMenuItemForm({
    onSuccess,
    onCloseDialog: () => onOpenChange(false),
    restaurantId: profile?.restaurant_id || null,
    isEditing,
    itemId: item?.id
  });

  useEffect(() => {
    if (open && isEditing && item) {
      if (item.variations && item.variations.length > 0) {
        toggleUseVariations();
        setVariations(item.variations);
      }

      if (item.imageUrl) {
        handleImageChange(null, item.imageUrl);
      }
    }
  }, [open, item, isEditing]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item ? 'Edit Menu Item' : 'Add Menu Item'}</DialogTitle>
          <DialogDescription>
            {item 
              ? 'Update the details for this menu item.' 
              : 'Create a new item to add to your restaurant menu.'}
          </DialogDescription>
        </DialogHeader>
        
        <MenuItemForm
          item={item}
          categories={categories}
          restaurantId={profile?.restaurant_id || null}
          isSubmitting={isSubmitting}
          imagePreview={imagePreview}
          useVariations={useVariations}
          variations={variations}
          onSubmit={onSubmit}
          onImageChange={handleImageChange}
          onToggleVariations={toggleUseVariations}
          onVariationsChange={setVariations}
          onCancel={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  );
};

export default MenuItemDialog;
