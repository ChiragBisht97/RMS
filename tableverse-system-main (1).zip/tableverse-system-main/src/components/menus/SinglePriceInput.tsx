
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface SinglePriceInputProps {
  price: number | string;
  onPriceChange: (value: string) => void;
  priceError?: string;
}

const SinglePriceInput: React.FC<SinglePriceInputProps> = ({
  price,
  onPriceChange,
  priceError
}) => {
  return (
    <div className="grid gap-2">
      <Label htmlFor="price">Price</Label>
      <Input
        id="price"
        type="number"
        step="0.01"
        min="0"
        value={price}
        onChange={(e) => onPriceChange(e.target.value)}
        placeholder="0.00"
        aria-invalid={!!priceError}
      />
      {priceError && (
        <p className="text-sm text-red-500">{priceError}</p>
      )}
    </div>
  );
};

export default SinglePriceInput;
