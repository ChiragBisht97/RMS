
import React from 'react';
import { MenuItem } from '@/types/tables';
import { Button } from '@/components/ui/button';
import { Edit, Trash2, Clock, DollarSign, Utensils, XCircle, CheckCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface MenuItemListProps {
  items: MenuItem[];
  handleEditItem: (item: MenuItem) => void;
  confirmDeleteItem: (item: MenuItem) => void;
  toggleStockStatus?: (item: MenuItem) => void;
}

const MenuItemList: React.FC<MenuItemListProps> = ({ 
  items,
  handleEditItem,
  confirmDeleteItem,
  toggleStockStatus
}) => {
  const { currency } = useCurrency();

  return (
    <div className="space-y-2">
      {items.map((item) => (
        <Card key={item.id} className="overflow-hidden">
          <CardContent className="p-0">
            <div className="flex items-center p-3">
              <div className="w-12 h-12 bg-muted rounded overflow-hidden mr-3 flex-shrink-0">
                <img 
                  src={item.imageUrl || `https://placehold.co/100x100/e4e9f6/404e8f?text=${encodeURIComponent(item.name)}`} 
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-sm truncate">{item.name}</h3>
                  <div className="flex items-center ml-2">
                    <Badge variant="outline" className="ml-2">
                      <DollarSign className="h-3 w-3 mr-1" />
                      {formatCurrency(item.price, currency)}
                    </Badge>
                    {item.inStock === false && (
                      <Badge variant="destructive" className="ml-2">
                        <Clock className="h-3 w-3 mr-1" />
                        Out of Stock
                      </Badge>
                    )}
                  </div>
                </div>
                
                {item.categoryName && (
                  <Badge variant="outline" className="mt-1 text-xs">
                    <Utensils className="h-3 w-3 mr-1" />
                    {item.categoryName}
                  </Badge>
                )}
              </div>
              
              <div className="flex gap-1 ml-2">
                {toggleStockStatus && (
                  <Button 
                    variant={item.inStock ? "outline" : "secondary"} 
                    size="sm" 
                    className={`h-8 w-8 p-0 ${item.inStock ? 'hover:bg-red-100 hover:text-red-500' : 'bg-green-100 text-green-500'}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStockStatus(item);
                    }}
                    title={item.inStock ? "Mark as out of stock" : "Mark as in stock"}
                  >
                    {item.inStock ? 
                      <XCircle className="h-4 w-4" /> : 
                      <CheckCircle className="h-4 w-4" />
                    }
                  </Button>
                )}
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0"
                  onClick={() => handleEditItem(item)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0"
                  onClick={() => confirmDeleteItem(item)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default MenuItemList;
