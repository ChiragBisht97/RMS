
import React from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Leaf, Check, ChefHat, Star } from 'lucide-react';

interface MenuItemAttributesProps {
  isVegan: boolean;
  isVegetarian: boolean;
  isGlutenFree: boolean;
  isSpicy: boolean;
  isChefChoice: boolean;
  isBundle: boolean;
  onChange: (key: keyof MenuItemAttributesProps, value: boolean) => void;
}

const MenuItemAttributes: React.FC<MenuItemAttributesProps> = ({
  isVegan,
  isVegetarian,
  isGlutenFree,
  isSpicy,
  isChefChoice,
  isBundle,
  onChange
}) => {
  return (
    <div className="border rounded-md p-4">
      <h3 className="font-medium mb-3">Item Attributes</h3>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center space-x-2">
          <Switch 
            id="isVegan" 
            checked={isVegan}
            onCheckedChange={(checked) => onChange('isVegan', checked)}
          />
          <Label htmlFor="isVegan" className="flex items-center">
            <Leaf className="h-4 w-4 mr-1" /> Vegan
          </Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Switch 
            id="isVegetarian" 
            checked={isVegetarian}
            onCheckedChange={(checked) => onChange('isVegetarian', checked)}
          />
          <Label htmlFor="isVegetarian" className="flex items-center">
            <Leaf className="h-4 w-4 mr-1" /> Vegetarian
          </Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Switch 
            id="isGlutenFree" 
            checked={isGlutenFree}
            onCheckedChange={(checked) => onChange('isGlutenFree', checked)}
          />
          <Label htmlFor="isGlutenFree" className="flex items-center">
            <Check className="h-4 w-4 mr-1" /> Gluten Free
          </Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Switch 
            id="isSpicy" 
            checked={isSpicy}
            onCheckedChange={(checked) => onChange('isSpicy', checked)}
          />
          <Label htmlFor="isSpicy" className="flex items-center">
            <Check className="h-4 w-4 mr-1" /> Spicy
          </Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Switch 
            id="isChefChoice" 
            checked={isChefChoice}
            onCheckedChange={(checked) => onChange('isChefChoice', checked)}
          />
          <Label htmlFor="isChefChoice" className="flex items-center">
            <ChefHat className="h-4 w-4 mr-1" /> Chef's Choice
          </Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <Switch 
            id="isBundle" 
            checked={isBundle}
            onCheckedChange={(checked) => onChange('isBundle', checked)}
          />
          <Label htmlFor="isBundle" className="flex items-center">
            <Star className="h-4 w-4 mr-1" /> Bundle
          </Label>
        </div>
      </div>
    </div>
  );
};

export default MenuItemAttributes;
