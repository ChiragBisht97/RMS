
import React from 'react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { MenuItem, Category } from '@/types/tables';
import { Loader2 } from 'lucide-react';

interface DeleteConfirmationDialogsProps {
  deleteDialogOpen: boolean;
  setDeleteDialogOpen: (open: boolean) => void;
  itemToDelete: MenuItem | null;
  handleDeleteItem: () => Promise<void>;
  categoryDeleteDialogOpen: boolean;
  setCategoryDeleteDialogOpen: (open: boolean) => void;
  categoryToDelete: Category | null;
  handleDeleteCategory: () => Promise<void>;
  isDeleting?: boolean;
}

const DeleteConfirmationDialogs: React.FC<DeleteConfirmationDialogsProps> = ({
  deleteDialogOpen,
  setDeleteDialogOpen,
  itemToDelete,
  handleDeleteItem,
  categoryDeleteDialogOpen,
  setCategoryDeleteDialogOpen,
  categoryToDelete,
  handleDeleteCategory,
  isDeleting = false
}) => {
  return (
    <>
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {itemToDelete?.name}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteItem} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AlertDialog 
        open={categoryDeleteDialogOpen} 
        onOpenChange={(open) => {
          // Prevent closing dialog during deletion
          if (isDeleting && !open) return;
          setCategoryDeleteDialogOpen(open);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the category "{categoryToDelete?.name}". Items in this category will become uncategorized.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteCategory} 
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default DeleteConfirmationDialogs;
