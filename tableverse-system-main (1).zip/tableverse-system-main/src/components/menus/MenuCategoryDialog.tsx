
import React from 'react';
import { useForm } from 'react-hook-form';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface CategoryFormData {
  name: string;
  description: string;
}

interface MenuCategoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  category?: {
    id: string;
    name: string;
    description?: string;
  } | null;
}

const MenuCategoryDialog: React.FC<MenuCategoryDialogProps> = ({
  open,
  onOpenChange,
  onSuccess,
  category
}) => {
  const { profile } = useAuth();
  const isEditing = !!category;
  
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<CategoryFormData>({
    defaultValues: {
      name: category?.name || '',
      description: category?.description || ''
    }
  });

  React.useEffect(() => {
    if (open) {
      reset({
        name: category?.name || '',
        description: category?.description || ''
      });
    }
  }, [open, category, reset]);

  const onSubmit = async (data: CategoryFormData) => {
    try {
      if (!profile?.restaurant_id) {
        toast({
          title: 'Error',
          description: 'Restaurant ID is missing. Please try again later.',
          variant: 'destructive',
        });
        return;
      }

      if (isEditing && category) {
        const { error } = await supabase
          .from('menu_categories')
          .update({
            mc_name: data.name,
            mc_description: data.description,
            mc_updated_at: new Date().toISOString(),
            restaurant_id: profile.restaurant_id
          })
          .eq('mc_id', category.id)
          .eq('restaurant_id', profile.restaurant_id); // Added this line to ensure restaurant ID filtering

        if (error) throw error;
        
        toast({
          title: 'Category updated',
          description: 'The category has been updated successfully.',
        });
      } else {
        const { error } = await supabase
          .from('menu_categories')
          .insert({
            mc_name: data.name,
            mc_description: data.description,
            restaurant_id: profile.restaurant_id
          });

        if (error) throw error;
        
        toast({
          title: 'Category created',
          description: 'The new category has been created successfully.',
        });
      }
      
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save category.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Category' : 'Add Category'}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? 'Update the details for this menu category.' 
              : 'Create a new category to organize your menu items.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                {...register('name', { required: 'Category name is required' })}
                placeholder="e.g., Appetizers, Main Courses, Desserts"
              />
              {errors.name && (
                <p className="text-sm text-red-500">{errors.name.message}</p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                {...register('description')}
                placeholder="Describe this category"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : isEditing ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MenuCategoryDialog;
