
import React from 'react';
import { Button } from '@/components/ui/button';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { Plus, Tag } from 'lucide-react';
import { Sheet, SheetTrigger } from '@/components/ui/sheet';

interface MenuHeaderProps {
  handleAddItem: () => void;
  categoriesSheetOpen: boolean;
  setCategoriesSheetOpen: (open: boolean) => void;
}

const MenuHeader: React.FC<MenuHeaderProps> = ({
  handleAddItem,
  categoriesSheetOpen,
  setCategoriesSheetOpen
}) => {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight">Menu Management</h1>
        <p className="text-muted-foreground">Create and manage your restaurant's menu items.</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-2">
        <Sheet open={categoriesSheetOpen} onOpenChange={setCategoriesSheetOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="lg">
              <Tag className="mr-2 h-4 w-4" /> Manage Categories
            </Button>
          </SheetTrigger>
        </Sheet>
        
        <AnimatedButton glint size="lg" onClick={handleAddItem}>
          <Plus className="mr-2 h-4 w-4" /> Add Menu Item
        </AnimatedButton>
      </div>
    </div>
  );
};

export default MenuHeader;
