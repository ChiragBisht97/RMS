
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Grid, List } from 'lucide-react';
import { MenuItem } from '@/types/tables';
import MenuItemCard from './MenuItemCard';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import MenuItemList from './MenuItemList';

interface MenuGridProps {
  isLoading: boolean;
  filteredItems: MenuItem[];
  searchQuery: string;
  handleAddItem: () => void;
  handleEditItem: (item: MenuItem) => void;
  confirmDeleteItem: (item: MenuItem) => void;
  toggleStockStatus?: (item: MenuItem) => void;
}

const MenuGrid: React.FC<MenuGridProps> = ({
  isLoading,
  filteredItems,
  searchQuery,
  handleAddItem,
  handleEditItem,
  confirmDeleteItem,
  toggleStockStatus
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-12">
        <p>Loading menu items...</p>
      </div>
    );
  }

  if (filteredItems.length === 0) {
    return (
      <div className="text-center p-12 border rounded-lg">
        <h3 className="text-lg font-medium mb-2">No menu items found</h3>
        <p className="text-muted-foreground mb-4">
          {searchQuery ? 'Try a different search term' : 'Start by adding your first menu item'}
        </p>
        <Button onClick={handleAddItem}>
          <Plus className="mr-2 h-4 w-4" /> Add Menu Item
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <ToggleGroup type="single" value={viewMode} onValueChange={(value) => value && setViewMode(value as 'grid' | 'list')}>
          <ToggleGroupItem value="grid" aria-label="Grid view">
            <Grid className="h-4 w-4" />
          </ToggleGroupItem>
          <ToggleGroupItem value="list" aria-label="List view">
            <List className="h-4 w-4" />
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <MenuItemCard 
              key={item.id}
              item={item}
              handleEditItem={handleEditItem}
              confirmDeleteItem={confirmDeleteItem}
              toggleStockStatus={toggleStockStatus}
              compact={true}
            />
          ))}
        </div>
      ) : (
        <MenuItemList 
          items={filteredItems} 
          handleEditItem={handleEditItem} 
          confirmDeleteItem={confirmDeleteItem} 
          toggleStockStatus={toggleStockStatus}
        />
      )}
    </div>
  );
};

export default MenuGrid;
