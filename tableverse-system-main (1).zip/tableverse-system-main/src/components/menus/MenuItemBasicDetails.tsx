
import React from 'react';
import { Category } from '@/types/tables';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface MenuItemBasicDetailsProps {
  name: string;
  nameError?: string;
  description: string;
  categoryId: string;
  categories: Category[];
  onNameChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
}

const MenuItemBasicDetails: React.FC<MenuItemBasicDetailsProps> = ({
  name,
  nameError,
  description,
  categoryId,
  categories,
  onNameChange,
  onDescriptionChange,
  onCategoryChange,
}) => {
  return (
    <div className="grid gap-4">
      <div className="grid gap-2">
        <Label htmlFor="name">Name</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => onNameChange(e.target.value)}
          placeholder="e.g., Classic Burger, Caesar Salad"
        />
        {nameError && (
          <p className="text-sm text-red-500">{nameError}</p>
        )}
      </div>
      
      <div className="grid gap-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => onDescriptionChange(e.target.value)}
          placeholder="Describe the menu item"
          rows={3}
        />
      </div>
      
      <div className="grid gap-2">
        <Label htmlFor="categoryId">Category</Label>
        <Select 
          onValueChange={onCategoryChange}
          value={categoryId}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Uncategorized</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default MenuItemBasicDetails;
