
import React, { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, Utensils, Leaf, ChefHat, Star, XCircle, CheckCircle } from 'lucide-react';
import { MenuItem, MenuItemAttributes } from '@/types/tables';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface MenuItemCardProps {
  item: MenuItem;
  handleEditItem: (item: MenuItem) => void;
  confirmDeleteItem: (item: MenuItem) => void;
  toggleStockStatus?: (item: MenuItem) => void;
  compact?: boolean;
}

const MenuItemCard: React.FC<MenuItemCardProps> = ({ 
  item, 
  handleEditItem, 
  confirmDeleteItem,
  toggleStockStatus,
  compact = false
}) => {
  const { currency } = useCurrency();
  
  useEffect(() => {
    console.log('MenuItemCard component - Using currency:', currency, 'for item:', item.name);
  }, [currency, item.name]);

  const getImageUrl = (item: MenuItem) => {
    return item.imageUrl || `https://placehold.co/100x100/e4e9f6/404e8f?text=${encodeURIComponent(item.name)}`;
  };

  const renderAttributeBadges = (item: MenuItem) => {
    const attributes = item.attributes || {};
    const badges = [];
    
    if (attributes.isVegan) {
      badges.push(
        <Badge key="vegan" variant="outline" className="bg-green-50 text-green-700 border-green-200 flex items-center gap-1">
          <Leaf className="h-3 w-3" /> Vegan
        </Badge>
      );
    }
    
    if (attributes.isVegetarian && !attributes.isVegan) {
      badges.push(
        <Badge key="vegetarian" variant="outline" className="bg-green-50 text-green-700 border-green-200 flex items-center gap-1">
          <Leaf className="h-3 w-3" /> Vegetarian
        </Badge>
      );
    }
    
    if (attributes.isGlutenFree) {
      badges.push(
        <Badge key="gluten-free" variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          Gluten Free
        </Badge>
      );
    }
    
    if (attributes.isChefChoice) {
      badges.push(
        <Badge key="chef-choice" variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 flex items-center gap-1">
          <ChefHat className="h-3 w-3" /> Chef's Choice
        </Badge>
      );
    }
    
    if (attributes.isSpicy) {
      badges.push(
        <Badge key="spicy" variant="outline" className="bg-red-50 text-red-700 border-red-200">
          Spicy
        </Badge>
      );
    }
    
    if (attributes.isBundle) {
      badges.push(
        <Badge key="bundle" variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 flex items-center gap-1">
          <Star className="h-3 w-3" /> Bundle
        </Badge>
      );
    }
    
    if (compact) {
      if (badges.length > 2) {
        const visibleBadges = badges.slice(0, 2);
        visibleBadges.push(
          <Badge key="more" variant="outline">+{badges.length - 2}</Badge>
        );
        return visibleBadges.length > 0 ? (
          <div className="flex flex-wrap gap-1 mt-1">
            {visibleBadges}
          </div>
        ) : null;
      }
    }
    
    return badges.length > 0 ? (
      <div className="flex flex-wrap gap-1 mt-2">
        {badges}
      </div>
    ) : null;
  };

  const formatPrice = (item: MenuItem) => {
    if (item.variations && item.variations.length > 1) {
      const lowest = Math.min(...item.variations.map(v => parseFloat(v.price) || 0));
      const highest = Math.max(...item.variations.map(v => parseFloat(v.price) || 0));
      
      return `${formatCurrency(lowest, currency)} - ${formatCurrency(highest, currency)}`;
    }
    
    return formatCurrency(item.price, currency);
  };

  if (compact) {
    return (
      <Card className="overflow-hidden">
        <div className="relative h-32 bg-muted">
          <img 
            src={getImageUrl(item)} 
            alt={item.name}
            className="w-full h-full object-cover"
          />
          {item.inStock === false && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <span className="text-white font-semibold text-xs px-2 py-1 bg-red-500 rounded-md">Out of Stock</span>
            </div>
          )}
          <div className="absolute top-2 right-2 flex space-x-1">
            {toggleStockStatus && (
              <Button 
                variant="outline" 
                size="icon" 
                className={`h-6 w-6 bg-background/80 backdrop-blur-sm ${item.inStock ? 'hover:bg-red-100' : 'hover:bg-green-100'}`}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleStockStatus(item);
                }}
                title={item.inStock ? "Mark as out of stock" : "Mark as in stock"}
              >
                {item.inStock ? 
                  <XCircle className="h-3 w-3 text-red-500" /> : 
                  <CheckCircle className="h-3 w-3 text-green-500" />
                }
              </Button>
            )}
            <Button 
              variant="outline" 
              size="icon" 
              className="h-6 w-6 bg-background/80 backdrop-blur-sm"
              onClick={() => handleEditItem(item)}
            >
              <Edit className="h-3 w-3" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-6 w-6 bg-background/80 backdrop-blur-sm"
              onClick={() => confirmDeleteItem(item)}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        </div>
        <CardHeader className="pb-1 pt-3 px-3">
          <div className="flex justify-between items-start">
            <CardTitle className="text-sm line-clamp-1">{item.name}</CardTitle>
            <div className="text-sm font-semibold">{formatPrice(item)}</div>
          </div>
          <CardDescription className="text-xs line-clamp-1">
            {item.categoryName && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                {item.categoryName}
              </span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="px-3 py-1">
          {renderAttributeBadges(item)}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 bg-muted">
        <img 
          src={getImageUrl(item)} 
          alt={item.name}
          className="w-full h-full object-cover"
        />
        {item.inStock === false && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="text-white font-semibold px-3 py-1 bg-red-500 rounded-md">Out of Stock</span>
          </div>
        )}
        <div className="absolute top-2 right-2 flex space-x-1">
          {toggleStockStatus && (
            <Button 
              variant="outline" 
              size="icon" 
              className={`h-8 w-8 bg-background/80 backdrop-blur-sm ${item.inStock ? 'hover:bg-red-100' : 'hover:bg-green-100'}`}
              onClick={(e) => {
                e.stopPropagation();
                toggleStockStatus(item);
              }}
              title={item.inStock ? "Mark as out of stock" : "Mark as in stock"}
            >
              {item.inStock ? 
                <XCircle className="h-4 w-4 text-red-500" /> : 
                <CheckCircle className="h-4 w-4 text-green-500" />
              }
            </Button>
          )}
          <Button 
            variant="outline" 
            size="icon" 
            className="h-8 w-8 bg-background/80 backdrop-blur-sm"
            onClick={() => handleEditItem(item)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="h-8 w-8 bg-background/80 backdrop-blur-sm"
            onClick={() => confirmDeleteItem(item)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{item.name}</CardTitle>
            <CardDescription>
              {item.categoryName && (
                <span className="inline-flex items-center px-2 py-0.5 mt-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                  {item.categoryName}
                </span>
              )}
            </CardDescription>
          </div>
          <div className="text-lg font-semibold">{formatPrice(item)}</div>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <p className="text-sm text-muted-foreground">
          {item.description || `A delicious ${item.name.toLowerCase()} prepared with fresh ingredients.`}
        </p>
        {renderAttributeBadges(item)}
        
        {item.variations && item.variations.length > 1 && (
          <div className="mt-3 pt-3 border-t grid grid-cols-2 gap-2 text-sm">
            {item.variations.map((variation, idx) => (
              <div key={idx} className="flex justify-between">
                <span className="font-medium">{variation.size}</span>
                <span>{formatCurrency(parseFloat(variation.price), currency)}</span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="ghost" size="sm" onClick={() => handleEditItem(item)}>
          View Details
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleEditItem(item)}>
          <Utensils className="mr-2 h-4 w-4" />
          Edit Item
        </Button>
      </CardFooter>
    </Card>
  );
};

export default MenuItemCard;
