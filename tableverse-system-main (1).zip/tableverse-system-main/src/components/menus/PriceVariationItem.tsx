
import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { MinusCircle } from 'lucide-react';
import { PriceVariation } from '@/types/tables';

interface PriceVariationItemProps {
  variation: PriceVariation;
  index: number;
  canRemove: boolean;
  onUpdate: (index: number, field: 'size' | 'price', value: string) => void;
  onRemove: (index: number) => void;
}

const PriceVariationItem: React.FC<PriceVariationItemProps> = ({
  variation,
  index,
  canRemove,
  onUpdate,
  onRemove
}) => {
  return (
    <div className="grid grid-cols-[1fr_1fr_auto] gap-2 items-center">
      <Input
        value={variation.size}
        onChange={(e) => onUpdate(index, 'size', e.target.value)}
        placeholder="Size name (e.g., Small, Medium)"
        aria-label={`Size name for variation ${index + 1}`}
      />
      <Input
        type="number"
        step="0.01"
        min="0"
        value={variation.price}
        onChange={(e) => onUpdate(index, 'price', e.target.value)}
        placeholder="0.00"
        aria-label={`Price for variation ${index + 1}`}
      />
      <Button 
        type="button" 
        variant="ghost" 
        size="icon"
        onClick={() => onRemove(index)}
        disabled={!canRemove}
        aria-label={`Remove variation ${index + 1}`}
      >
        <MinusCircle className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default PriceVariationItem;
