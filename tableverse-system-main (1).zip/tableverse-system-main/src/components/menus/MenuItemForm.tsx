
import React from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { MenuItem, Category, PriceVariation } from '@/types/tables';
import { MenuItemFormData } from '@/hooks/useMenuItemForm';
import MenuItemImageUpload from './MenuItemImageUpload';
import MenuItemPricing from './MenuItemPricing';
import MenuItemAttributes from './MenuItemAttributes';
import MenuItemBasicDetails from './MenuItemBasicDetails';

interface MenuItemFormProps {
  item?: MenuItem | null;
  categories: Category[];
  restaurantId: string | null;
  isSubmitting: boolean;
  imagePreview: string | null;
  useVariations: boolean;
  variations: PriceVariation[];
  onSubmit: (data: MenuItemFormData) => void;
  onImageChange: (file: File | null, preview: string | null) => void;
  onToggleVariations: () => void;
  onVariationsChange: (variations: PriceVariation[]) => void;
  onCancel: () => void;
}

const MenuItemForm: React.FC<MenuItemFormProps> = ({
  item,
  categories,
  restaurantId,
  isSubmitting,
  imagePreview,
  useVariations,
  variations,
  onSubmit,
  onImageChange,
  onToggleVariations,
  onVariationsChange,
  onCancel
}) => {
  const { register, handleSubmit, formState: { errors }, reset, setValue, watch } = useForm<MenuItemFormData>({
    defaultValues: {
      name: item?.name || '',
      description: item?.description || '',
      price: item?.price || 0,
      categoryId: item?.categoryId || 'none',
      inStock: item?.inStock !== false,
      isVegan: item?.attributes?.isVegan || false,
      isVegetarian: item?.attributes?.isVegetarian || false,
      isGlutenFree: item?.attributes?.isGlutenFree || false,
      isSpicy: item?.attributes?.isSpicy || false,
      isChefChoice: item?.attributes?.isChefChoice || false,
      isBundle: item?.attributes?.isBundle || false,
    }
  });

  const handlePriceChange = (value: string) => {
    setValue('price', parseFloat(value) || 0);
  };

  const handleAttributeChange = (key: string, value: boolean) => {
    setValue(key as keyof MenuItemFormData, value);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="grid gap-4 py-4">
        <MenuItemBasicDetails
          name={watch('name')}
          nameError={errors.name?.message}
          description={watch('description')}
          categoryId={watch('categoryId')}
          categories={categories}
          onNameChange={(value) => setValue('name', value)}
          onDescriptionChange={(value) => setValue('description', value)}
          onCategoryChange={(value) => setValue('categoryId', value)}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
          <div className="grid gap-2">
            <Label>Image</Label>
            <MenuItemImageUpload
              imagePreview={imagePreview}
              onImageChange={onImageChange}
              restaurantId={restaurantId}
            />
          </div>
        </div>
        
        <MenuItemPricing
          useVariations={useVariations}
          variations={variations}
          onToggleVariations={onToggleVariations}
          onVariationsChange={onVariationsChange}
          price={watch('price')}
          onPriceChange={handlePriceChange}
          priceError={errors.price?.message}
        />
        
        <MenuItemAttributes
          isVegan={watch('isVegan')}
          isVegetarian={watch('isVegetarian')}
          isGlutenFree={watch('isGlutenFree')}
          isSpicy={watch('isSpicy')}
          isChefChoice={watch('isChefChoice')}
          isBundle={watch('isBundle')}
          onChange={handleAttributeChange}
        />

        <div className="flex items-center space-x-2">
          <Switch 
            id="inStock" 
            checked={watch('inStock')}
            onCheckedChange={(checked) => setValue('inStock', checked)}
          />
          <Label htmlFor="inStock">Item is in stock</Label>
        </div>
      </div>
      
      <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 mt-6">
        <Button variant="outline" type="button" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : item ? 'Update' : 'Create'}
        </Button>
      </div>
    </form>
  );
};

export default MenuItemForm;
