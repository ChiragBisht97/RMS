
import React from "react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import PermissionToggle from "./PermissionToggle";
import { useToast } from "@/hooks/use-toast";
import { UserWithPermissions, PermissionModule } from "./types";

interface PermissionsTableProps {
  users: UserWithPermissions[];
  permissionModules: PermissionModule[];
  isUpdating: Record<string, boolean>;
  currentUserId: string | undefined;
  onTogglePermission: (userId: string, module: string, currentValue: boolean) => void;
}

const PermissionsTable: React.FC<PermissionsTableProps> = ({
  users,
  permissionModules,
  isUpdating,
  currentUserId,
  onTogglePermission,
}) => {
  const { toast } = useToast();

  const handleTogglePermission = (userId: string, module: string, currentValue: boolean) => {
    // Don't allow changing permissions for owners
    const userToUpdate = users?.find(u => u.pro_id === userId);
    if (userToUpdate?.is_owner) {
      toast({
        title: "Cannot modify owner permissions",
        description: "Restaurant owners always have access to all modules",
        variant: "default",
      });
      return;
    }
    
    onTogglePermission(userId, module, currentValue);
  };

  // Sort users by role importance: owner first, then admin, manager, and staff
  const sortedUsers = [...(users || [])].sort((a, b) => {
    // Owners first
    if (a.is_owner && !b.is_owner) return -1;
    if (!a.is_owner && b.is_owner) return 1;
    
    // Then by role
    const roleOrder: Record<string, number> = { admin: 1, manager: 2, staff: 3 };
    const aOrder = roleOrder[a.pro_role] || 4;
    const bOrder = roleOrder[b.pro_role] || 4;
    
    return aOrder - bOrder;
  });

  return (
    <div className="w-full overflow-x-auto">
      <Table>
        <TableCaption>Module permissions for users</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[180px]">User</TableHead>
            <TableHead className="w-[100px]">Role</TableHead>
            {permissionModules.map((module) => (
              <TableHead key={module.id} className="text-center">
                {module.name}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedUsers && sortedUsers.length > 0 ? (
            sortedUsers.map((user) => (
              <TableRow key={user.pro_id}>
                <TableCell className="font-medium">
                  {user.pro_first_name || 'N/A'} {user.pro_last_name || ''}
                  {user.is_owner && (
                    <span className="ml-2 text-xs text-primary">(Owner)</span>
                  )}
                </TableCell>
                <TableCell>
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      user.pro_role === "admin"
                        ? "bg-primary/10 text-primary"
                        : user.pro_role === "manager"
                        ? "bg-amber-100 text-amber-800"
                        : "bg-green-100 text-green-800"
                    }`}
                  >
                    {user.pro_role || 'staff'}
                  </span>
                </TableCell>
                {permissionModules.map((module) => (
                  <TableCell key={`${user.pro_id}-${module.id}`} className="text-center">
                    <PermissionToggle
                      isEnabled={!!user.permissions[module.id]}
                      isUpdating={isUpdating[`${user.pro_id}-${module.id}`]}
                      isDisabled={
                        user.is_owner || // Can't change owner permissions
                        user.pro_id === currentUserId // Can't change own permissions
                      }
                      onToggle={() =>
                        handleTogglePermission(
                          user.pro_id,
                          module.id,
                          !!user.permissions[module.id]
                        )
                      }
                    />
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell
                colSpan={permissionModules.length + 2}
                className="text-center py-6"
              >
                No users found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default PermissionsTable;
