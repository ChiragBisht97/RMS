
import React from "react";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";

interface PermissionToggleProps {
  isEnabled: boolean;
  isUpdating: boolean;
  isDisabled: boolean;
  onToggle: () => void;
}

const PermissionToggle: React.FC<PermissionToggleProps> = ({
  isEnabled,
  isUpdating,
  isDisabled,
  onToggle,
}) => {
  return (
    <div className="flex justify-center">
      <Switch
        checked={isEnabled}
        onCheckedChange={onToggle}
        disabled={isDisabled || isUpdating}
      />
      {isUpdating && <Loader2 className="h-3 w-3 ml-1 animate-spin" />}
    </div>
  );
};

export default PermissionToggle;
