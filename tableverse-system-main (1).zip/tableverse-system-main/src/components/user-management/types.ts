
// Type for permission module
export interface PermissionModule {
  id: string;
  name: string;
  description: string;
}

// Type for user with permissions
export interface UserWithPermissions {
  pro_id: string;
  pro_first_name: string;
  pro_last_name: string;
  pro_role: string;
  pro_avatar_url: string | null;
  is_owner: boolean;
  permissions: Record<string, boolean>;
}
