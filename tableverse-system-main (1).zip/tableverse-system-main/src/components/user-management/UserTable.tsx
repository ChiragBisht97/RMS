
import React from "react";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { MoreVertical, Edit, Key } from "lucide-react";

interface UserTableProps {
  users: any[];
  isNotAdmin: boolean;
  getInitials: (firstName: string | null, lastName: string | null) => string;
  openEditProfileDialog: (userId: string, firstName: string, lastName: string) => void;
  openResetPasswordDialog: (userId: string, email: string) => void;
  changeUserRole: (userId: string, newRole: string) => void;
  roleOptions: { value: string; label: string }[];
  currentUserId?: string;
}

const UserTable: React.FC<UserTableProps> = ({
  users,
  isNotAdmin,
  getInitials,
  openEditProfileDialog,
  openResetPasswordDialog,
  changeUserRole,
  roleOptions,
  currentUserId,
}) => {
  return (
    <div className="bg-card rounded-lg border shadow-sm">
      <Table>
        <TableCaption>List of users in your organization</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[250px]">User</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users && users.length > 0 ? (
            users.map((user: any) => (
              <TableRow key={user.pro_id}>
                <TableCell className="font-medium">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      {user.pro_avatar_url ? (
                        <AvatarImage src={user.pro_avatar_url} alt={`${user.pro_first_name} ${user.pro_last_name}`} />
                      ) : null}
                      <AvatarFallback>
                        {getInitials(user.pro_first_name, user.pro_last_name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">
                        {user.pro_first_name || 'N/A'} {user.pro_last_name || ''}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {user.is_owner && <span className="text-primary font-medium">Owner</span>}
                      </div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium 
                      ${user.pro_role === 'admin' ? 'bg-primary/10 text-primary' : 
                       user.pro_role === 'manager' ? 'bg-amber-100 text-amber-800' : 
                       'bg-green-100 text-green-800'}`}>
                      {user.pro_role || 'staff'}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Active
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      
                      <DropdownMenuItem 
                        onClick={() => openEditProfileDialog(
                          user.pro_id, 
                          user.pro_first_name || '', 
                          user.pro_last_name || ''
                        )}
                        className="flex items-center gap-2"
                      >
                        <Edit className="h-4 w-4" />
                        <span>Edit Profile</span>
                      </DropdownMenuItem>
                      
                      <DropdownMenuItem 
                        onClick={() => openResetPasswordDialog(user.pro_id, user.email)}
                        disabled={user.is_owner && user.pro_id !== currentUserId}
                        className="flex items-center gap-2"
                      >
                        <Key className="h-4 w-4" />
                        <span>Reset Password</span>
                      </DropdownMenuItem>
                      
                      {!isNotAdmin && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel>Change Role</DropdownMenuLabel>
                          {roleOptions.map((role) => (
                            <DropdownMenuItem
                              key={role.value}
                              disabled={user.pro_role === role.value || user.is_owner || user.pro_id === currentUserId}
                              onClick={() => !user.is_owner && changeUserRole(user.pro_id, role.value)}
                            >
                              {role.label}
                            </DropdownMenuItem>
                          ))}
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={4} className="text-center py-6">
                No users found. {!isNotAdmin && "Create some users to get started."}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default UserTable;
