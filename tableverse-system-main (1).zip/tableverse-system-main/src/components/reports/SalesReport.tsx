
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingDown, TrendingUp, DollarSign, ShoppingCart } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { SalesData } from '@/hooks/useReportsData';
import { formatCurrency } from '@/utils/formatCurrency';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { BarChart, Bar, CartesianGrid, XAxis, YAxis } from 'recharts';

interface SalesReportProps {
  salesData: SalesData[];
  totalRevenue: number;
  totalOrders: number;
  averageOrderValue: number;
  loading: boolean;
  currency: string;
}

const SalesReport: React.FC<SalesReportProps> = ({
  salesData,
  totalRevenue,
  totalOrders,
  averageOrderValue,
  loading,
  currency
}) => {
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="pb-2">
            <CardDescription>Total Revenue</CardDescription>
            <CardTitle className="text-2xl">
              {loading ? <Skeleton className="h-8 w-24" /> : formatCurrency(totalRevenue, currency)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground flex items-center">
              <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
              <span>+12% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <CardContent className="p-0 pt-1">
                {loading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <div className="text-2xl font-bold">{totalOrders}</div>
                )}
              </CardContent>
            </div>
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
              <ShoppingCart className="h-4 w-4 text-blue-600" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
              <span>+19% from last month</span>
            </p>
          </CardContent>
        </Card>
        
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle className="text-sm font-medium">Average Order Value</CardTitle>
              <CardContent className="p-0 pt-1">
                {loading ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  <div className="text-2xl font-bold">{formatCurrency(averageOrderValue, currency)}</div>
                )}
              </CardContent>
            </div>
            <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
              <DollarSign className="h-4 w-4 text-green-600" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
              <span>-3% from last month</span>
            </p>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-4">
        <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
          <CardHeader>
            <CardTitle>Sales Breakdown</CardTitle>
            <CardDescription>Daily sales for the selected period</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[350px] w-full" />
            ) : salesData.length > 0 ? (
              <ChartContainer 
                className="h-[350px]" 
                config={{
                  revenue: { 
                    color: "#4f46e5",
                    label: "Revenue" 
                  }
                }}
              >
                <BarChart data={salesData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#6b7280', fontSize: 12 }}
                    tickFormatter={(value) => formatCurrency(value, currency)}
                    width={80}
                  />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent 
                        formatter={(value) => formatCurrency(Number(value), currency)}
                      />
                    }
                  />
                  <Bar 
                    dataKey="revenue" 
                    fill="var(--color-revenue)" 
                    radius={[4, 4, 0, 0]}
                    name="Revenue" 
                  />
                </BarChart>
              </ChartContainer>
            ) : (
              <p className="text-center py-16 text-muted-foreground">No sales data available for the selected period.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SalesReport;
