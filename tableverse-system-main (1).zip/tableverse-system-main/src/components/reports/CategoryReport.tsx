
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { CategoryData } from '@/hooks/useReportsData';
import { formatCurrency } from '@/utils/formatCurrency';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { BarChart, Bar, PieChart, Pie, Cell, CartesianGrid, XAxis, YAxis } from 'recharts';

interface CategoryReportProps {
  categories: CategoryData[];
  loading: boolean;
  currency: string;
}

const COLORS = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

const CategoryReport: React.FC<CategoryReportProps> = ({ 
  categories, 
  loading,
  currency
}) => {
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Category Distribution</CardTitle>
          <CardDescription>Percentage of orders by category</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : categories.length > 0 ? (
            <ChartContainer 
              className="h-[300px]" 
              config={
                categories.reduce((acc, category, index) => {
                  acc[category.name] = { color: COLORS[index % COLORS.length] };
                  return acc;
                }, {})
              }
            >
              <PieChart>
                <Pie
                  data={categories}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  innerRadius={60}
                  paddingAngle={2}
                  fill="#8884d8"
                  dataKey="orderCount"
                  nameKey="name"
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                >
                  {categories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <ChartTooltip 
                  content={
                    <ChartTooltipContent 
                      formatter={(value, name) => [`${value} orders`, name]}
                    />
                  }
                />
              </PieChart>
            </ChartContainer>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No category data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
      
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Category Performance</CardTitle>
          <CardDescription>Sales and order details by menu category</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[400px] w-full" />
          ) : categories.length > 0 ? (
            <ChartContainer 
              className="h-[300px] mb-6" 
              config={{
                revenue: { 
                  color: "#4f46e5",
                  label: "Revenue" 
                },
                orderCount: {
                  color: "#10b981",
                  label: "Orders"
                }
              }}
            >
              <BarChart data={categories} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                  yAxisId="left"
                  tickFormatter={(value) => formatCurrency(value, currency)}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                  yAxisId="right"
                  orientation="right"
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent />
                  }
                />
                <Bar 
                  dataKey="revenue" 
                  fill="var(--color-revenue)" 
                  radius={[4, 4, 0, 0]}
                  name="Revenue" 
                  yAxisId="left"
                />
                <Bar 
                  dataKey="orderCount" 
                  fill="var(--color-orderCount)" 
                  radius={[4, 4, 0, 0]}
                  name="Orders" 
                  yAxisId="right"
                />
              </BarChart>
            </ChartContainer>
          ) : null}

          {loading ? (
            <Skeleton className="h-[400px] w-full" />
          ) : categories.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Orders</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Items</TableHead>
                    <TableHead className="text-right">Avg. Price</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {categories.map((category) => (
                    <TableRow key={category.name}>
                      <TableCell className="font-medium">{category.name}</TableCell>
                      <TableCell className="text-right">{category.orderCount}</TableCell>
                      <TableCell className="text-right">{formatCurrency(category.revenue, currency)}</TableCell>
                      <TableCell className="text-right">{category.itemCount}</TableCell>
                      <TableCell className="text-right">{formatCurrency(category.averagePrice, currency)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No category data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CategoryReport;
