
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { PopularItemData } from '@/hooks/useReportsData';
import { formatCurrency } from '@/utils/formatCurrency';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { BarChart, Bar, PieChart, Pie, Cell, CartesianGrid, XAxis, YAxis } from 'recharts';

interface PopularItemsReportProps {
  items: PopularItemData[];
  loading: boolean;
  currency: string;
}

const PopularItemsReport: React.FC<PopularItemsReportProps> = ({ 
  items, 
  loading,
  currency
}) => {
  const COLORS = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
  
  const renderStarRating = (rating: number) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star} className={`text-lg ${star <= rating ? 'text-amber-400' : 'text-gray-300'}`}>
            ★
          </span>
        ))}
      </div>
    );
  };
  
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Sales by Item</CardTitle>
          <CardDescription>Revenue distribution across menu items</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : items.length > 0 ? (
            <ChartContainer 
              className="h-[300px]" 
              config={{
                revenue: { 
                  color: "#10b981",
                  label: "Revenue" 
                }
              }}
            >
              <BarChart data={items} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                  tickFormatter={(value) => formatCurrency(value, currency)}
                  width={80}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent 
                      formatter={(value) => formatCurrency(Number(value), currency)}
                    />
                  }
                />
                <Bar 
                  dataKey="revenue" 
                  fill="var(--color-revenue)" 
                  radius={[4, 4, 0, 0]}
                  name="Revenue" 
                />
              </BarChart>
            </ChartContainer>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No sales data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
      
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Item Categories</CardTitle>
          <CardDescription>Distribution of items by category</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : items.length > 0 ? (
            <ChartContainer 
              className="h-[300px]" 
              config={
                items.reduce((acc, item, index) => {
                  acc[item.name] = { color: COLORS[index % COLORS.length] };
                  return acc;
                }, {})
              }
            >
              <PieChart>
                <Pie
                  dataKey="revenue"
                  isAnimationActive={true}
                  data={items}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  innerRadius={60}
                  fill="#8884d8"
                  paddingAngle={2}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  labelLine={false}
                >
                  {items.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <ChartTooltip
                  content={
                    <ChartTooltipContent 
                      formatter={(value) => formatCurrency(Number(value), currency)}
                    />
                  }
                />
              </PieChart>
            </ChartContainer>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No category data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
      
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Popular Items</CardTitle>
          <CardDescription>Most ordered items ranked by popularity</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[400px] w-full" />
          ) : items.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Orders</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Rating</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.category}</TableCell>
                      <TableCell className="text-right">{item.orderCount}</TableCell>
                      <TableCell className="text-right">{formatCurrency(item.revenue, currency)}</TableCell>
                      <TableCell className="text-right">{renderStarRating(item.averageRating || 0)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No popular items data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PopularItemsReport;
