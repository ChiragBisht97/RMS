
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { TableData } from '@/hooks/useReportsData';
import { Progress } from '@/components/ui/progress';
import { formatCurrency } from '@/utils/formatCurrency';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { PieChart, Pie, Cell } from 'recharts';

interface TableReportProps {
  tables: TableData[];
  loading: boolean;
  currency: string;
}

const TableReport: React.FC<TableReportProps> = ({ 
  tables, 
  loading,
  currency
}) => {
  const COLORS = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
  
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Table Distribution</CardTitle>
          <CardDescription>Proportion of orders by table</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : tables.length > 0 ? (
            <ChartContainer 
              className="h-[300px]" 
              config={
                tables.reduce((acc, table, index) => {
                  acc[table.name] = { color: COLORS[index % COLORS.length] };
                  return acc;
                }, {})
              }
            >
              <PieChart>
                <Pie
                  data={tables}
                  dataKey="orderCount"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  innerRadius={60}
                  fill="#8884d8"
                  paddingAngle={2}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  labelLine={false}
                >
                  {tables.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <ChartTooltip
                  content={
                    <ChartTooltipContent />
                  }
                />
              </PieChart>
            </ChartContainer>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No table data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
      
      <Card className="overflow-hidden border border-border/40 bg-card/60 backdrop-blur-sm shadow-sm">
        <CardHeader>
          <CardTitle>Table Performance</CardTitle>
          <CardDescription>Revenue and utilization metrics by table</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-[400px] w-full" />
          ) : tables.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Table</TableHead>
                    <TableHead className="text-right">Orders</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Turnover Rate</TableHead>
                    <TableHead className="text-right">Avg. Occupancy</TableHead>
                    <TableHead>Utilization</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tables.map((table) => (
                    <TableRow key={table.id}>
                      <TableCell className="font-medium">{table.name}</TableCell>
                      <TableCell className="text-right">{table.orderCount}</TableCell>
                      <TableCell className="text-right">{formatCurrency(table.revenue, currency)}</TableCell>
                      <TableCell className="text-right">{table.turnoverRate.toFixed(1)}/day</TableCell>
                      <TableCell className="text-right">{table.averageOccupancyMinutes} min</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress 
                            value={table.utilization} 
                            className="h-2" 
                            style={{
                              "--progress-color": table.utilization > 75 ? "#10b981" : 
                                                table.utilization > 50 ? "#0ea5e9" : 
                                                table.utilization > 25 ? "#f59e0b" : "#ef4444"
                            } as React.CSSProperties}
                          />
                          <span className="text-xs font-medium">{table.utilization}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-center py-16 text-muted-foreground">No table data available for the selected period.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TableReport;
