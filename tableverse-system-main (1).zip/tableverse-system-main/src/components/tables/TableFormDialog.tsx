import React from 'react';
import { useForm } from 'react-hook-form';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { supabase } from '@/integrations/supabase/client';
import { generateTableQrCode } from '@/utils/qrCode';
import { useAuth } from '@/contexts/AuthContext';

const tableFormSchema = z.object({
  name: z.string().min(1, "Table name is required"),
  capacity: z.string().min(1, "Capacity is required").refine((val) => !isNaN(Number(val)), "Capacity must be a number"),
  status: z.enum(['Available', 'Occupied', 'Reserved', 'Cleaning']),
  location: z.string().optional(),
});

type TableFormValues = z.infer<typeof tableFormSchema>;

interface TableItem {
  id: string;
  name: string;
  capacity: number;
  status: string;
  location: string | null;
}

interface TableFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  table: TableItem | null;
  onTableSaved: () => void;
}

const TableFormDialog: React.FC<TableFormDialogProps> = ({
  open,
  onOpenChange,
  table,
  onTableSaved,
}) => {
  const isEditing = !!table;
  const { profile } = useAuth();
  
  const form = useForm<TableFormValues>({
    resolver: zodResolver(tableFormSchema),
    defaultValues: {
      name: table?.name || '',
      capacity: table?.capacity ? String(table.capacity) : '',
      status: (table?.status as any) || 'Available',
      location: table?.location || '',
    },
  });

  React.useEffect(() => {
    if (open) {
      form.reset({
        name: table?.name || '',
        capacity: table?.capacity ? String(table.capacity) : '',
        status: (table?.status as any) || 'Available',
        location: table?.location || '',
      });
    }
  }, [open, table, form]);

  const onSubmit = async (data: TableFormValues) => {
    try {
      if (!profile?.restaurant_id) {
        throw new Error("Restaurant information is missing. Please refresh the page and try again.");
      }
      
      const tableName = data.name;
      
      if (isEditing && table) {
        const { error } = await supabase
          .from('tables')
          .update({
            tb_name: tableName,
            tb_capacity: Number(data.capacity),
            tb_status: data.status,
            tb_location: data.location || null,
            tb_updated_at: new Date().toISOString(),
            restaurant_id: profile.restaurant_id
          })
          .eq('tb_id', table.id);

        if (error) throw error;
        toast({
          title: 'Table updated',
          description: 'The table has been updated successfully.',
        });
      } else {
        const { data: newTable, error: insertError } = await supabase
          .from('tables')
          .insert({
            tb_name: tableName,
            tb_capacity: Number(data.capacity),
            tb_status: data.status,
            tb_location: data.location || null,
            restaurant_id: profile.restaurant_id
          })
          .select('tb_id')
          .single();

        if (insertError) throw insertError;
        
        if (newTable) {
          const qrCode = await generateTableQrCode(newTable.tb_id);
          
          const { error: updateError } = await supabase
            .from('tables')
            .update({
              tb_qr_code: qrCode,
            })
            .eq('tb_id', newTable.tb_id);

          if (updateError) throw updateError;
        }

        toast({
          title: 'Table created',
          description: 'The new table has been created successfully with a QR code.',
        });
      }
      
      onTableSaved();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save table.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Table' : 'Add Table'}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? 'Update the details for this table.' 
              : 'Create a new table with a unique QR code for customer ordering.'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 1, Window Table" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="capacity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Capacity</FormLabel>
                  <FormControl>
                    <Input type="number" min="1" placeholder="Number of seats" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Available">Available</SelectItem>
                      <SelectItem value="Occupied">Occupied</SelectItem>
                      <SelectItem value="Reserved">Reserved</SelectItem>
                      <SelectItem value="Cleaning">Cleaning</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Patio, Near window" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? 'Saving...' : isEditing ? 'Update' : 'Create'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default TableFormDialog;
