
import React from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Download, Trash2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface TableDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  qrCodeUrl: string;
  tableName: string;
  onSuccess?: () => void;
  onDelete?: () => void;
  tableId?: string;
}

const TableDialog: React.FC<TableDialogProps> = ({
  open,
  onOpenChange,
  qrCodeUrl,
  tableName,
  onSuccess,
  onDelete,
  tableId,
}) => {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = qrCodeUrl;
    link.download = `${tableName.replace(/\s+/g, '-')}-QRCode.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'QR Code Downloaded',
      description: `QR code for ${tableName} has been downloaded`,
    });
    
    if (onSuccess) {
      onSuccess();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>QR Code for {tableName}</DialogTitle>
          <DialogDescription>
            Customers can scan this QR code to place orders directly from this table.
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center justify-center py-4">
          <img 
            src={qrCodeUrl} 
            alt={`QR code for ${tableName}`} 
            className="w-64 h-64 border rounded-md"
          />
          <p className="text-sm text-center text-muted-foreground mt-2">
            Print this QR code and place it on {tableName}
          </p>
        </div>
        
        <div className="flex justify-between mt-2">
          <Button 
            variant="destructive" 
            onClick={onDelete}
            className="gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Delete Table
          </Button>
          <Button onClick={handleDownload} className="gap-2">
            <Download className="h-4 w-4" />
            Download QR Code
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TableDialog;
