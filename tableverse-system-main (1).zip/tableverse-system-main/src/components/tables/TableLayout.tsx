import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TableItem } from '@/types/tables';
import { supabase } from '@/integrations/supabase/client';
import { Trash2, Move, Grid3X3 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useDraggable } from '@dnd-kit/core';
import { DndContext, DragEndEvent, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';

interface TableLayoutProps {
  tables?: TableItem[];
  onTableDeleted?: () => void;
}

interface DraggableTableProps {
  table: TableItem;
  position: { x: number; y: number };
  isSelected: boolean;
  onSelect: () => void;
}

const DraggableTable: React.FC<DraggableTableProps> = ({ table, position, isSelected, onSelect }) => {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: table.id,
    data: { 
      table,
      initialPosition: position
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Available':
        return 'bg-green-500';
      case 'Occupied':
        return 'bg-red-500';
      case 'Reserved':
        return 'bg-blue-500';
      case 'Cleaning':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    left: `${position.x}%`,
    top: `${position.y}%`
  } : {
    left: `${position.x}%`,
    top: `${position.y}%`
  };

  return (
    <div 
      ref={setNodeRef}
      className={cn(
        'absolute w-20 h-20 rounded-md flex flex-col items-center justify-center cursor-move shadow-md transition-colors',
        getStatusColor(table.status),
        'text-white',
        isSelected && 'ring-2 ring-primary ring-offset-2'
      )}
      style={style}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      {...attributes}
      {...listeners}
    >
      <span className="font-medium">{table.name}</span>
      <span className="text-xs">{table.capacity} seats</span>
    </div>
  );
};

const TableLayout: React.FC<TableLayoutProps> = ({ tables = [], onTableDeleted }) => {
  const [selectedTable, setSelectedTable] = useState<TableItem | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isReleasing, setIsReleasing] = useState(false);
  const [tablePositions, setTablePositions] = useState<Record<string, { x: number, y: number }>>({});
  const { profile } = useAuth();

  useEffect(() => {
    const initialPositions: Record<string, { x: number, y: number }> = {};
    
    tables.forEach(table => {
      if (!tablePositions[table.id]) {
        initialPositions[table.id] = {
          x: Math.floor(Math.random() * 70) + 10,
          y: Math.floor(Math.random() * 70) + 10
        };
      }
    });
    
    if (Object.keys(initialPositions).length > 0) {
      setTablePositions(prev => ({ ...prev, ...initialPositions }));
    }
  }, [tables]);

  const handleDeleteTable = async () => {
    if (!selectedTable) return;
    
    setIsDeleting(true);
    try {
      const { error } = await supabase
        .from('tables')
        .delete()
        .eq('tb_id', selectedTable.id);
        
      if (error) throw error;
      
      toast({
        title: "Table deleted",
        description: `Table "${selectedTable.name}" has been deleted.`,
      });
      
      if (onTableDeleted) {
        onTableDeleted();
      }
    } catch (error) {
      console.error('Error deleting table:', error);
      toast({
        title: "Error",
        description: "Failed to delete table. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsDeleting(false);
      setIsDeleteDialogOpen(false);
      setSelectedTable(null);
    }
  };

  const handleReleaseTable = async () => {
    if (!selectedTable) return;
    
    setIsReleasing(true);
    try {
      if (!profile?.restaurant_id) return;
      
      const { data: activeOrders, error: checkError } = await supabase
        .from('orders')
        .select('order_id')
        .eq('table_id', selectedTable.id)
        .in('status', ['Pending', 'In Progress', 'Ready'])
        .limit(1);
      
      if (checkError) throw checkError;
      
      if (activeOrders && activeOrders.length > 0) {
        toast({
          title: "Cannot Release Table",
          description: "This table has active orders that need to be completed first.",
          variant: "destructive",
        });
        setIsReleasing(false);
        return;
      }
      
      const { error: updateError } = await supabase
        .from('tables')
        .update({ tb_status: 'Available' })
        .eq('tb_id', selectedTable.id)
        .eq('restaurant_id', profile.restaurant_id);
      
      if (updateError) throw updateError;
      
      toast({
        title: "Table Released",
        description: "The table is now available for new customers.",
      });
      
      if (onTableDeleted) {
        onTableDeleted();
      }
      
      setSelectedTable(null);
      
    } catch (error) {
      console.error('Error releasing table:', error);
      toast({
        title: "Error",
        description: "Failed to release the table. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsReleasing(false);
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, delta } = event;
    const tableId = active.id as string;
    
    if (!tableId || !tablePositions[tableId]) return;
    
    const currentPosition = tablePositions[tableId];
    const containerWidth = document.querySelector('.layout-container')?.clientWidth || 1000;
    const containerHeight = document.querySelector('.layout-container')?.clientHeight || 500;
    
    const deltaXPercent = (delta.x / containerWidth) * 100;
    const deltaYPercent = (delta.y / containerHeight) * 100;
    
    const newX = Math.max(0, Math.min(90, currentPosition.x + deltaXPercent));
    const newY = Math.max(0, Math.min(90, currentPosition.y + deltaYPercent));
    
    const newPositions = {
      ...tablePositions,
      [tableId]: { x: newX, y: newY }
    };
    setTablePositions(newPositions);
    
    if (profile?.restaurant_id) {
      try {
        const { error } = await supabase
          .from('tables')
          .update({ 
            tb_location: JSON.stringify({ x: newX, y: newY }) 
          })
          .eq('tb_id', tableId)
          .eq('restaurant_id', profile.restaurant_id);
        
        if (error) throw error;
      } catch (error) {
        console.error('Error saving table position:', error);
        toast({
          title: "Error",
          description: "Failed to save table position.",
          variant: "destructive"
        });
      }
    }
  };

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );
  
  useEffect(() => {
    const loadSavedPositions = async () => {
      try {
        if (!profile?.restaurant_id) return;
        
        const { data, error } = await supabase
          .from('tables')
          .select('tb_id, tb_location')
          .eq('restaurant_id', profile.restaurant_id);
          
        if (error) throw error;
        
        const savedPositions: Record<string, { x: number, y: number }> = {};
        
        data.forEach(item => {
          if (item.tb_location) {
            try {
              const position = JSON.parse(item.tb_location);
              if (position.x !== undefined && position.y !== undefined) {
                savedPositions[item.tb_id] = { 
                  x: position.x, 
                  y: position.y 
                };
              }
            } catch (e) {
              console.error('Error parsing table location:', e);
            }
          }
        });
        
        if (Object.keys(savedPositions).length > 0) {
          setTablePositions(prev => ({ ...prev, ...savedPositions }));
        }
      } catch (error) {
        console.error('Error loading table positions:', error);
      }
    };
    
    loadSavedPositions();
  }, [profile?.restaurant_id]);

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Floor Layout</CardTitle>
          <CardDescription>Visual representation of your restaurant floor</CardDescription>
        </CardHeader>
        <CardContent>
          <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
            <div 
              className="relative w-full h-[500px] bg-slate-50 rounded-lg border border-slate-200 p-4 layout-container"
              style={{ 
                backgroundImage: `
                  linear-gradient(to right, #e5e7eb 1px, transparent 1px),
                  linear-gradient(to bottom, #e5e7eb 1px, transparent 1px)
                `,
                backgroundSize: '40px 40px',
              }}
              onClick={() => setSelectedTable(null)}
            >
              {tables.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <Grid3X3 className="h-16 w-16 text-slate-300 mb-4" />
                  <p className="text-muted-foreground mb-2">No tables available</p>
                  <p className="text-sm text-muted-foreground">Add tables to see them in the floor layout</p>
                </div>
              ) : (
                <div className="relative w-full h-full">
                  {tables.map((table) => (
                    <DraggableTable
                      key={table.id}
                      table={table}
                      position={tablePositions[table.id] || { x: 10, y: 10 }}
                      isSelected={selectedTable?.id === table.id}
                      onSelect={() => setSelectedTable(table === selectedTable ? null : table)}
                    />
                  ))}
                </div>
              )}
            </div>
          </DndContext>
          
          {selectedTable && (
            <div className="mt-4 p-3 border rounded-md bg-muted/20">
              <h3 className="font-medium mb-2">Selected: {selectedTable.name}</h3>
              <div className="flex flex-wrap gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-muted-foreground"
                >
                  <Move className="h-4 w-4 mr-1" />
                  Drag to move
                </Button>
                
                {selectedTable.status === 'Occupied' && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="text-green-600"
                    onClick={handleReleaseTable}
                    disabled={isReleasing}
                  >
                    {isReleasing ? "Checking..." : "Release Table"}
                  </Button>
                )}
                
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={() => setIsDeleteDialogOpen(true)}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Table</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the table "{selectedTable?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteTable}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default TableLayout;
