
import React from 'react';
import BlurCard from '@/components/ui/BlurCard';
import { CheckCircle2, Users, Clock, Coffee } from 'lucide-react';
import { TableItem } from '@/types/tables';

interface StatsProps {
  available: number;
  occupied: number;
  reserved: number;
  cleaning: number;
}

interface TableStatsComponentProps {
  tables: TableItem[];
  isLoading: boolean;
}

const TableStats: React.FC<TableStatsComponentProps> = ({ tables, isLoading }) => {
  // Calculate stats from tables
  const available = tables.filter(table => table.status === 'Available').length;
  const occupied = tables.filter(table => table.status === 'Occupied').length;
  const reserved = tables.filter(table => table.status === 'Reserved').length;
  const cleaning = tables.filter(table => table.status === 'Cleaning').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <BlurCard className="p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
            <CheckCircle2 className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold">{available}</h3>
            <p className="text-sm text-muted-foreground">Available Tables</p>
          </div>
        </div>
      </BlurCard>
      
      <BlurCard className="p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
            <Users className="h-6 w-6 text-red-600" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold">{occupied}</h3>
            <p className="text-sm text-muted-foreground">Occupied Tables</p>
          </div>
        </div>
      </BlurCard>
      
      <BlurCard className="p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
            <Clock className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold">{reserved}</h3>
            <p className="text-sm text-muted-foreground">Reserved Tables</p>
          </div>
        </div>
      </BlurCard>
      
      <BlurCard className="p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-yellow-100 flex items-center justify-center">
            <Coffee className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold">{cleaning}</h3>
            <p className="text-sm text-muted-foreground">Cleaning Tables</p>
          </div>
        </div>
      </BlurCard>
    </div>
  );
};

export default TableStats;
