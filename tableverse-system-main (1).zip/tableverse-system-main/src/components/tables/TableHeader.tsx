import React from 'react';
import { Plus, QrCode } from 'lucide-react';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { toast } from '@/hooks/use-toast';
import { generateTableQrCode } from '@/utils/qrCode';
import { TableItem } from '@/types/tables';

interface TableHeaderProps {
  handleAddTable: () => void;
  tables?: Array<{
    id: string;
    name: string;
    qr_code: string | null;
  }>;
  fetchTables?: () => Promise<void>;
}

const TableHeader: React.FC<TableHeaderProps> = ({ handleAddTable, tables = [], fetchTables = async () => {} }) => {
  const handleGenerateAllQRCodes = async () => {
    const tablesWithoutQR = tables.filter(t => !t.qr_code);
    if (tablesWithoutQR.length === 0) {
      toast({
        title: 'All tables have QR codes',
        description: 'All tables already have QR codes generated.',
      });
      return;
    }
    
    toast({
      title: 'Generating QR codes',
      description: `Generating QR codes for ${tablesWithoutQR.length} tables.`,
    });
    
    for (const table of tablesWithoutQR) {
      try {
        const qrCode = await generateTableQrCode(table.id);
        
        await fetch('/api/tables/update-qr', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ tableId: table.id, qrCode }),
        });
      } catch (error) {
        console.error('Error generating QR code:', error);
      }
    }
    
    fetchTables();
  };

  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight">Table Management</h1>
        <p className="text-muted-foreground">Monitor table status and generate QR codes for customer ordering.</p>
      </div>
      <div className="flex gap-2">
        <AnimatedButton onClick={handleAddTable}>
          <Plus className="mr-2 h-4 w-4" /> Add Table
        </AnimatedButton>
        <AnimatedButton variant="outline" onClick={handleGenerateAllQRCodes}>
          <QrCode className="mr-2 h-4 w-4" /> Generate All QR Codes
        </AnimatedButton>
      </div>
    </div>
  );
};

export default TableHeader;
