
import React from 'react';
import {
  TableIcon,
  Edit,
  QrCode,
  Eye,
  Trash2,
  UserRound,
  Plus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { TableItem } from '@/types/tables';
import { Skeleton } from '@/components/ui/skeleton';

interface TableListViewProps {
  tables: TableItem[];
  isLoading: boolean;
  handleAddTable: () => void;
  handleEditTable: (table: TableItem) => void;
  handleDeleteTable: (tableId: string, tableName: string) => void;
  generateQRCode: (tableId: string, tableName: string) => Promise<void>;
  viewQRCode: (qrCode: string, tableName: string, tableId: string) => void;
}

const TableListView: React.FC<TableListViewProps> = ({
  tables,
  isLoading,
  handleAddTable,
  handleEditTable,
  handleDeleteTable,
  generateQRCode,
  viewQRCode,
}) => {
  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-end">
          <Skeleton className="h-10 w-32" />
        </div>
        <Card>
          <CardContent className="p-0">
            <div className="p-6">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center py-4 space-x-4">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-[250px]" />
                    <Skeleton className="h-4 w-[200px]" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Empty state
  if (tables.length === 0) {
    return (
      <Card className="w-full text-center py-12">
        <CardContent className="flex flex-col items-center">
          <TableIcon className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No tables yet</h3>
          <p className="text-muted-foreground mb-6">
            Create your first table to get started
          </p>
          <Button onClick={handleAddTable}>
            <Plus className="h-4 w-4 mr-2" />
            Add Table
          </Button>
        </CardContent>
      </Card>
    );
  }

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Available':
        return <Badge variant="outline" className="bg-green-100 text-green-800">Available</Badge>;
      case 'Occupied':
        return <Badge variant="outline" className="bg-red-100 text-red-800">Occupied</Badge>;
      case 'Reserved':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Reserved</Badge>;
      case 'Cleaning':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Cleaning</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Format timestamp
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={handleAddTable}>
          <Plus className="h-4 w-4 mr-2" />
          Add Table
        </Button>
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Table Name</TableHead>
                <TableHead>Capacity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tables.map((table) => (
                <TableRow key={table.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <TableIcon className="h-4 w-4 mr-2 text-primary" />
                      {table.name}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <UserRound className="h-4 w-4 mr-1 text-muted-foreground" />
                      {table.capacity} seats
                    </div>
                  </TableCell>
                  <TableCell>{getStatusBadge(table.status)}</TableCell>
                  <TableCell>{formatDate(table.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditTable(table)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      {table.qr_code ? (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => viewQRCode(table.qr_code || '', table.name, table.id)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => generateQRCode(table.id, table.name)}
                        >
                          <QrCode className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => handleDeleteTable(table.id, table.name)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default TableListView;
