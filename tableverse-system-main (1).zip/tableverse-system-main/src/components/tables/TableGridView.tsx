
import React, { useState } from 'react';
import {
  TableIcon,
  Edit,
  UserRound,
  QrCode,
  Eye,
  Trash2,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { TableItem } from '@/types/tables';

interface TableGridViewProps {
  tables: TableItem[];
  isLoading: boolean;
  handleAddTable: () => void;
  handleEditTable: (table: TableItem) => void;
  handleUpdateStatus: (tableId: string, newStatus: string) => void;
  generateQRCode: (tableId: string, tableName: string) => Promise<void>;
  viewQRCode: (qrCode: string, tableName: string, tableId: string) => void;
  handleDeleteTable: (tableId: string, tableName: string) => void;
}

const TableGridView: React.FC<TableGridViewProps> = ({
  tables,
  isLoading,
  handleAddTable,
  handleEditTable,
  handleUpdateStatus,
  generateQRCode,
  viewQRCode,
  handleDeleteTable
}) => {
  const [hoveredTable, setHoveredTable] = useState<string | null>(null);
  
  // Loading skeletons
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="relative h-64">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-3/4" />
            </CardHeader>
            <CardContent className="space-y-2">
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-20 w-full" />
            </CardContent>
            <CardFooter>
              <Skeleton className="h-10 w-full" />
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  }
  
  // Empty state
  if (tables.length === 0) {
    return (
      <Card className="w-full text-center py-12">
        <CardContent className="flex flex-col items-center">
          <TableIcon className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No tables yet</h3>
          <p className="text-muted-foreground mb-6">
            Create your first table to get started
          </p>
          <Button onClick={handleAddTable}>
            <Plus className="h-4 w-4 mr-2" />
            Add Table
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  // Get badge color for table status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Available':
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200">Available</Badge>;
      case 'Occupied':
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-200">Occupied</Badge>;
      case 'Reserved':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-200">Reserved</Badge>;
      case 'Cleaning':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Cleaning</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Table listings
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {tables.map(table => (
        <Card 
          key={table.id} 
          className="relative"
          onMouseEnter={() => setHoveredTable(table.id)}
          onMouseLeave={() => setHoveredTable(null)}
        >
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center">
              <TableIcon className="h-5 w-5 mr-2 text-primary" />
              {table.name}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <UserRound className="h-4 w-4 text-muted-foreground mr-1" />
                <span className="text-sm">{table.capacity} seats</span>
              </div>
              <div>{getStatusBadge(table.status)}</div>
            </div>
            
            {/* Status actions */}
            {table.status === 'Available' ? (
              <div className="flex flex-wrap gap-1 mt-1">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs h-7 px-2 text-red-600"
                  onClick={() => handleUpdateStatus(table.id, 'Occupied')}
                >
                  Mark Occupied
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs h-7 px-2 text-blue-600"
                  onClick={() => handleUpdateStatus(table.id, 'Reserved')}
                >
                  Mark Reserved
                </Button>
              </div>
            ) : (
              <div className="flex flex-wrap gap-1 mt-1">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs h-7 px-2 text-green-600"
                  onClick={() => handleUpdateStatus(table.id, 'Available')}
                >
                  Mark Available
                </Button>
                {table.status === 'Occupied' && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-xs h-7 px-2 text-yellow-600"
                    onClick={() => handleUpdateStatus(table.id, 'Cleaning')}
                  >
                    Mark Cleaning
                  </Button>
                )}
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="text-xs"
              onClick={() => handleEditTable(table)}
            >
              <Edit className="h-3 w-3 mr-1" />
              Edit
            </Button>
            
            {table.qr_code ? (
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => viewQRCode(table.qr_code || '', table.name, table.id)}
              >
                <Eye className="h-3 w-3 mr-1" />
                View QR
              </Button>
            ) : (
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => generateQRCode(table.id, table.name)}
              >
                <QrCode className="h-3 w-3 mr-1" />
                Generate QR
              </Button>
            )}
          </CardFooter>
          
          {/* Delete button - shown on hover */}
          {hoveredTable === table.id && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-2 right-2 h-7 w-7 text-muted-foreground hover:text-destructive"
              onClick={() => handleDeleteTable(table.id, table.name)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </Card>
      ))}
      
      {/* Add table button */}
      <Card className="border-dashed border-2 hover:border-primary/50 cursor-pointer flex items-center justify-center min-h-[242px]" onClick={handleAddTable}>
        <div className="text-center space-y-2">
          <Plus className="h-8 w-8 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground font-medium">Add New Table</p>
        </div>
      </Card>
    </div>
  );
};

export default TableGridView;
