
import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { MenuItem as MenuItemType } from '@/types/tables';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface MenuItemProps {
  item: MenuItemType;
  onAddToCart: (item: MenuItemType) => void;
}

const MenuItem: React.FC<MenuItemProps> = ({ item, onAddToCart }) => {
  const { currency, isLoading } = useCurrency();
  
  useEffect(() => {
    console.log('MenuItem component - Using currency:', currency, 'for item:', item.name);
    console.log('Price formatted:', formatCurrency(item.price, currency));
  }, [currency, item.name, item.price]);
  
  // Function to render attribute badges
  const renderAttributes = () => {
    if (!item.attributes) return null;
    
    const { isVegan, isVegetarian, isGlutenFree, isSpicy, isChefChoice } = item.attributes;
    
    return (
      <div className="flex flex-wrap gap-1 mt-2">
        {isVegan && (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-xs">
            Vegan
          </Badge>
        )}
        {isVegetarian && !isVegan && (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-xs">
            Vegetarian
          </Badge>
        )}
        {isGlutenFree && (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">
            Gluten Free
          </Badge>
        )}
        {isSpicy && (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 text-xs">
            Spicy
          </Badge>
        )}
        {isChefChoice && (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 text-xs">
            Chef's Choice
          </Badge>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
      <div className="relative h-40 bg-gray-100 overflow-hidden">
        <img 
          src={item.imageUrl || `https://placehold.co/400x300/e4e9f6/404e8f?text=${encodeURIComponent(item.name)}`}
          alt={item.name}
          className="w-full h-full object-cover"
        />
        {!item.inStock && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="text-white font-medium bg-red-500 px-3 py-1 rounded">Out of Stock</span>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium">{item.name}</h3>
          <span className="font-semibold">{formatCurrency(item.price, currency)}</span>
        </div>
        
        <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
          {item.description || `A delicious ${item.name.toLowerCase()} prepared with fresh ingredients.`}
        </p>
        
        {renderAttributes()}
        
        <div className="mt-4 flex justify-end">
          <Button 
            variant="default" 
            size="sm" 
            className="px-3 py-1 h-8"
            onClick={() => onAddToCart(item)}
            disabled={!item.inStock}
          >
            <Plus className="mr-1 h-4 w-4" />
            Add to Order
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MenuItem;
