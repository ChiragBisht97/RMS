
import React, { useState, useEffect } from 'react';
import { Trash2, Minus, Plus, Edit, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { CartItem as CartItemType } from '@/types/orders';
import { formatCurrency } from '@/utils/formatCurrency';
import { useCurrency } from '@/hooks/useCurrency';

interface CartItemProps {
  item: CartItemType;
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveItem: (id: string) => void;
  onUpdateNotes?: (id: string, notes: string) => void;
  currency?: string;
}

const CartItem: React.FC<CartItemProps> = ({ 
  item, 
  onUpdateQuantity, 
  onRemoveItem,
  onUpdateNotes,
  currency: propCurrency
}) => {
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [notes, setNotes] = useState(item.notes || '');
  const { currency: hookCurrency } = useCurrency();
  
  // Use prop currency if provided, otherwise use from hook
  const currency = propCurrency || hookCurrency;

  useEffect(() => {
    console.log('CartItem component - Using currency:', currency, 'for item:', item.name);
    console.log('Price formatted for CartItem:', formatCurrency(item.price, currency));
  }, [currency, item.name, item.price]);

  const handleNotesUpdate = () => {
    if (onUpdateNotes) {
      onUpdateNotes(item.id, notes);
    }
    setIsEditingNotes(false);
  };

  // Fixed: Change the way we update quantity
  const handleUpdateQuantity = (change: number) => {
    const newQuantity = item.quantity + change;
    if (newQuantity <= 0) {
      onRemoveItem(item.id);
      return;
    }
    onUpdateQuantity(item.id, newQuantity);
  };

  return (
    <div className="border-b last:border-0 py-3">
      <div className="flex justify-between items-start mb-1">
        <div className="flex-1">
          <h4 className="font-medium">{item.name}</h4>
          {item.price_variation_name && (
            <p className="text-xs text-muted-foreground">
              Size: {item.price_variation_name}
            </p>
          )}
        </div>
        <div className="text-right">
          <span className="font-medium">
            {formatCurrency(item.price * item.quantity, currency)}
          </span>
          <p className="text-xs text-muted-foreground">
            {formatCurrency(item.price, currency)} each
          </p>
        </div>
      </div>
      
      {isEditingNotes ? (
        <div className="mt-2 mb-2">
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add special instructions..."
            className="text-sm min-h-[60px]"
          />
          <div className="flex justify-end mt-1">
            <Button 
              size="sm" 
              variant="outline" 
              className="h-7 text-xs"
              onClick={() => setIsEditingNotes(false)}
            >
              Cancel
            </Button>
            <Button 
              size="sm" 
              variant="default" 
              className="h-7 text-xs ml-2"
              onClick={handleNotesUpdate}
            >
              <Check className="h-3 w-3 mr-1" />
              Save
            </Button>
          </div>
        </div>
      ) : (
        item.notes && (
          <p className="text-xs text-muted-foreground italic mt-1 mb-2">
            Note: {item.notes}
          </p>
        )
      )}
      
      <div className="flex justify-between items-center mt-2">
        <div className="flex items-center space-x-1">
          <Button 
            variant="outline" 
            size="icon" 
            className="h-7 w-7"
            onClick={() => onRemoveItem(item.id)}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
          
          {onUpdateNotes && (
            <Button 
              variant="outline" 
              size="icon" 
              className="h-7 w-7"
              onClick={() => setIsEditingNotes(true)}
            >
              <Edit className="h-3 w-3" />
            </Button>
          )}
        </div>
        
        <div className="flex items-center">
          <Button 
            variant="outline" 
            size="icon" 
            className="h-7 w-7 rounded-r-none"
            onClick={() => handleUpdateQuantity(-1)}
            disabled={item.quantity <= 1}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <div className="w-8 h-7 flex items-center justify-center border-y border-input">
            {item.quantity}
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            className="h-7 w-7 rounded-l-none"
            onClick={() => handleUpdateQuantity(1)}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
