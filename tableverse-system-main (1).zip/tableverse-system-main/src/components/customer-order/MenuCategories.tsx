
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface MenuCategoriesProps {
  categories: Array<{id: string; name: string}>;
  currentTab: string | null;
  onTabChange: (value: string) => void;
  showAllItemsOption?: boolean;
}

const MenuCategories: React.FC<MenuCategoriesProps> = ({ 
  categories, 
  currentTab, 
  onTabChange,
  showAllItemsOption = false
}) => {
  if (!currentTab && categories.length > 0) {
    // Set a default tab if none is selected
    onTabChange(categories[0].id);
  }

  // Filter out duplicate "all items" categories if they exist
  const uniqueCategories = categories.filter((category, index, self) => 
    index === self.findIndex((c) => c.id === category.id)
  );

  return (
    <Tabs value={currentTab || ''} onValueChange={onTabChange} className="w-full">
      <TabsList className="flex flex-wrap mb-4 h-auto">
        {showAllItemsOption && (
          <TabsTrigger key="all-items" value="all-items" className="mb-1 mr-1">
            All Items
          </TabsTrigger>
        )}
        {uniqueCategories.map(category => (
          <TabsTrigger key={category.id} value={category.id} className="mb-1 mr-1">
            {category.name}
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
};

export default MenuCategories;
