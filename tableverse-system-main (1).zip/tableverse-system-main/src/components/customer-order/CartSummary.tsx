
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ShoppingCart, CreditCard, Smartphone, Store, RefreshCcw } from 'lucide-react';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import CartItem from './CartItem';
import { CartItem as CartItemType } from '@/types/orders';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';
import { toast } from '@/hooks/use-toast';

interface CartSummaryProps {
  cart: CartItemType[];
  tableName: string;
  subtotal: number;
  tax: number;
  total: number;
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveItem: (id: string) => void;
  onPlaceOrder: () => void;
  onResetOrder?: () => void;
  applyServiceCharge?: boolean;
  serviceChargePercentage?: number;
  serviceCharge?: number;
  isLoading?: boolean;
}

const CartSummary: React.FC<CartSummaryProps> = ({
  cart,
  tableName,
  subtotal,
  tax,
  total,
  onUpdateQuantity,
  onRemoveItem,
  onPlaceOrder,
  onResetOrder,
  applyServiceCharge = false,
  serviceChargePercentage = 0,
  serviceCharge = 0,
  isLoading = false
}) => {
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const { currency, isLoading: currencyLoading } = useCurrency();
  const [refreshing, setRefreshing] = useState(false);
  
  useEffect(() => {
    console.log('CartSummary component - Using currency:', currency);
    console.log('Subtotal formatted:', formatCurrency(subtotal, currency));
    console.log('Tax formatted:', formatCurrency(tax, currency));
    console.log('Total formatted:', formatCurrency(total, currency));
  }, [currency, subtotal, tax, total]);
  
  const handlePlaceOrder = () => {
    if (cart.length === 0) return;
    setPaymentDialogOpen(true);
  };
  
  const handlePaymentOptionSelected = (method: string) => {
    setPaymentDialogOpen(false);
    onPlaceOrder();
    
    if (method === 'counter') {
      alert('Please proceed to the counter to complete your payment.');
    } else if (method === 'card') {
      alert('Card payment functionality would be implemented here.');
    } else if (method === 'mobile') {
      alert('Mobile payment functionality would be implemented here.');
    }
  };

  const forceRefreshCurrency = () => {
    setRefreshing(true);
    // Force a re-render by triggering an event
    window.dispatchEvent(new CustomEvent('refresh-currency'));
    
    // Wait a bit to simulate refresh
    setTimeout(() => {
      setRefreshing(false);
      toast({
        title: "Currency updated",
        description: "The currency display has been refreshed.",
      });
    }, 1000);
  };

  return (
    <>
      <Card className="sticky top-4">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Your Order
            </CardTitle>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={forceRefreshCurrency}
              disabled={refreshing}
              title="Refresh currency display"
            >
              <RefreshCcw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            </Button>
          </div>
          <CardDescription>{tableName}</CardDescription>
        </CardHeader>
        <CardContent>
          {cart.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              <ShoppingCart className="mx-auto h-8 w-8 mb-2 opacity-50" />
              <p>Your order is empty</p>
              <p className="text-sm">Add items from the menu</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[350px] overflow-y-auto">
              {cart.map(item => (
                <CartItem
                  key={item.id}
                  item={item}
                  onUpdateQuantity={onUpdateQuantity}
                  onRemoveItem={onRemoveItem}
                  currency={currency}
                />
              ))}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col">
          <div className="w-full pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Subtotal</span>
              <span>{formatCurrency(subtotal, currency)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Tax (8%)</span>
              <span>{formatCurrency(tax, currency)}</span>
            </div>
            {applyServiceCharge && serviceCharge > 0 && (
              <div className="flex justify-between text-sm">
                <span>Service Charge ({serviceChargePercentage}%)</span>
                <span>{formatCurrency(serviceCharge, currency)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold pt-2 border-t">
              <span>Total</span>
              <span>{formatCurrency(total, currency)}</span>
            </div>
            {currencyLoading && (
              <div className="text-xs text-center text-muted-foreground pt-2">
                Loading currency settings...
              </div>
            )}
          </div>
          
          <AnimatedButton 
            className="w-full mt-6" 
            disabled={cart.length === 0 || isLoading || currencyLoading}
            glint
            onClick={handlePlaceOrder}
          >
            {isLoading ? 'Processing...' : 'Place Order & Pay'}
          </AnimatedButton>
          
          {onResetOrder && (
            <Button 
              variant="outline"
              className="w-full mt-2" 
              onClick={onResetOrder}
              disabled={isLoading}
            >
              Start New Order
            </Button>
          )}
        </CardFooter>
      </Card>
      
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Choose Payment Method</DialogTitle>
            <DialogDescription>
              Select how you would like to pay for your order.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <Button 
              onClick={() => handlePaymentOptionSelected('card')}
              className="flex items-center justify-center gap-2" 
              size="lg"
              disabled={isLoading}
            >
              <CreditCard className="h-5 w-5" />
              Pay with Card
            </Button>
            
            <Button 
              onClick={() => handlePaymentOptionSelected('mobile')}
              className="flex items-center justify-center gap-2" 
              size="lg"
              disabled={isLoading}
            >
              <Smartphone className="h-5 w-5" />
              Pay with Mobile App
            </Button>
            
            <Button 
              onClick={() => handlePaymentOptionSelected('counter')}
              className="flex items-center justify-center gap-2" 
              size="lg"
              variant="outline"
              disabled={isLoading}
            >
              <Store className="h-5 w-5" />
              Pay at Counter
            </Button>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setPaymentDialogOpen(false)} disabled={isLoading}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CartSummary;
