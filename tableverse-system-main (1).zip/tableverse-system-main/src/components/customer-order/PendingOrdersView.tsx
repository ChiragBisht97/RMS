
import React from 'react';
import { Button } from '@/components/ui/button';
import { formatTimeAgo } from '@/utils/orders';
import { getStatusColor } from '@/utils/orders';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, Clock, CheckCircle2, ArrowLeft } from 'lucide-react';
import BlurCard from '@/components/ui/BlurCard';
import { OrderWithItems } from '@/types/orders';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface PendingOrdersViewProps {
  orders: OrderWithItems[];
  onBack: () => void;
}

const PendingOrdersView: React.FC<PendingOrdersViewProps> = ({ orders, onBack }) => {
  const { currency } = useCurrency();
  
  // Filter only active orders (Pending, In Progress, Ready)
  const activeOrders = orders.filter(order => 
    ['Pending', 'In Progress', 'Ready'].includes(order.status)
  );
  
  if (!activeOrders || activeOrders.length === 0) {
    return (
      <BlurCard className="p-6 text-center">
        <AlertCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-medium mb-2">No Active Orders</h2>
        <p className="text-muted-foreground mb-6">
          You don't have any active orders at this table.
        </p>
        <Button onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Return to Menu
        </Button>
      </BlurCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Your Active Orders</h2>
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Menu
        </Button>
      </div>
      
      {activeOrders.map((order) => (
        <BlurCard key={order.order_id} className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-medium">
                Order #{order.order_id.slice(-4)}
              </h3>
              <p className="text-sm text-muted-foreground">
                {formatTimeAgo(order.created_at)}
              </p>
            </div>
            <div className="flex gap-2">
              <Badge className={getStatusColor(order.status)}>
                {order.status}
              </Badge>
              <Badge className={
                order.payment_status === 'Unpaid' ? 'bg-yellow-100 text-yellow-800' :
                order.payment_status === 'Paid' ? 'bg-green-100 text-green-800' :
                'bg-blue-100 text-blue-800'
              }>
                {order.payment_status}
              </Badge>
            </div>
          </div>
          
          <div className="border-t border-border pt-4">
            <h4 className="font-medium mb-2">Order Items</h4>
            <ul className="divide-y">
              {order.items && order.items.map((item) => (
                <li key={item.item_id} className="py-2 flex justify-between">
                  <div>
                    <span className="font-medium">{item.quantity}x</span> {item.name || 'Unknown Item'}
                    {item.notes && <p className="text-xs text-muted-foreground">Note: {item.notes}</p>}
                  </div>
                  <div className="text-right">
                    {formatCurrency(item.price * item.quantity, currency)}
                  </div>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="border-t border-border mt-4 pt-4">
            <div className="flex justify-between font-medium">
              <span>Total:</span>
              <span>{formatCurrency(order.total, currency)}</span>
            </div>
          </div>
          
          <div className="mt-4 text-center">
            {order.status === 'Pending' && (
              <div className="flex items-center justify-center text-yellow-600">
                <Clock className="h-5 w-5 mr-2" />
                <span>Your order has been received and is being processed</span>
              </div>
            )}
            {order.status === 'In Progress' && (
              <div className="flex items-center justify-center text-blue-600">
                <AlertCircle className="h-5 w-5 mr-2" />
                <span>Your order is being prepared</span>
              </div>
            )}
            {order.status === 'Ready' && (
              <div className="flex items-center justify-center text-green-600">
                <CheckCircle2 className="h-5 w-5 mr-2" />
                <span>Your order is ready to be served</span>
              </div>
            )}
          </div>
        </BlurCard>
      ))}
      
      <div className="flex justify-center mt-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Menu
        </Button>
      </div>
    </div>
  );
};

export default PendingOrdersView;
