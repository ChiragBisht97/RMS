
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface CustomerInfoFormProps {
  customerName: string;
  customerPhone: string;
  onChange: (name: string, value: string) => void;
}

const CustomerInfoForm: React.FC<CustomerInfoFormProps> = ({
  customerName,
  customerPhone,
  onChange
}) => {
  return (
    <div className="bg-card p-5 rounded-lg border mb-4">
      <h3 className="text-lg font-medium mb-4">Your Information (Optional)</h3>
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="customer-name">Name</Label>
          <Input
            id="customer-name"
            placeholder="Your name (optional)"
            value={customerName}
            onChange={(e) => onChange('name', e.target.value)}
          />
        </div>
        
        <div>
          <Label htmlFor="customer-phone">Phone</Label>
          <Input
            id="customer-phone"
            placeholder="Your phone (optional)"
            value={customerPhone}
            onChange={(e) => onChange('phone', e.target.value)}
            type="tel"
          />
        </div>
      </div>
    </div>
  );
};

export default CustomerInfoForm;
