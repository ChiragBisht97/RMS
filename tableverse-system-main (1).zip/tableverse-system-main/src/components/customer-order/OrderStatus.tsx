
import React from 'react';
import BlurCard from '@/components/ui/BlurCard';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, AlertCircle, CheckCircle2, DollarSign, ArrowLeft } from 'lucide-react';
import { OrderStatus as OrderStatusType } from '@/types/orders';

interface OrderStatusProps {
  status: string | null;
  paymentStatus?: string | null;
  orderId?: string;
  onNewOrder: () => void;
}

const OrderStatus: React.FC<OrderStatusProps> = ({ status, paymentStatus, orderId, onNewOrder }) => {
  if (!status) return null;

  const orderNumber = orderId 
    ? orderId.slice(-4) 
    : Math.floor(1000 + Math.random() * 9000).toString();
  
  const renderPaymentBadge = () => {
    if (!paymentStatus) return null;
    
    return (
      <Badge className={`
        ${paymentStatus === 'Unpaid' ? 'bg-yellow-100 text-yellow-800' : ''}
        ${paymentStatus === 'Prepaid' ? 'bg-green-100 text-green-800' : ''}
        ${paymentStatus === 'Paid' ? 'bg-blue-100 text-blue-800' : ''}
        ml-2
      `}>
        {paymentStatus}
      </Badge>
    );
  };
  
  // Normalize status to handle case variations
  const normalizedStatus = status.toLowerCase();
  
  return (
    <BlurCard className="mb-8 p-6 text-center">
      <div className="mb-4">
        {(normalizedStatus === 'pending') && (
          <Clock className="h-16 w-16 text-yellow-500 mx-auto animate-pulse" />
        )}
        {(normalizedStatus === 'in progress' || normalizedStatus === 'in_progress') && (
          <AlertCircle className="h-16 w-16 text-blue-500 mx-auto animate-pulse" />
        )}
        {(normalizedStatus === 'ready') && (
          <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto" />
        )}
        {paymentStatus === 'Prepaid' && (
          <DollarSign className="h-10 w-10 text-green-500 mx-auto mt-2" />
        )}
      </div>
      
      <h2 className="text-2xl font-medium mb-2">
        {normalizedStatus === 'pending' && 'Order Received'}
        {(normalizedStatus === 'in progress' || normalizedStatus === 'in_progress') && 'Preparing Your Order'}
        {normalizedStatus === 'ready' && 'Your Order is Ready!'}
      </h2>
      
      <p className="text-muted-foreground mb-4">
        {normalizedStatus === 'pending' && 'Your order has been sent to the kitchen.'}
        {(normalizedStatus === 'in progress' || normalizedStatus === 'in_progress') && 'Our chefs are working on your delicious meal.'}
        {normalizedStatus === 'ready' && 'A staff member will bring it to your table shortly.'}
      </p>
      
      <div className="flex items-center justify-center gap-2 mb-6">
        <Badge className={`
          ${normalizedStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
          ${(normalizedStatus === 'in progress' || normalizedStatus === 'in_progress') ? 'bg-blue-100 text-blue-800' : ''}
          ${normalizedStatus === 'ready' ? 'bg-green-100 text-green-800' : ''}
        `}>
          Order #{orderNumber}
        </Badge>
        {renderPaymentBadge()}
      </div>
      
      <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
        <Button 
          variant="outline"
          onClick={onNewOrder}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Menu
        </Button>
        <Button 
          variant="default"
          onClick={onNewOrder}
        >
          Place Another Order
        </Button>
      </div>
    </BlurCard>
  );
};

export default OrderStatus;
