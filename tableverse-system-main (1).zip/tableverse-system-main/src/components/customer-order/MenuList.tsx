
import React from 'react';
import MenuItem from './MenuItem';
import { MenuItem as MenuItemType } from '@/types/tables';

interface MenuListProps {
  items: MenuItemType[];
  onAddToCart: (item: MenuItemType) => void;
  showAllItems?: boolean;
}

const MenuList: React.FC<MenuListProps> = ({ items, onAddToCart, showAllItems = false }) => {
  if (!items || items.length === 0) {
    return (
      <div className="text-center p-8 border border-dashed rounded-lg">
        <p className="text-muted-foreground">
          {showAllItems ? "No menu items found." : "No items in this category."}
        </p>
      </div>
    );
  }

  // If showing all items, we want to organize them by category
  if (showAllItems) {
    // Group items by category
    const itemsByCategory = items.reduce((acc, item) => {
      const category = item.categoryName || 'Uncategorized';
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(item);
      return acc;
    }, {} as Record<string, MenuItemType[]>);

    return (
      <div className="space-y-6">
        {Object.entries(itemsByCategory).map(([category, categoryItems]) => (
          <div key={category}>
            <h3 className="font-medium text-lg mb-3 border-b pb-2">{category}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
              {categoryItems.map((item) => (
                <MenuItem key={item.id} item={item} onAddToCart={onAddToCart} />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
      {items.map((item) => (
        <MenuItem key={item.id} item={item} onAddToCart={onAddToCart} />
      ))}
    </div>
  );
};

export default MenuList;
