
import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface FloatingCartButtonProps {
  itemCount: number;
  total: number;
  onClick: () => void;
}

const FloatingCartButton: React.FC<FloatingCartButtonProps> = ({ 
  itemCount, 
  total,
  onClick
}) => {
  const { currency } = useCurrency();

  useEffect(() => {
    console.log('FloatingCartButton - Using currency:', currency);
    console.log('Total formatted in FloatingCartButton:', formatCurrency(total, currency));
  }, [currency, total]);

  if (itemCount === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50">
      <Button 
        onClick={onClick}
        className="rounded-full px-4 py-6 shadow-lg flex items-center"
        size="lg"
      >
        <ShoppingCart className="h-5 w-5 mr-2" />
        <span className="font-medium">{itemCount} {itemCount === 1 ? 'item' : 'items'}</span>
        <span className="mx-2">•</span>
        <span className="font-bold">{formatCurrency(total, currency)}</span>
      </Button>
    </div>
  );
};

export default FloatingCartButton;
