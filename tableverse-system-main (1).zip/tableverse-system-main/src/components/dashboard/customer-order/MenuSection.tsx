
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Plus } from 'lucide-react';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';
import { Badge } from '@/components/ui/badge';
import ItemVariationDialog from '@/components/pos/ItemVariationDialog';

interface MenuSectionProps {
  categories: Array<{id: string; name: string}>;
  currentTab: string;
  setCurrentTab: (value: string) => void;
  menuItems: any[];
  addToCart: (item: any) => void;
  isLoading: boolean;
}

const MenuSection: React.FC<MenuSectionProps> = ({
  categories,
  currentTab,
  setCurrentTab,
  menuItems,
  addToCart,
  isLoading
}) => {
  // Filter items based on selected category
  const filteredItems = currentTab === 'all'
    ? menuItems
    : menuItems.filter(item => item.category === currentTab);

  // State for variation selection dialog
  const [selectedItem, setSelectedItem] = useState<any | null>(null);
  const [isVariationDialogOpen, setIsVariationDialogOpen] = useState(false);

  // Handle menu item click to check for variations
  const handleMenuItemClick = (item: any) => {
    if (item.variations && item.variations.length > 0) {
      setSelectedItem(item);
      setIsVariationDialogOpen(true);
    } else {
      addToCart(item);
    }
  };

  // Handle variation selection
  const handleVariationSelect = (item: any, variation: any) => {
    if (!item) return;
    
    // Generate a unique ID for this item+variation combination
    const variationId = `${item.id}-${variation.size}`;
    
    // Create a modified item with the selected variation and unique ID
    const itemWithVariation = {
      ...item,
      id: variationId, // This ensures each size variation can be added separately to cart
      price: Number(variation.price),
      selectedVariation: variation.size,
      notes: `Size: ${variation.size}`
    };
    
    addToCart(itemWithVariation);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="category-selection">
        <ScrollArea className="w-full pb-4">
          <div className="flex flex-wrap gap-2 pb-2">
            <Button 
              variant={currentTab === 'all' ? 'default' : 'outline'} 
              size="sm"
              className="rounded-full"
              onClick={() => setCurrentTab('all')}
            >
              All Items
            </Button>
            {categories.map(category => (
              <Button 
                key={category.id}
                variant={currentTab === category.id ? 'default' : 'outline'} 
                size="sm"
                className="rounded-full"
                onClick={() => setCurrentTab(category.id)}
              >
                {category.name}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
      
      <div className="space-y-4">
        {filteredItems.length > 0 ? (
          filteredItems.map(item => (
            <MenuItem 
              key={item.id} 
              item={item} 
              onAddToCart={handleMenuItemClick} 
            />
          ))
        ) : (
          <div className="text-center py-8 border rounded-lg">
            <p className="text-muted-foreground">No items in this category</p>
          </div>
        )}
      </div>

      <ItemVariationDialog
        open={isVariationDialogOpen}
        onOpenChange={setIsVariationDialogOpen}
        item={selectedItem}
        onSelectVariation={handleVariationSelect}
      />
    </div>
  );
};

// MenuItem component
interface MenuItemProps {
  item: any;
  onAddToCart: (item: any) => void;
}

const MenuItem: React.FC<MenuItemProps> = ({ item, onAddToCart }) => {
  const { currency } = useCurrency();
  const hasVariations = item.variations && item.variations.length > 0;
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="grid grid-cols-1 md:grid-cols-3">
        <div className="bg-muted h-36 md:h-auto">
          <img 
            src={item.image || `https://placehold.co/300x200/e4e9f6/404e8f?text=${encodeURIComponent(item.name)}`} 
            alt={item.name} 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="md:col-span-2 p-4 flex flex-col">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium">{item.name}</h3>
              {hasVariations && (
                <Badge variant="outline" className="ml-1">Multiple sizes</Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
              {item.description}
            </p>
            <p className="font-medium mt-2">
              {hasVariations 
                ? `${formatCurrency(Number(item.variations[0].price), currency)} - ${formatCurrency(Number(item.variations[item.variations.length-1].price), currency)}`
                : formatCurrency(Number(item.price), currency)
              }
            </p>
          </div>
          <div className="flex justify-end mt-4">
            <AnimatedButton 
              onClick={() => onAddToCart(item)}
            >
              <Plus className="mr-2 h-4 w-4" />
              {hasVariations ? 'Select Option' : 'Add to Order'}
            </AnimatedButton>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default MenuSection;
