
import React from 'react';
import { Button } from '@/components/ui/button';
import BlurCard from '@/components/ui/BlurCard';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle2, Clock } from 'lucide-react';

interface OrderStatusSectionProps {
  currentOrderStatus: string | null;
  selectedTable: string | null;
  tables: any[];
  resetOrder: () => void;
}

const OrderStatusSection: React.FC<OrderStatusSectionProps> = ({
  currentOrderStatus,
  selectedTable,
  tables,
  resetOrder
}) => {
  if (!currentOrderStatus) return null;

  return (
    <BlurCard className="mb-8 p-6 text-center">
      <div className="mb-4">
        {currentOrderStatus === 'pending' && (
          <Clock className="h-16 w-16 text-yellow-500 mx-auto animate-pulse" />
        )}
        {currentOrderStatus === 'preparing' && (
          <AlertCircle className="h-16 w-16 text-blue-500 mx-auto animate-pulse" />
        )}
        {currentOrderStatus === 'ready' && (
          <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto" />
        )}
      </div>
      
      <h2 className="text-2xl font-medium mb-2">
        {currentOrderStatus === 'pending' && 'Order Received'}
        {currentOrderStatus === 'preparing' && 'Preparing Order'}
        {currentOrderStatus === 'ready' && 'Order is Ready!'}
      </h2>
      
      <p className="text-muted-foreground mb-4">
        {currentOrderStatus === 'pending' && 'Your order has been sent to the kitchen.'}
        {currentOrderStatus === 'preparing' && 'The kitchen is working on the order.'}
        {currentOrderStatus === 'ready' && 'The order is ready to be served.'}
      </p>
      
      <Badge className={`
        ${currentOrderStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
        ${currentOrderStatus === 'preparing' ? 'bg-blue-100 text-blue-800' : ''}
        ${currentOrderStatus === 'ready' ? 'bg-green-100 text-green-800' : ''}
      `}>
        Table {tables.find(t => t.id === selectedTable)?.name || ''}
      </Badge>
      
      <div className="mt-6">
        <Button 
          variant="outline"
          onClick={resetOrder}
        >
          Place Another Order
        </Button>
      </div>
    </BlurCard>
  );
};

export default OrderStatusSection;
