
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TableIcon } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface TableSelectionProps {
  selectedTable: string | null;
  setSelectedTable: (value: string) => void;
  tables: Array<{tb_id: string; tb_name: string}>;
  isLoading?: boolean;
}

const TableSelection: React.FC<TableSelectionProps> = ({
  selectedTable,
  setSelectedTable,
  tables,
  isLoading = false
}) => {
  return (
    <Card className="w-full max-w-md">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center">
          <TableIcon className="h-5 w-5 mr-2 text-primary" />
          Select Table
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-10 w-full" />
        ) : (
          <Select 
            value={selectedTable || ""} 
            onValueChange={setSelectedTable}
            disabled={isLoading}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a table" />
            </SelectTrigger>
            <SelectContent>
              {tables.length > 0 ? (
                tables.map(table => (
                  <SelectItem key={table.tb_id} value={table.tb_id}>
                    {table.tb_name}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="none" disabled>
                  No available tables
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        )}
      </CardContent>
    </Card>
  );
};

export default TableSelection;
