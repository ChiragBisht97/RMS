
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { Minus, Plus, ShoppingCart, XCircle } from 'lucide-react';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface CartSectionProps {
  cart: CartItem[];
  selectedTable: string | null;
  tables: any[];
  subtotal: number;
  tax: number;
  total: number;
  serviceCharge: number;
  updateQuantity: (id: string, change: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  placeOrder: () => void;
  applyServiceCharge?: boolean;
  serviceChargePercentage?: number;
}

const CartSection: React.FC<CartSectionProps> = ({
  cart,
  selectedTable,
  tables,
  subtotal,
  tax,
  total,
  serviceCharge,
  updateQuantity,
  removeFromCart,
  clearCart,
  placeOrder,
  applyServiceCharge = false,
  serviceChargePercentage = 0
}) => {
  const { currency } = useCurrency();
  
  return (
    <Card className="sticky top-4">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Order Summary
          </CardTitle>
          {cart.length > 0 && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearCart}
              className="h-8 px-2 text-muted-foreground hover:text-destructive"
            >
              <XCircle className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
        <CardDescription>
          {selectedTable ? (
            <span>Table {tables.find(t => t.tb_id === selectedTable)?.tb_name}</span>
          ) : (
            <span className="text-amber-500">Please select a table</span>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {cart.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">
            <ShoppingCart className="mx-auto h-8 w-8 mb-2 opacity-50" />
            <p>The order is empty</p>
            <p className="text-sm">Add items from the menu</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-[350px] overflow-y-auto">
            {cart.map(item => (
              <CartItem 
                key={item.id}
                item={item}
                updateQuantity={updateQuantity}
                removeFromCart={removeFromCart}
                currency={currency}
              />
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col">
        <div className="w-full pt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>{formatCurrency(subtotal, currency)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Tax (8%)</span>
            <span>{formatCurrency(tax, currency)}</span>
          </div>
          {applyServiceCharge && serviceCharge > 0 && (
            <div className="flex justify-between text-sm">
              <span>Service Charge ({serviceChargePercentage}%)</span>
              <span>{formatCurrency(serviceCharge, currency)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold pt-2 border-t">
            <span>Total</span>
            <span>{formatCurrency(total, currency)}</span>
          </div>
        </div>
        
        <AnimatedButton 
          className="w-full mt-6" 
          disabled={cart.length === 0 || !selectedTable}
          glint
          onClick={placeOrder}
        >
          Place Order
        </AnimatedButton>
      </CardFooter>
    </Card>
  );
};

interface CartItemProps {
  item: CartItem;
  updateQuantity: (id: string, change: number) => void;
  removeFromCart: (id: string) => void;
  currency?: string;
}

const CartItem: React.FC<CartItemProps> = ({ item, updateQuantity, removeFromCart, currency = '$' }) => {
  return (
    <div className="flex justify-between items-center py-2 border-b">
      <div className="flex-1">
        <p className="font-medium">{item.name}</p>
        <p className="text-sm text-muted-foreground">{formatCurrency(Number(item.price), currency)} each</p>
      </div>
      <div className="flex items-center gap-2">
        <button 
          className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center"
          onClick={() => updateQuantity(item.id, -1)}
        >
          <Minus className="h-3 w-3" />
        </button>
        <span className="w-6 text-center">{item.quantity}</span>
        <button 
          className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center"
          onClick={() => updateQuantity(item.id, 1)}
        >
          <Plus className="h-3 w-3" />
        </button>
        <button 
          className="h-7 w-7 rounded-full hover:bg-muted flex items-center justify-center ml-1"
          onClick={() => removeFromCart(item.id)}
        >
          <XCircle className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>
    </div>
  );
};

export default CartSection;
