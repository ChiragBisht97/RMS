
import React from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingCart, XCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface MobileCartSummaryProps {
  cart: Array<{id: string; quantity: number}>;
  total: number;
  clearCart: () => void;
  isLoading?: boolean;
}

const MobileCartSummary: React.FC<MobileCartSummaryProps> = ({
  cart,
  total,
  clearCart,
  isLoading = false
}) => {
  const { currency } = useCurrency();
  
  if (isLoading) {
    return (
      <div className="fixed bottom-0 left-0 right-0 bg-background border-t z-10 p-4 md:hidden">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-4 w-20 mb-2" />
            <Skeleton className="h-5 w-16" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="h-9 w-24" />
            <Skeleton className="h-9 w-9" />
          </div>
        </div>
      </div>
    );
  }

  if (cart.length === 0) return null;
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t z-10 p-4 md:hidden">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">{cart.reduce((sum, item) => sum + item.quantity, 0)} {cart.length === 1 ? 'item' : 'items'}</p>
          <p className="font-bold">{formatCurrency(total, currency)}</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => document.getElementById('cart-section')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            View Cart
          </Button>
          <Button 
            variant="destructive" 
            size="sm"
            onClick={clearCart}
          >
            <XCircle className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MobileCartSummary;
