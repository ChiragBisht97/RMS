
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { useAuth } from '@/contexts/AuthContext';
import { useSidebarState } from '@/hooks/useSidebarState';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { 
  BarChart4, 
  Utensils, 
  ClipboardList, 
  Table, 
  CreditCard, 
  Users,
  UserCog,
  QrCode,
  Settings,
  LogOut,
  ChevronRight,
  Menu,
  X,
  FileBarChart
} from 'lucide-react';

const DashboardSidebar = () => {
  const { sidebarCollapsed, toggleSidebar } = useSidebarState();
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut, user, profile } = useAuth();

  const isActive = (path: string) => location.pathname === path;

  const toggleMobileSidebar = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleLogout = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      await signOut();
      // Navigation is handled in the signOut function
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Fetch user permissions
  const { data: permissions } = useQuery({
    queryKey: ['user-permissions', user?.id],
    queryFn: async () => {
      if (!user) return null;
      
      // Use type assertion to work around the TypeScript issue
      const { data, error } = await (supabase
        .from('user_permissions') as any)
        .select('module, enabled')
        .eq('user_id', user.id);
      
      if (error) {
        console.error('Error fetching permissions:', error);
        return null;
      }
      
      // Convert to a map for easier lookup
      const permissionsMap: Record<string, boolean> = {};
      if (data) {
        data.forEach((item: any) => {
          permissionsMap[item.module] = item.enabled;
        });
      }
      
      return permissionsMap;
    },
    enabled: !!user
  });

  // Define all possible menu items
  const allMenuItems = [
    {
      name: 'Dashboard',
      path: '/dashboard',
      icon: BarChart4,
      module: 'dashboard', // Dashboard is always visible
    },
    {
      name: 'Menus',
      path: '/dashboard/menus',
      icon: Utensils,
      module: 'menus',
    },
    {
      name: 'Orders',
      path: '/dashboard/orders',
      icon: ClipboardList,
      module: 'orders',
    },
    {
      name: 'Tables',
      path: '/dashboard/tables',
      icon: Table,
      module: 'tables',
    },
    {
      name: 'Point of Sale',
      path: '/dashboard/pos',
      icon: CreditCard,
      module: 'pos',
    },
    {
      name: 'Reports',
      path: '/dashboard/reports',
      icon: FileBarChart,
      module: 'reports',
    },
    {
      name: 'Users',
      path: '/dashboard/users',
      icon: Users,
      module: 'users',
      adminOnly: false, // Changed from true to false - allow all users to see Users list
    },
    {
      name: 'User Management',
      path: '/dashboard/user-management',
      icon: UserCog,
      module: 'user_management',
      adminOnly: true, // Only for admins and owners
    },
    {
      name: 'Customer Order',
      path: '/dashboard/customer-order',
      icon: QrCode,
      module: 'customer_order',
    },
  ];

  // Filter menu items based on user permissions
  const menuItems = allMenuItems.filter(item => {
    // Dashboard is always visible to all users
    if (item.module === 'dashboard') return true;
    
    // Users page is visible to all authenticated users
    if (item.module === 'users' && !item.adminOnly) return true;
    
    // Admin-only items are only visible to admins and owners
    if (item.adminOnly && !(profile?.is_owner || profile?.pro_role === 'admin')) {
      return false;
    }
    
    // If user is owner or admin, they can access everything
    if (profile?.is_owner || profile?.pro_role === 'admin') {
      return true;
    }
    
    // For normal users, check permissions
    // If we don't have permissions data yet, hide the item to be safe
    if (!permissions) return false;
    
    // If there's a specific permission for this module, use it
    if (item.module in permissions) {
      return permissions[item.module];
    }
    
    // Default to not showing the item if there's no explicit permission
    return false;
  });

  return (
    <>
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={toggleMobileSidebar}
          className="p-2 rounded-md bg-primary text-primary-foreground shadow-md"
          aria-label={mobileOpen ? "Close sidebar" : "Open sidebar"}
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      <div 
        className={cn(
          "fixed inset-0 bg-black/50 z-40 lg:hidden transition-opacity duration-300",
          mobileOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={() => setMobileOpen(false)}
      />

      <aside 
        className={cn(
          "fixed top-0 left-0 h-full z-40 bg-sidebar transition-all duration-300 ease-in-out border-r border-sidebar-border shadow-sm",
          sidebarCollapsed ? "w-20" : "w-64",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="flex flex-col h-full">
          <div className={cn(
            "flex h-16 items-center px-4 border-b border-sidebar-border",
            sidebarCollapsed ? "justify-center" : "justify-between"
          )}>
            <Link to="/dashboard" className="flex items-center">
              {sidebarCollapsed ? (
                <span className="text-xl font-display font-bold text-primary">P</span>
              ) : (
                <>
                  <span className="text-xl font-display font-bold text-sidebar-foreground">Plate</span>
                  <span className="text-primary font-display font-bold text-xl">Sync</span>
                </>
              )}
            </Link>
            
            {!sidebarCollapsed && (
              <button 
                onClick={toggleSidebar}
                className="p-1 rounded-md hover:bg-sidebar-accent"
                aria-label="Collapse sidebar"
              >
                <ChevronRight size={16} />
              </button>
            )}
          </div>
          
          <nav className="flex-1 overflow-y-auto py-4 px-3">
            <ul className="space-y-1">
              {menuItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={cn(
                      "flex items-center py-2 px-3 rounded-md transition-colors",
                      sidebarCollapsed ? "justify-center" : "justify-start",
                      isActive(item.path) 
                        ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                        : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground"
                    )}
                  >
                    <item.icon className={cn("h-5 w-5", isActive(item.path) ? "text-primary" : "")} />
                    {!sidebarCollapsed && <span className="ml-3">{item.name}</span>}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          
          <div className="p-4 border-t border-sidebar-border">
            <ul className="space-y-1">
              <li>
                <Link
                  to="/dashboard/settings"
                  className={cn(
                    "flex items-center py-2 px-3 rounded-md transition-colors",
                    sidebarCollapsed ? "justify-center" : "justify-start",
                    isActive('/dashboard/settings') 
                      ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground"
                  )}
                >
                  <Settings className="h-5 w-5" />
                  {!sidebarCollapsed && <span className="ml-3">Settings</span>}
                </Link>
              </li>
              <li>
                <button
                  onClick={handleLogout}
                  className={cn(
                    "flex items-center py-2 px-3 rounded-md transition-colors text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground w-full",
                    sidebarCollapsed ? "justify-center" : "justify-start"
                  )}
                >
                  <LogOut className="h-5 w-5" />
                  {!sidebarCollapsed && <span className="ml-3">Logout</span>}
                </button>
              </li>
            </ul>
            
            {sidebarCollapsed && (
              <button 
                onClick={toggleSidebar}
                className="mt-4 p-2 w-full flex justify-center rounded-md hover:bg-sidebar-accent"
                aria-label="Expand sidebar"
              >
                <ChevronRight size={16} className="rotate-180" />
              </button>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

export default DashboardSidebar;
