
import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { Menu, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { user } = useAuth();

  const isActive = (path: string) => location.pathname === path;

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Close mobile menu when changing routes
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <header
      className={cn(
        'fixed top-0 left-0 w-full z-50 transition-all duration-300 ease-in-out',
        isScrolled
          ? 'bg-white/80 dark:bg-gray-900/80 backdrop-blur-md shadow-sm py-3'
          : 'bg-transparent py-5'
      )}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <span className="text-2xl font-display font-bold text-foreground">Plate</span>
          <span className="text-primary font-display font-bold text-2xl">Sync</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link
            to="/"
            className={cn(
              'text-sm font-medium transition-colors hover:text-primary',
              isActive('/') ? 'text-primary' : 'text-foreground/80'
            )}
          >
            Home
          </Link>
          <Link
            to="/pricing"
            className={cn(
              'text-sm font-medium transition-colors hover:text-primary',
              isActive('/pricing') ? 'text-primary' : 'text-foreground/80'
            )}
          >
            Pricing
          </Link>
          <Link
            to="/terms"
            className={cn(
              'text-sm font-medium transition-colors hover:text-primary',
              isActive('/terms') ? 'text-primary' : 'text-foreground/80'
            )}
          >
            Terms
          </Link>
          <Link
            to="/privacy"
            className={cn(
              'text-sm font-medium transition-colors hover:text-primary',
              isActive('/privacy') ? 'text-primary' : 'text-foreground/80'
            )}
          >
            Privacy
          </Link>
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          {user ? (
            <Link to="/dashboard">
              <AnimatedButton variant="default" size="sm" glint>
                Dashboard
              </AnimatedButton>
            </Link>
          ) : (
            <>
              <Link to="/login">
                <AnimatedButton variant="outline" size="sm" glint>
                  Log in
                </AnimatedButton>
              </Link>
              <Link to="/login">
                <AnimatedButton variant="default" size="sm" glint>
                  Get Started
                </AnimatedButton>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Navigation Button */}
        <button
          onClick={toggleMobileMenu}
          className="md:hidden flex items-center justify-center p-2 rounded-md text-foreground hover:text-primary"
          aria-expanded={isMobileMenuOpen}
        >
          {isMobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div
        className={cn(
          'md:hidden fixed inset-0 top-[60px] bg-background/95 backdrop-blur-sm z-40 transition-all duration-300 ease-in-out',
          isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
      >
        <div className="container mx-auto px-4 py-8 flex flex-col space-y-8">
          <nav className="flex flex-col space-y-6">
            <Link
              to="/"
              className={cn(
                'text-lg font-medium transition-colors hover:text-primary',
                isActive('/') ? 'text-primary' : 'text-foreground'
              )}
            >
              Home
            </Link>
            <Link
              to="/pricing"
              className={cn(
                'text-lg font-medium transition-colors hover:text-primary',
                isActive('/pricing') ? 'text-primary' : 'text-foreground'
              )}
            >
              Pricing
            </Link>
            <Link
              to="/terms"
              className={cn(
                'text-lg font-medium transition-colors hover:text-primary',
                isActive('/terms') ? 'text-primary' : 'text-foreground'
              )}
            >
              Terms
            </Link>
            <Link
              to="/privacy"
              className={cn(
                'text-lg font-medium transition-colors hover:text-primary',
                isActive('/privacy') ? 'text-primary' : 'text-foreground'
              )}
            >
              Privacy
            </Link>
          </nav>

          <div className="flex flex-col space-y-4">
            {user ? (
              <Link to="/dashboard">
                <AnimatedButton variant="default" className="w-full">
                  Dashboard
                </AnimatedButton>
              </Link>
            ) : (
              <>
                <Link to="/login">
                  <AnimatedButton variant="outline" className="w-full">
                    Log in
                  </AnimatedButton>
                </Link>
                <Link to="/login">
                  <AnimatedButton variant="default" className="w-full">
                    Get Started
                  </AnimatedButton>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
