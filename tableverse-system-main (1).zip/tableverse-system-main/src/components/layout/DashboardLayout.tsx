
import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import DashboardSidebar from './DashboardSidebar';
import { useAuth } from '@/contexts/AuthContext';
import { useSidebarState } from '@/hooks/useSidebarState';

interface DashboardLayoutProps {
  children?: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  // This pre-fetches the auth context to ensure it's available before rendering the sidebar
  const auth = useAuth();
  const location = useLocation();
  const { sidebarCollapsed } = useSidebarState();
  
  // Get restaurant name directly from profile data
  const restaurantName = auth.profile?.restaurant_name || "Restaurant";
  const userName = auth.profile?.first_name || "";
  
  // Log the profile data to debug
  console.log("Auth profile in DashboardLayout:", auth.profile);
  
  return (
    <div className="min-h-screen bg-background">
      <DashboardSidebar />
      
      <main className={`transition-all duration-300 min-h-screen bg-subtle-gradient bg-fixed ${sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <div className="p-4 md:p-6 lg:p-8">
          {/* Tenant context banner for multi-tenant awareness - only shown when no children are passed */}
          {auth.profile?.restaurant_id && !children && (
            <div className="mb-4 p-3 bg-primary/10 backdrop-blur-sm rounded-lg text-sm border border-primary/20 text-primary flex justify-between items-center shadow-sm">
              <span className="flex items-center gap-2">
                <strong>{restaurantName}{userName && `, ${userName}`}</strong> 
                {auth.profile.is_owner && (
                  <span className="ml-2 text-xs bg-primary/20 px-2 py-0.5 rounded">Owner</span>
                )}
              </span>
              {auth.profile.subscription_status === 'trial' && (
                <span className="text-amber-600 font-medium">
                  Trial ends in {auth.profile.trial_days_left || 14} days
                </span>
              )}
            </div>
          )}
          {children || <Outlet />}
        </div>
      </main>
    </div>
  );
};

export default DashboardLayout;
