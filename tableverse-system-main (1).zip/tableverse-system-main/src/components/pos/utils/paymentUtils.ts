
import { OrderItem } from '../types/paymentTypes';
import { toast } from '@/hooks/use-toast';

export const calculateChange = (tenderAmount: string, totalAmount: number): number => {
  const numericTender = parseFloat(tenderAmount) || 0;
  const change = numericTender - totalAmount;
  return change > 0 ? change : 0;
};

export const printReceipt = (
  selectedOrders: string[], 
  orderDetails: { [orderId: string]: OrderItem[] },
  combinedTotal: number,
  tableNumber?: string,
  paymentMethod?: 'cash' | 'card' | 'mobile',
  tenderAmount?: string,
  changeAmount?: number,
  currency: string = '$',
  taxPercentage: number = 8,
  serviceChargePercentage: number = 0,
  applyServiceCharge: boolean = false
) => {
  try {
    // Get items from all selected orders
    const receiptItems: OrderItem[] = [];
    let totalItems = 0;
    
    selectedOrders.forEach(orderId => {
      const items = orderDetails[orderId] || [];
      receiptItems.push(...items);
      totalItems += items.length;
    });
    
    if (receiptItems.length === 0) {
      console.log("No items found for receipt");
      return;
    }
    
    // Create receipt content
    const date = new Date().toLocaleString();
    const orderNumbers = selectedOrders.map(id => `#${id.slice(-4)}`).join(", ");
    
    // Calculate all prices correctly
    const itemsSubtotal = receiptItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = itemsSubtotal * (taxPercentage / 100);
    const serviceCharge = applyServiceCharge ? itemsSubtotal * (serviceChargePercentage / 100) : 0;
    const total = itemsSubtotal + tax + serviceCharge;
    
    let receiptContent = `
      <style>
        @media print {
          body { font-family: 'Courier New', monospace; font-size: 12px; }
          .receipt { width: 300px; padding: 10px; }
          .header { text-align: center; margin-bottom: 10px; }
          .divider { border-top: 1px dashed #000; margin: 10px 0; }
          .item { display: flex; justify-content: space-between; margin: 5px 0; }
          .totals { margin-top: 10px; }
          .footer { text-align: center; margin-top: 20px; font-size: 10px; }
        }
      </style>
      <div class="receipt">
        <div class="header">
          <h2>RECEIPT</h2>
          <p>Date: ${date}</p>
          <p>Table: ${tableNumber}</p>
          <p>Order(s): ${orderNumbers}</p>
        </div>
        <div class="divider"></div>
        <div class="items">
          <div class="item" style="font-weight: bold;">
            <span>Item</span>
            <span>Qty</span>
            <span>Price</span>
          </div>
    `;
    
    // Add items to receipt
    receiptItems.forEach(item => {
      receiptContent += `
        <div class="item">
          <span>${item.name}</span>
          <span>${item.quantity}x</span>
          <span>${currency}${(item.price * item.quantity).toFixed(2)}</span>
        </div>
      `;
    });
    
    // Add totals with correct calculations
    receiptContent += `
        <div class="divider"></div>
        <div class="totals">
          <div class="item">
            <span>Subtotal:</span>
            <span>${currency}${itemsSubtotal.toFixed(2)}</span>
          </div>
          <div class="item">
            <span>Tax (${taxPercentage}%):</span>
            <span>${currency}${tax.toFixed(2)}</span>
          </div>
    `;
    
    // Only add service charge if applied
    if (applyServiceCharge && serviceCharge > 0) {
      receiptContent += `
          <div class="item">
            <span>Service Charge (${serviceChargePercentage}%):</span>
            <span>${currency}${serviceCharge.toFixed(2)}</span>
          </div>
      `;
    }
    
    receiptContent += `
          <div class="item" style="font-weight: bold;">
            <span>Total:</span>
            <span>${currency}${total.toFixed(2)}</span>
          </div>
          ${paymentMethod === 'cash' && tenderAmount ? `
          <div class="item">
            <span>Cash tendered:</span>
            <span>${currency}${parseFloat(tenderAmount).toFixed(2)}</span>
          </div>
          <div class="item">
            <span>Change:</span>
            <span>${currency}${changeAmount?.toFixed(2) || '0.00'}</span>
          </div>
          ` : `
          <div class="item">
            <span>Payment method:</span>
            <span>${paymentMethod === 'card' ? 'Credit/Debit Card' : paymentMethod === 'mobile' ? 'Mobile Payment' : ''}</span>
          </div>
          `}
        </div>
        <div class="divider"></div>
        <div class="footer">
          <p>Thank you for your business!</p>
        </div>
      </div>
    `;
    
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        title: "Print Error",
        description: "Could not open print window. Please check your popup settings.",
        variant: "destructive"
      });
      return;
    }
    
    printWindow.document.write(receiptContent);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = function() {
      printWindow.print();
      printWindow.onafterprint = function() {
        printWindow.close();
      };
    };
    
    toast({
      title: "Receipt printed",
      description: "Payment receipt has been sent to printer."
    });
    
  } catch (error) {
    console.error('Error printing receipt:', error);
    toast({
      title: "Print Error",
      description: "Failed to print receipt. Please try again.",
      variant: "destructive"
    });
  }
};
