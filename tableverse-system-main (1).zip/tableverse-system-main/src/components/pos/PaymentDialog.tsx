import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { Printer } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

import PaymentMethodSelector from './PaymentMethodSelector';
import CashTenderInput from './CashTenderInput';

import { OrderDetails, OrderSummary, PaymentDialogProps } from './types/paymentTypes';

import { fetchTableOrders, fetchOrderDetails, updateOrdersPaymentStatus } from './services/paymentService';
import { calculateChange, printReceipt } from './utils/paymentUtils';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

const PaymentDialog: React.FC<PaymentDialogProps> = ({
  open,
  onOpenChange,
  onPayment,
  orderTotal,
  tableNumber,
  orderId,
  isLoading
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'mobile'>('cash');
  const [showCashTender, setShowCashTender] = useState(false);
  const [tenderAmount, setTenderAmount] = useState<string>('');
  const [changeAmount, setChangeAmount] = useState<number>(0);
  const [tableOrders, setTableOrders] = useState<OrderSummary[]>([]);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [combinedTotal, setCombinedTotal] = useState<number>(orderTotal);
  const [orderDetails, setOrderDetails] = useState<OrderDetails>({});
  const [processingPayment, setProcessingPayment] = useState(false);
  const { currency, applyServiceCharge, serviceChargePercentage } = useCurrency();

  useEffect(() => {
    if (open) {
      setPaymentMethod('cash');
      setShowCashTender(false);
      setTenderAmount('');
      setChangeAmount(0);
      setSelectedOrders(orderId ? [orderId] : []);
      setCombinedTotal(orderTotal);
      setOrderDetails({});
      setProcessingPayment(false);
      
      if (tableNumber) {
        console.log('Loading orders for table:', tableNumber);
        loadTableOrders();
      }
    }
  }, [open, orderId, orderTotal, tableNumber]);

  const loadTableOrders = async () => {
    console.log('Fetching table orders for:', tableNumber, orderId);
    const orders = await fetchTableOrders(orderId, tableNumber);
    console.log('Fetched orders:', orders);
    
    if (orders && orders.length > 0) {
      setTableOrders(orders);
      
      if (orders.length === 1) {
        setSelectedOrders([orders[0].order_id]);
      } else if (orderId) {
        setSelectedOrders([orderId]);
      }
      
      const orderIds = orders.map(order => order.order_id);
      const details = await fetchOrderDetails(orderIds);
      setOrderDetails(details);
    } else {
      console.log('No orders found for', tableNumber);
      // If it's a walk-in order but no orders were found, try again with a direct query
      if (tableNumber === 'Walk-in Customer' && !orders.length) {
        console.log('Attempting direct query for walk-in orders');
        const { data, error } = await supabase
          .from('orders')
          .select('order_id, total, items_count, status')
          .is('table_id', null)
          .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
          .neq('payment_status', 'Paid')
          .neq('payment_status', 'Prepaid');
          
        if (data && data.length > 0) {
          console.log('Direct query found walk-in orders:', data);
          setTableOrders(data);
          if (data.length === 1) {
            setSelectedOrders([data[0].order_id]);
          }
          
          const orderIds = data.map(order => order.order_id);
          const details = await fetchOrderDetails(orderIds);
          setOrderDetails(details);
        }
      }
    }
  };

  useEffect(() => {
    setChangeAmount(calculateChange(tenderAmount, combinedTotal));
  }, [tenderAmount, combinedTotal]);

  useEffect(() => {
    if (selectedOrders.length === 0) {
      setCombinedTotal(0);
      return;
    }
    
    const total = tableOrders
      .filter(order => selectedOrders.includes(order.order_id))
      .reduce((sum, order) => sum + order.total, 0);
    
    setCombinedTotal(total || orderTotal);
  }, [selectedOrders, tableOrders, orderTotal]);

  const handlePaymentMethodChange = (value: string) => {
    setPaymentMethod(value as 'cash' | 'card' | 'mobile');
    setShowCashTender(value === 'cash');
    setTenderAmount('');
    setChangeAmount(0);
  };

  const handleTenderInput = (value: string) => {
    if (/^\d*\.?\d{0,2}$/.test(value) || value === '') {
      setTenderAmount(value);
    }
  };

  const handleNumpadClick = (value: string) => {
    if (value === 'backspace') {
      setTenderAmount(prev => prev.slice(0, -1));
    } else if (value === 'clear') {
      setTenderAmount('');
    } else if (value === 'exact') {
      setTenderAmount(combinedTotal.toFixed(2));
    } else {
      const newValue = tenderAmount + value;
      handleTenderInput(newValue);
    }
  };

  const toggleOrderSelection = (orderId: string) => {
    setSelectedOrders(prev => {
      if (prev.includes(orderId)) {
        return prev.filter(id => id !== orderId);
      } else {
        return [...prev, orderId];
      }
    });
  };

  const handleCompletePayment = async () => {
    if (paymentMethod === 'cash' && parseFloat(tenderAmount) < combinedTotal) {
      toast({
        title: "Insufficient amount",
        description: "Cash tender amount must be equal to or greater than the total",
        variant: "destructive"
      });
      return;
    }
    
    if (selectedOrders.length === 0) {
      toast({
        title: "No orders selected",
        description: "Please select at least one order to process payment",
        variant: "destructive"
      });
      return;
    }
    
    setProcessingPayment(true);
    
    try {
      const ordersToUpdate = tableOrders.filter(order => selectedOrders.includes(order.order_id));
      const shouldReleaseTable = ordersToUpdate.every(order => order.status === 'Completed');
      const paymentStatus = ordersToUpdate.every(order => order.status === 'Completed') ? 'Paid' : 'Prepaid';
      
      const success = await updateOrdersPaymentStatus(
        selectedOrders, 
        paymentStatus, 
        shouldReleaseTable
      );
      
      if (success) {
        onPayment(paymentMethod);
        
        toast({
          title: "Payment successful",
          description: `Payment processed via ${paymentMethod}`,
        });

        onOpenChange(false);
      } else {
        throw new Error("Failed to update payment status");
      }
    } catch (error) {
      console.error('Payment processing error:', error);
      toast({
        title: "Payment failed",
        description: "There was an error processing the payment",
        variant: "destructive"
      });
    } finally {
      setProcessingPayment(false);
    }
  };

  const handlePrintReceipt = () => {
    if (selectedOrders.length === 0) {
      toast({
        title: "No orders selected",
        description: "Please select at least one order to print receipt",
        variant: "destructive"
      });
      return;
    }
    
    printReceipt(
      selectedOrders, 
      orderDetails, 
      combinedTotal, 
      tableNumber, 
      paymentMethod,
      tenderAmount,
      changeAmount,
      currency,
      8,
      serviceChargePercentage,
      applyServiceCharge
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Process Payment</DialogTitle>
          <DialogDescription>
            {tableNumber && <div className="text-base font-medium mt-1">Table: {tableNumber}</div>}
            {orderId && !tableOrders.length && 
              <div className="text-sm text-muted-foreground">
                Order ID: #{orderId.slice(-4)}
              </div>
            }
            {tableOrders.length <= 1 && (
              <div className="font-medium text-lg mt-3 border-t pt-2">
                Total: {formatCurrency(combinedTotal, currency)}
              </div>
            )}
          </DialogDescription>
        </DialogHeader>

        {showCashTender ? (
          <CashTenderInput
            combinedTotal={combinedTotal}
            tenderAmount={tenderAmount}
            onTenderInput={handleTenderInput}
            onNumpadClick={handleNumpadClick}
            changeAmount={changeAmount}
          />
        ) : (
          <PaymentMethodSelector
            tableOrders={tableOrders}
            paymentMethod={paymentMethod}
            onPaymentMethodChange={handlePaymentMethodChange}
            selectedOrders={selectedOrders}
            onOrderSelectionToggle={toggleOrderSelection}
            combinedTotal={combinedTotal}
            onPrintReceipt={handlePrintReceipt}
            tableNumber={tableNumber}
          />
        )}
        
        <DialogFooter>
          {showCashTender ? (
            <>
              <Button 
                variant="outline" 
                onClick={() => setShowCashTender(false)}
                disabled={isLoading || processingPayment}
              >
                Back
              </Button>
              <Button 
                onClick={handleCompletePayment}
                disabled={isLoading || processingPayment || parseFloat(tenderAmount) < combinedTotal || selectedOrders.length === 0}
              >
                {isLoading || processingPayment ? 'Processing...' : 'Complete Payment'}
              </Button>
              <Button 
                variant="outline" 
                onClick={handlePrintReceipt}
                disabled={isLoading || processingPayment || selectedOrders.length === 0}
              >
                <Printer className="h-4 w-4 mr-2" />
                Print Receipt
              </Button>
            </>
          ) : (
            <>
              <Button 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                disabled={isLoading || processingPayment}
              >
                Cancel
              </Button>
              {paymentMethod === 'cash' ? (
                <Button 
                  onClick={() => setShowCashTender(true)}
                  disabled={isLoading || processingPayment || selectedOrders.length === 0}
                >
                  Continue
                </Button>
              ) : (
                <>
                  <Button 
                    onClick={handleCompletePayment}
                    disabled={isLoading || processingPayment || selectedOrders.length === 0}
                  >
                    {isLoading || processingPayment ? 'Processing...' : 'Complete Payment'}
                  </Button>
                </>
              )}
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentDialog;
