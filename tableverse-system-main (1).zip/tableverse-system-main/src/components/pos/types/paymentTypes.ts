
export interface OrderSummary {
  order_id: string;
  total: number;
  items_count: number;
  status: string;
  payment_status?: string;
  created_at?: string;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

export interface OrderDetails {
  [orderId: string]: OrderItem[];
}

export interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPayment: (method: 'cash' | 'card' | 'mobile') => void;
  orderTotal: number;
  tableNumber?: string;
  orderId?: string;
  isLoading: boolean;
}
