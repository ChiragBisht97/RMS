
import React from 'react';
import { CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, DollarSign, Minus, Plus, Trash2, Receipt, Ban, X } from 'lucide-react';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import BlurCard from '@/components/ui/BlurCard';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface CartSectionProps {
  cart: { id: string; name: string; price: number; quantity: number; }[];
  updateQuantity: (id: string, change: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  subtotal: number;
  tax: number;
  total: number;
  taxPercentage: number;
  setIsCreateOrderOpen: (open: boolean) => void;
  setIsPaymentModalOpen: (open: boolean) => void;
  selectedTable: string | null;
  orderType: 'table' | 'walkin';
  renderSelectedOrderType: () => React.ReactNode;
  currentOrder: any;
  voidLineItem?: (itemId: string) => void;
  voidOrder?: () => void;
  applyServiceCharge?: boolean;
  serviceChargePercentage?: number;
  serviceCharge?: number;
}

const CartSection: React.FC<CartSectionProps> = ({
  cart,
  updateQuantity,
  removeFromCart,
  clearCart,
  subtotal,
  tax,
  total,
  taxPercentage,
  setIsCreateOrderOpen,
  setIsPaymentModalOpen,
  selectedTable,
  orderType,
  renderSelectedOrderType,
  currentOrder,
  voidLineItem,
  voidOrder,
  applyServiceCharge = false,
  serviceChargePercentage = 0,
  serviceCharge = 0
}) => {
  const { currency } = useCurrency();
  
  return (
    <BlurCard className="sticky top-4">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            {currentOrder ? 'Existing Order' : 'Current Order'}
          </CardTitle>
          {currentOrder && (
            <Badge variant="outline" className="ml-2">
              Order #{currentOrder.order_id.slice(-4)}
            </Badge>
          )}
        </div>
        {(selectedTable || orderType === 'walkin') && (
          <CardDescription>
            {renderSelectedOrderType()}
          </CardDescription>
        )}
        {currentOrder && (
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant={
              currentOrder.status === 'Pending' ? 'secondary' : 
              currentOrder.status === 'In Progress' ? 'secondary' : 
              currentOrder.status === 'Ready' ? 'default' : 'outline'
            }>
              {currentOrder.status}
            </Badge>
            
            {currentOrder.payment_status && (
              <Badge 
                variant={
                  currentOrder.payment_status === 'Unpaid' ? 'outline' : 
                  currentOrder.payment_status === 'Prepaid' ? 'secondary' : 'default'
                }
                className={currentOrder.payment_status === 'Paid' ? 'bg-green-500 hover:bg-green-600' : ''}
              >
                {currentOrder.payment_status}
              </Badge>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent className="pb-0">
        {cart.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">
            <ShoppingCart className="mx-auto h-8 w-8 mb-2 opacity-50" />
            <p>Your cart is empty</p>
            <p className="text-sm">Add items from the menu</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[calc(100vh-24rem)] overflow-y-auto">
            {cart.map(item => (
              <div key={item.id} className="flex justify-between items-center py-2 border-b border-border/50">
                <div className="flex-1">
                  <p className="font-medium text-sm">{item.name}</p>
                  <p className="text-sm text-muted-foreground">{formatCurrency(item.price, currency)} each</p>
                </div>
                <div className="flex items-center gap-2">
                  {!currentOrder ? (
                    <>
                      <button 
                        className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center"
                        onClick={() => updateQuantity(item.id, -1)}
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button 
                        className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center"
                        onClick={() => updateQuantity(item.id, 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                      <button 
                        className="h-7 w-7 rounded-full hover:bg-muted flex items-center justify-center ml-1"
                        onClick={() => removeFromCart(item.id)}
                      >
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </button>
                    </>
                  ) : (
                    <>
                      <span className="w-8 text-center">{item.quantity}</span>
                      {voidLineItem && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button 
                              className="h-7 w-7 rounded-full hover:bg-destructive/10 flex items-center justify-center ml-1"
                              title="Void item"
                            >
                              <X className="h-4 w-4 text-destructive" />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Void Item</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to void "{item.name}"? 
                                This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => voidLineItem(item.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Void Item
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col pt-0">
        <div className="w-full pt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>{formatCurrency(subtotal, currency)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Tax ({taxPercentage}%)</span>
            <span>{formatCurrency(tax, currency)}</span>
          </div>
          {applyServiceCharge && (
            <div className="flex justify-between text-sm">
              <span>Service Charge ({serviceChargePercentage}%)</span>
              <span>{formatCurrency(serviceCharge, currency)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold pt-2 border-t">
            <span>Total</span>
            <span>{formatCurrency(total, currency)}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-2 mt-6 w-full">
          {currentOrder ? (
            <AnimatedButton 
              onClick={() => setIsPaymentModalOpen(true)}
              glint
              variant="default"
            >
              <Receipt className="mr-2 h-4 w-4" />
              Collect Payment
            </AnimatedButton>
          ) : (
            <AnimatedButton 
              disabled={cart.length === 0 || (!selectedTable && orderType !== 'walkin')} 
              glint
              onClick={() => setIsCreateOrderOpen(true)}
            >
              <DollarSign className="mr-2 h-4 w-4" />
              Create Order
            </AnimatedButton>
          )}
        </div>
        
        <div className="grid grid-cols-3 gap-2 mt-4 w-full">
          {cart.length > 0 && !currentOrder && (
            <Button variant="outline" size="sm" onClick={clearCart} className="col-span-3 text-muted-foreground">
              Clear Cart
            </Button>
          )}
          
          {cart.length > 0 && currentOrder && voidOrder && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="col-span-3 text-destructive border-destructive/30 hover:bg-destructive/10"
                >
                  <Ban className="mr-2 h-4 w-4" />
                  Void Order
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Void Entire Order</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to void this entire order?
                    This will cancel the order and cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={voidOrder}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Void Order
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
        
        {!selectedTable && orderType !== 'walkin' && cart.length > 0 && !currentOrder && (
          <div className="w-full mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md text-amber-800 text-sm">
            Please select a table or walk-in customer before creating an order.
          </div>
        )}
      </CardFooter>
    </BlurCard>
  );
};

export default CartSection;
