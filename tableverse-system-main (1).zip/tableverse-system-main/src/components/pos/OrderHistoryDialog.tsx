
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';
import { OrderItem } from './types/paymentTypes';
import { printReceipt } from './utils/paymentUtils';
import { useCurrency } from '@/hooks/useCurrency';

interface OrderHistoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const OrderHistoryDialog: React.FC<OrderHistoryDialogProps> = ({ open, onOpenChange }) => {
  const [todayOrders, setTodayOrders] = useState<any[]>([]);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState('today');
  const [orderItems, setOrderItems] = useState<{[orderId: string]: OrderItem[]}>({});
  const { profile } = useAuth();
  const { currency, applyServiceCharge, serviceChargePercentage } = useCurrency();

  useEffect(() => {
    if (open) {
      fetchOrders();
    }
  }, [open]);

  const fetchOrders = async () => {
    if (!profile?.restaurant_id) return;
    
    setIsLoading(true);
    
    try {
      // Get today's date at midnight
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Fetch today's orders
      const { data: todayData, error: todayError } = await supabase
        .from('orders')
        .select(`
          order_id,
          created_at,
          total,
          status,
          payment_status,
          tables:table_id (tb_name)
        `)
        .eq('restaurant_id', profile.restaurant_id)
        .gte('created_at', today.toISOString())
        .order('created_at', { ascending: false });
      
      if (todayError) throw todayError;
      
      // Fetch recent orders (last 7 days excluding today)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      sevenDaysAgo.setHours(0, 0, 0, 0);
      
      const { data: recentData, error: recentError } = await supabase
        .from('orders')
        .select(`
          order_id,
          created_at,
          total,
          status,
          payment_status,
          tables:table_id (tb_name)
        `)
        .eq('restaurant_id', profile.restaurant_id)
        .gte('created_at', sevenDaysAgo.toISOString())
        .lt('created_at', today.toISOString())
        .order('created_at', { ascending: false });
      
      if (recentError) throw recentError;
      
      setTodayOrders(todayData || []);
      setRecentOrders(recentData || []);
      
      // Fetch order items for all orders
      const allOrderIds = [...(todayData || []), ...(recentData || [])].map(order => order.order_id);
      
      if (allOrderIds.length > 0) {
        const { data: itemsData, error: itemsError } = await supabase
          .from('order_items')
          .select(`
            item_id,
            order_id,
            menu_item_id,
            quantity,
            price,
            menu_items:menu_item_id (mi_name)
          `)
          .in('order_id', allOrderIds);
        
        if (itemsError) throw itemsError;
        
        // Organize items by order ID
        const itemsByOrder: {[orderId: string]: OrderItem[]} = {};
        
        (itemsData || []).forEach((item: any) => {
          if (!itemsByOrder[item.order_id]) {
            itemsByOrder[item.order_id] = [];
          }
          
          itemsByOrder[item.order_id].push({
            id: item.item_id,
            name: item.menu_items?.mi_name || 'Unknown Item',
            price: item.price,
            quantity: item.quantity
          });
        });
        
        setOrderItems(itemsByOrder);
      }
    } catch (error) {
      console.error('Error fetching order history:', error);
      toast({
        title: 'Error',
        description: 'Failed to load order history',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleTabChange = (value: string) => {
    setSelectedTab(value);
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'p');
    } catch (error) {
      return dateString;
    }
  };

  const printOrderReceipt = (order: any) => {
    const items = orderItems[order.order_id] || [];
    
    if (items.length === 0) {
      toast({
        title: 'No items',
        description: 'Cannot print receipt for an order with no items',
        variant: 'destructive',
      });
      return;
    }
    
    printReceipt(
      [order.order_id],
      orderItems,
      order.total,
      order.tables?.tb_name,
      undefined,
      undefined,
      undefined,
      currency,
      8, // tax percentage (hardcoded to 8%)
      serviceChargePercentage,
      applyServiceCharge
    );
  };

  const renderOrderList = (orders: any[]) => {
    if (orders.length === 0) {
      return (
        <div className="text-center py-10 text-muted-foreground">
          No orders found
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        {orders.map(order => (
          <div key={order.order_id} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <div className="font-medium">Order #{order.order_id.slice(-4)}</div>
                <div className="text-sm text-muted-foreground">{formatDate(order.created_at)}</div>
                <div className="flex gap-2 mt-1">
                  <div className={`px-2 py-0.5 text-xs rounded-full ${
                    order.status === 'Completed' ? 'bg-green-100 text-green-800' :
                    order.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {order.status}
                  </div>
                  <div className={`px-2 py-0.5 text-xs rounded-full ${
                    order.payment_status === 'Paid' ? 'bg-green-100 text-green-800' :
                    'bg-amber-100 text-amber-800'
                  }`}>
                    {order.payment_status}
                  </div>
                </div>
              </div>
              <div>
                <div className="text-right font-medium">{currency}{order.total.toFixed(2)}</div>
                <div className="text-sm text-muted-foreground">
                  {order.tables?.tb_name ? `Table ${order.tables.tb_name}` : 'Walk-in'}
                </div>
                {orderItems[order.order_id] && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                    onClick={() => printOrderReceipt(order)}
                  >
                    <Printer className="h-4 w-4 mr-1" />
                    Print Receipt
                  </Button>
                )}
              </div>
            </div>
            
            {orderItems[order.order_id] && (
              <div className="mt-3 border-t pt-3">
                <div className="text-sm font-medium mb-1">Items:</div>
                <div className="text-sm">
                  {orderItems[order.order_id].map((item, index) => (
                    <div key={index} className="flex justify-between">
                      <span>{item.name} × {item.quantity}</span>
                      <span>{currency}{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Order History</DialogTitle>
        </DialogHeader>
        
        <Tabs value={selectedTab} onValueChange={handleTabChange} className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="mb-4">
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="recent">Recent (7 days)</TabsTrigger>
          </TabsList>
          
          <div className="overflow-y-auto pr-2 flex-1">
            <TabsContent value="today" className="mt-0">
              {isLoading ? (
                <div className="text-center py-10">Loading...</div>
              ) : (
                renderOrderList(todayOrders)
              )}
            </TabsContent>
            
            <TabsContent value="recent" className="mt-0">
              {isLoading ? (
                <div className="text-center py-10">Loading...</div>
              ) : (
                renderOrderList(recentOrders)
              )}
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default OrderHistoryDialog;
