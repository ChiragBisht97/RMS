
import { supabase } from '@/integrations/supabase/client';

export const fetchTableOrders = async (orderId?: string, tableNumber?: string) => {
  try {
    // If we have a specific orderId, fetch just that order
    if (orderId) {
      const { data, error } = await supabase
        .from('orders')
        .select('order_id, total, items_count, status')
        .eq('order_id', orderId)
        .single();
      
      return error ? [] : [data];
    }
    
    // Get current user's restaurant_id
    const { data: userData } = await supabase.auth.getUser();
    const { data: profileData } = await supabase
      .from('profiles')
      .select('restaurant_id')
      .eq('pro_id', userData.user?.id)
      .single();
      
    const restaurantId = profileData?.restaurant_id;
    
    if (!restaurantId) {
      console.error('No restaurant ID found for current user');
      return [];
    }

    // For walk-in customers (no table)
    if (tableNumber === 'Walk-in Customer') {
      const { data, error } = await supabase
        .from('orders')
        .select('order_id, total, items_count, status')
        .is('table_id', null)
        .eq('restaurant_id', restaurantId) // Filter by restaurant_id
        .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
        .neq('payment_status', 'Paid')
        .neq('payment_status', 'Prepaid')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching walk-in orders:', error);
        return [];
      }
      
      return data || [];
    }
    
    // For regular tables
    if (tableNumber) {
      const { data: tableData, error: tableError } = await supabase
        .from('tables')
        .select('tb_id')
        .eq('tb_name', tableNumber)
        .eq('restaurant_id', restaurantId)
        .single();
      
      if (tableError || !tableData) {
        console.error('Error finding table:', tableError);
        return [];
      }
      
      const tableId = tableData.tb_id;
      
      const { data, error } = await supabase
        .from('orders')
        .select('order_id, total, items_count, status')
        .eq('table_id', tableId)
        .eq('restaurant_id', restaurantId) // Filter by restaurant_id
        .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
        .neq('payment_status', 'Paid')
        .neq('payment_status', 'Prepaid')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching table orders:', error);
        return [];
      }
      
      return data || [];
    }
    
    return [];
  } catch (error) {
    console.error('Error in fetchTableOrders:', error);
    return [];
  }
};

export const fetchOrderDetails = async (orderIds: string[]) => {
  try {
    const { data, error } = await supabase
      .from('order_items')
      .select(`
        order_id,
        quantity,
        price,
        notes,
        menu_items (
          mi_id,
          mi_name,
          mi_description,
          mi_image_url
        )
      `)
      .in('order_id', orderIds);
    
    if (error) {
      console.error('Error fetching order details:', error);
      return {};
    }
    
    const orderDetails: { [orderId: string]: any[] } = {};
    
    data.forEach(item => {
      const orderId = item.order_id;
      if (!orderDetails[orderId]) {
        orderDetails[orderId] = [];
      }
      
      // Check if notes contains variation information
      let variationInfo = '';
      if (item.notes && item.notes.startsWith('Size:')) {
        variationInfo = item.notes;
      }
      
      orderDetails[orderId].push({
        ...item,
        // Add variation info to the item if it exists
        variation: variationInfo
      });
    });
    
    return orderDetails;
  } catch (error) {
    console.error('Error in fetchOrderDetails:', error);
    return {};
  }
};

export const updateOrdersPaymentStatus = async (orderIds: string[], paymentStatus: string, shouldReleaseTable: boolean) => {
  try {
    // Update payment status for selected orders
    const { error: updateError } = await supabase
      .from('orders')
      .update({ payment_status: paymentStatus })
      .in('order_id', orderIds);
    
    if (updateError) {
      console.error('Error updating payment status:', updateError);
      throw updateError;
    }
    
    // If all orders are completed, release the table
    if (shouldReleaseTable) {
      // Get table ID from the first order
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select('table_id')
        .eq('order_id', orderIds[0])
        .single();
      
      if (orderError) {
        console.error('Error fetching order:', orderError);
        throw orderError;
      }
      
      const tableId = orderData?.table_id;
      
      if (tableId) {
        const { error: tableError } = await supabase
          .from('tables')
          .update({ tb_status: 'Available' })
          .eq('tb_id', tableId);
        
        if (tableError) {
          console.error('Error updating table status:', tableError);
          throw tableError;
        }
        
        console.log(`Table ${tableId} released successfully`);
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error in updateOrdersPaymentStatus:', error);
    return false;
  }
};
