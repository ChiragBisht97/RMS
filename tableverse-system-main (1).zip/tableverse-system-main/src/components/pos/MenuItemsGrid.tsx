
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Search, Grid, List } from 'lucide-react';
import { MenuItem } from '@/types/tables';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface MenuItemsGridProps {
  loading: boolean;
  filteredItems: MenuItem[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  categories: { id: string; name: string }[];
  addToCart: (item: MenuItem) => void;
}

const MenuItemsGrid: React.FC<MenuItemsGridProps> = ({
  loading,
  filteredItems,
  searchQuery,
  setSearchQuery,
  currentTab,
  setCurrentTab,
  categories,
  addToCart
}) => {
  const [viewMode, setViewMode] = React.useState<'grid' | 'list'>('grid');
  const { currency } = useCurrency();

  return (
    <div className="lg:col-span-2 space-y-6">
      <div className="flex justify-between items-center gap-4">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            type="search" 
            placeholder="Search menu items..." 
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex items-center gap-2">
          <ToggleGroup type="single" value={viewMode} onValueChange={(value) => value && setViewMode(value as 'grid' | 'list')}>
            <ToggleGroupItem value="grid" aria-label="Grid view">
              <Grid className="h-4 w-4" />
            </ToggleGroupItem>
            <ToggleGroupItem value="list" aria-label="List view">
              <List className="h-4 w-4" />
            </ToggleGroupItem>
          </ToggleGroup>
        </div>
      </div>
      
      <div className="category-selection">
        <ScrollArea className="w-full pb-4">
          <div className="flex flex-wrap gap-2 pb-2">
            <Button 
              variant={currentTab === 'all' ? 'default' : 'outline'} 
              size="sm"
              className="rounded-full"
              onClick={() => setCurrentTab('all')}
            >
              All Items
            </Button>
            {categories
              .filter(category => category.id !== 'all') // Exclude the 'all' category as it's already added above
              .map(category => (
                <Button 
                  key={category.id}
                  variant={currentTab === category.id ? 'default' : 'outline'} 
                  size="sm"
                  className="rounded-full"
                  onClick={() => setCurrentTab(category.id)}
                >
                  {category.name}
                </Button>
              ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="text-center py-12 border rounded-lg">
          <p className="text-muted-foreground">No menu items found.</p>
          <Button className="mt-4" variant="outline" onClick={() => window.location.href = '/dashboard/menus'}>
            Go to Menu Management
          </Button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4">
          {filteredItems.map(item => (
            <Card 
              key={item.id}
              className={`cursor-pointer hover:shadow-md transition-shadow ${!item.inStock ? 'opacity-50' : ''}`}
              onClick={() => item.inStock && addToCart(item)}
            >
              <div className="aspect-square bg-muted flex items-center justify-center overflow-hidden">
                <img 
                  src={item.imageUrl || `https://placehold.co/300x200/e4e9f6/404e8f?text=${encodeURIComponent(item.name)}`}
                  alt={item.name}
                  className="h-full w-full object-cover"
                />
              </div>
              <CardHeader className="p-3">
                <CardTitle className="text-sm">{item.name}</CardTitle>
                <CardDescription className="text-xs">
                  {item.variations && item.variations.length > 0 
                    ? `${formatCurrency(Number(item.variations[0].price), currency)} - ${formatCurrency(Number(item.variations[item.variations.length - 1].price), currency)}`
                    : formatCurrency(item.price, currency)}
                </CardDescription>
                {!item.inStock && (
                  <Badge variant="destructive" className="mt-1">Out of Stock</Badge>
                )}
                {item.variations && item.variations.length > 0 && (
                  <Badge variant="outline" className="mt-1">Multiple options</Badge>
                )}
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {filteredItems.map(item => (
            <Card 
              key={item.id}
              className={`overflow-hidden cursor-pointer hover:shadow-md transition-shadow ${!item.inStock ? 'opacity-50' : ''}`}
              onClick={() => item.inStock && addToCart(item)}
            >
              <div className="flex items-center p-3">
                <div className="w-12 h-12 bg-muted rounded overflow-hidden mr-3 flex-shrink-0">
                  <img 
                    src={item.imageUrl || `https://placehold.co/100x100/e4e9f6/404e8f?text=${encodeURIComponent(item.name)}`} 
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-sm">{item.name}</h3>
                  <p className="text-xs text-muted-foreground">
                    {item.variations && item.variations.length > 0 
                      ? `${formatCurrency(Number(item.variations[0].price), currency)} - ${formatCurrency(Number(item.variations[item.variations.length - 1].price), currency)}`
                      : formatCurrency(item.price, currency)}
                  </p>
                </div>
                {!item.inStock && (
                  <Badge variant="destructive" className="ml-2">Out of Stock</Badge>
                )}
                {item.variations && item.variations.length > 0 && (
                  <Badge variant="outline" className="ml-2">Multiple options</Badge>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default MenuItemsGrid;
