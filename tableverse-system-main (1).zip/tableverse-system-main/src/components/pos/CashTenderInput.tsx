
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DollarSign, X } from 'lucide-react';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface CashTenderInputProps {
  combinedTotal: number;
  tenderAmount: string;
  onTenderInput: (value: string) => void;
  onNumpadClick: (value: string) => void;
  changeAmount: number;
}

const CashTenderInput: React.FC<CashTenderInputProps> = ({
  combinedTotal,
  tenderAmount,
  onTenderInput,
  onNumpadClick,
  changeAmount
}) => {
  const { currency } = useCurrency();
  
  return (
    <div className="py-4 animate-fade-in">
      <div className="space-y-4">
        <div className="bg-muted p-4 rounded-md flex justify-between items-center">
          <span className="text-muted-foreground">Amount Due:</span>
          <span className="text-lg font-semibold">{formatCurrency(combinedTotal, currency)}</span>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="tender-amount">Cash Tendered:</Label>
          <div className="relative">
            <span className="absolute left-3 top-3 text-muted-foreground">{currency}</span>
            <Input
              id="tender-amount"
              value={tenderAmount}
              onChange={(e) => onTenderInput(e.target.value)}
              className="pl-9 text-right text-lg font-medium"
              autoFocus
            />
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 mt-4">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.'].map((num) => (
            <Button
              key={num}
              type="button"
              variant="outline"
              onClick={() => onNumpadClick(num)}
              className="h-12 text-lg font-medium"
            >
              {num}
            </Button>
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => onNumpadClick('backspace')}
            className="h-12"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => onNumpadClick('clear')}
            className="h-12"
          >
            Clear
          </Button>
          <Button
            type="button"
            variant="secondary"
            onClick={() => onNumpadClick('exact')}
            className="h-12"
          >
            Exact Amount
          </Button>
        </div>
        
        {parseFloat(tenderAmount) > 0 && (
          <div className={`bg-muted p-4 rounded-md flex justify-between items-center ${changeAmount > 0 ? 'bg-green-50' : ''}`}>
            <span className="text-muted-foreground">Change Due:</span>
            <span className={`text-lg font-semibold ${changeAmount > 0 ? 'text-green-600' : ''}`}>
              {formatCurrency(changeAmount, currency)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default CashTenderInput;
