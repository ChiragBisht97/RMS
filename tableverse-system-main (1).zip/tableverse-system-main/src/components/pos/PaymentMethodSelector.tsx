
import React from 'react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Banknote, CreditCard, Smartphone, Printer, ShoppingCart } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { OrderSummary } from './types/paymentTypes';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';

interface PaymentMethodSelectorProps {
  tableOrders: OrderSummary[];
  paymentMethod: 'cash' | 'card' | 'mobile';
  onPaymentMethodChange: (value: string) => void;
  selectedOrders: string[];
  onOrderSelectionToggle: (orderId: string) => void;
  combinedTotal: number;
  onPrintReceipt: () => void;
  tableNumber?: string;
}

const PaymentMethodSelector: React.FC<PaymentMethodSelectorProps> = ({
  tableOrders,
  paymentMethod,
  onPaymentMethodChange,
  selectedOrders,
  onOrderSelectionToggle,
  combinedTotal,
  onPrintReceipt,
  tableNumber
}) => {
  const { currency } = useCurrency();
  
  const renderOrderSelection = () => {
    if (tableOrders.length <= 1) return null;
    
    return (
      <div className="border rounded-md p-3 my-4 space-y-2">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-medium flex items-center">
            <ShoppingCart className="h-4 w-4 mr-2" />
            Available Orders for {tableNumber}
          </h3>
        </div>
        
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {tableOrders.map(order => (
            <div 
              key={order.order_id} 
              className="flex items-center justify-between border rounded-md p-2"
            >
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id={`order-${order.order_id}`}
                  checked={selectedOrders.includes(order.order_id)}
                  onCheckedChange={() => onOrderSelectionToggle(order.order_id)}
                />
                <Label htmlFor={`order-${order.order_id}`} className="cursor-pointer">
                  <div className="flex flex-col">
                    <span>Order #{order.order_id.slice(-4)}</span>
                    <span className="text-xs text-muted-foreground">
                      {order.items_count} item{order.items_count > 1 ? 's' : ''} - {order.status}
                    </span>
                  </div>
                </Label>
              </div>
              <span className="font-medium">{formatCurrency(order.total, currency)}</span>
            </div>
          ))}
        </div>
        
        <div className="pt-2 border-t mt-2 flex justify-between items-center font-medium">
          <span>Combined Total:</span>
          <span>{formatCurrency(combinedTotal, currency)}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="py-4">
      {renderOrderSelection()}
      
      <RadioGroup
        defaultValue="cash"
        value={paymentMethod}
        onValueChange={onPaymentMethodChange}
        className="grid grid-cols-1 gap-4"
      >
        <div className="flex items-center space-x-2 border p-4 rounded-md">
          <RadioGroupItem value="cash" id="cash" />
          <Label htmlFor="cash" className="flex items-center gap-2 cursor-pointer">
            <Banknote className="h-5 w-5 text-green-600" />
            Cash
          </Label>
        </div>
        
        <div className="flex items-center space-x-2 border p-4 rounded-md">
          <RadioGroupItem value="card" id="card" />
          <Label htmlFor="card" className="flex items-center gap-2 cursor-pointer">
            <CreditCard className="h-5 w-5 text-blue-600" />
            Credit/Debit Card
          </Label>
        </div>
        
        <div className="flex items-center space-x-2 border p-4 rounded-md">
          <RadioGroupItem value="mobile" id="mobile" />
          <Label htmlFor="mobile" className="flex items-center gap-2 cursor-pointer">
            <Smartphone className="h-5 w-5 text-purple-600" />
            Mobile Payment
          </Label>
        </div>
      </RadioGroup>
      
      <div className="text-center mt-4">
        <Button
          variant="ghost"
          size="sm"
          className="text-muted-foreground"
          onClick={onPrintReceipt}
          disabled={selectedOrders.length === 0}
        >
          <Printer className="h-4 w-4 mr-2" />
          Print Receipt
        </Button>
      </div>
    </div>
  );
};

export default PaymentMethodSelector;
