
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { TableIcon, Users, CheckCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';

interface TableSelectionSheetProps {
  tables: any[];
  handleTableSelect: (tableId: string) => void;
  setWalkInOrder: () => void;
  onClose: () => void;
  refreshTables: () => void;
}

const TableSelectionSheet: React.FC<TableSelectionSheetProps> = ({
  tables,
  handleTableSelect,
  setWalkInOrder,
  onClose,
  refreshTables
}) => {
  const [isReleasing, setIsReleasing] = useState<string | null>(null);
  const [hasActiveWalkInOrders, setHasActiveWalkInOrders] = useState(false);
  const { profile } = useAuth();
  
  // Check for active walk-in orders whenever the sheet is opened (tables array changes)
  useEffect(() => {
    checkForWalkInOrders();
  }, [tables]);
  
  // Check for active walk-in orders
  const checkForWalkInOrders = async () => {
    if (!profile?.restaurant_id) return;
    
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('order_id')
        .is('table_id', null)
        .eq('restaurant_id', profile.restaurant_id) // Filter by restaurant_id
        .in('status', ['Pending', 'In Progress', 'Ready', 'Completed'])
        .neq('payment_status', 'Paid')
        .neq('payment_status', 'Prepaid')
        .limit(1);
        
      if (error) throw error;
      setHasActiveWalkInOrders(data && data.length > 0);
      console.log('Active walk-in orders:', data?.length > 0);
    } catch (error) {
      console.error('Error checking for walk-in orders:', error);
    }
  };
  
  // Handle table selection and close the sheet
  const handleTableClick = (tableId: string) => {
    handleTableSelect(tableId);
    onClose();
  };
  
  // Handle walk-in selection and close the sheet
  const handleWalkInClick = () => {
    setWalkInOrder();
    onClose();
  };

  // Check if table has active orders and release it if not
  const handleReleaseTable = async (tableId: string) => {
    setIsReleasing(tableId);
    
    try {
      // Check for active orders on this table
      const { data: activeOrders, error: checkError } = await supabase
        .from('orders')
        .select('order_id')
        .eq('table_id', tableId)
        .in('status', ['Pending', 'In Progress', 'Ready'])
        .neq('payment_status', 'Paid')
        .neq('payment_status', 'Prepaid')
        .limit(1);
      
      if (checkError) throw checkError;
      
      if (activeOrders && activeOrders.length > 0) {
        toast({
          title: "Cannot Release Table",
          description: "This table has active orders that need to be completed first.",
          variant: "destructive",
        });
        return;
      }
      
      // If no active orders, release the table
      const { error: updateError } = await supabase
        .from('tables')
        .update({ tb_status: 'Available' })
        .eq('tb_id', tableId);
      
      if (updateError) throw updateError;
      
      toast({
        title: "Table Released",
        description: "The table is now available for new customers.",
      });
      
      // Refresh tables data to update UI
      refreshTables();
      
    } catch (error) {
      console.error('Error releasing table:', error);
      toast({
        title: "Error",
        description: "Failed to release the table. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsReleasing(null);
    }
  };
  
  // Check if there are currently any walk-in orders
  const hasWalkInOrders = tables.some(table => table.id === 'walkin' && table.status === 'Occupied') || hasActiveWalkInOrders;
  
  return (
    <SheetContent side="right">
      <SheetHeader>
        <SheetTitle>Select Table or Customer</SheetTitle>
        <SheetDescription>
          Choose a table for the order or select walk-in customer
        </SheetDescription>
      </SheetHeader>
      <div className="mt-6 space-y-6">
        {!hasWalkInOrders && (
          <Button 
            variant="outline" 
            className="w-full justify-start" 
            onClick={handleWalkInClick}
          >
            <Users className="h-4 w-4 mr-2" />
            <span>Walk-in Customer</span>
          </Button>
        )}
        
        <div>
          <h3 className="text-sm font-medium mb-2">Available Tables</h3>
          <ScrollArea className="h-[200px]">
            <div className="space-y-1">
              {tables
                .filter(table => table.status === 'Available' && table.id !== 'walkin')
                .map(table => (
                  <Button 
                    key={table.id} 
                    variant="ghost" 
                    className="w-full justify-start"
                    onClick={() => handleTableClick(table.id)}
                  >
                    <TableIcon className="h-4 w-4 mr-2 text-green-500" />
                    <span>{table.name}</span>
                    <Badge variant="outline" className="ml-auto">
                      {table.capacity} seats
                    </Badge>
                  </Button>
                ))}
            </div>
          </ScrollArea>
        </div>
        
        <Separator />
        
        <div>
          <h3 className="text-sm font-medium mb-2 flex items-center">
            <span>Occupied Tables</span>
            <Badge variant="secondary" className="ml-2">Cashier Mode</Badge>
          </h3>
          {tables.filter(table => table.status === 'Occupied').length === 0 && !hasActiveWalkInOrders && (
            <Alert className="my-3">
              <AlertDescription>
                No occupied tables at the moment.
              </AlertDescription>
            </Alert>
          )}
          <ScrollArea className="h-[200px]">
            <div className="space-y-1">
              {/* Show walk-in customer if there are active walk-in orders */}
              {hasActiveWalkInOrders && (
                <div className="flex flex-col gap-1 mb-2">
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start"
                    onClick={() => handleTableClick('walkin')}
                  >
                    <Users className="h-4 w-4 mr-2 text-blue-500" />
                    <span>Walk-in Customer</span>
                    <Badge variant="secondary" className="ml-auto">
                      Collect Payment
                    </Badge>
                  </Button>
                </div>
              )}
            
              {tables
                .filter(table => table.status === 'Occupied')
                .map(table => (
                  <div key={table.id} className="flex flex-col gap-1 mb-2">
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => handleTableClick(table.id)}
                    >
                      {table.id === 'walkin' ? (
                        <Users className="h-4 w-4 mr-2 text-blue-500" />
                      ) : (
                        <TableIcon className="h-4 w-4 mr-2 text-red-500" />
                      )}
                      <span>{table.name}</span>
                      <Badge variant="secondary" className="ml-auto">
                        Collect Payment
                      </Badge>
                    </Button>
                    {table.id !== 'walkin' && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="ml-6"
                        onClick={() => handleReleaseTable(table.id)}
                        disabled={isReleasing === table.id}
                      >
                        <CheckCircle className="h-3.5 w-3.5 mr-1" />
                        {isReleasing === table.id ? 'Checking...' : 'Release Table'}
                      </Button>
                    )}
                  </div>
                ))}
            </div>
          </ScrollArea>
        </div>
      </div>
    </SheetContent>
  );
};

export default TableSelectionSheet;
