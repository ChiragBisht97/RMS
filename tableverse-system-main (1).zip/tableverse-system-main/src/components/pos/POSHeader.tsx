
import React from 'react';
import { Button } from '@/components/ui/button';
import { SettingsIcon, TableIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';

interface POSHeaderProps {
  isTablesSheetOpen: boolean;
  setIsTablesSheetOpen: (open: boolean) => void;
  selectedTable: string | null;
  orderType: 'table' | 'walkin';
  tables: any[];
  taxPercentage: number;
  renderSelectedOrderType: () => React.ReactNode;
}

const POSHeader: React.FC<POSHeaderProps> = ({
  isTablesSheetOpen,
  setIsTablesSheetOpen,
  selectedTable,
  orderType,
  tables,
  taxPercentage,
  renderSelectedOrderType
}) => {
  const { profile } = useAuth();
  // Count occupied tables for cashier mode indicator
  const occupiedTablesCount = tables.filter(table => table.status === 'Occupied').length;
  
  // Get the first name for a more personalized UI
  const userName = profile?.first_name || '';

  return (
    <div className="flex justify-between items-center">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight">
          Point of Sale {userName && <span className="text-lg font-normal text-muted-foreground ml-2">({userName})</span>}
        </h1>
        <p className="text-muted-foreground">Process orders and payments.</p>
      </div>
      
      <div className="flex gap-3">
        <Sheet open={isTablesSheetOpen} onOpenChange={setIsTablesSheetOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" className="flex gap-2 relative">
              {selectedTable || orderType === 'walkin' ? (
                <>
                  {renderSelectedOrderType()}
                  {occupiedTablesCount > 0 && (
                    <Badge variant="secondary" className="absolute -top-2 -right-2">
                      {occupiedTablesCount}
                    </Badge>
                  )}
                </>
              ) : (
                <>
                  <TableIcon className="h-4 w-4" />
                  Select Table
                  {occupiedTablesCount > 0 && (
                    <Badge variant="secondary" className="absolute -top-2 -right-2">
                      {occupiedTablesCount}
                    </Badge>
                  )}
                </>
              )}
            </Button>
          </SheetTrigger>
        </Sheet>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon">
              <SettingsIcon className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => window.location.href = '/dashboard/settings'}>
              Tax Settings ({taxPercentage}%)
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default POSHeader;
