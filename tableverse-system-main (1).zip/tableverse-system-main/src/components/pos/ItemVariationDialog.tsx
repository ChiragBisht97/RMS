
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { MenuItem } from '@/types/tables';
import { useCurrency } from '@/hooks/useCurrency';
import { formatCurrency } from '@/utils/formatCurrency';
import { X } from 'lucide-react';

interface ItemVariationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: MenuItem | null;
  onSelectVariation: (item: MenuItem, variation: { size: string, price: string }) => void;
}

const ItemVariationDialog: React.FC<ItemVariationDialogProps> = ({ 
  open, 
  onOpenChange, 
  item, 
  onSelectVariation 
}) => {
  const { currency } = useCurrency();
  
  if (!item || !item.variations || item.variations.length === 0) {
    return null;
  }
  
  // Handle variation selection and immediately close the dialog
  const handleVariationSelect = (variation: { size: string, price: string }) => {
    if (item) {
      onSelectVariation(item, variation);
      onOpenChange(false); // Close dialog immediately after selection
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select size for {item.name}</DialogTitle>
        </DialogHeader>
        
        <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none">
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </DialogClose>
        
        <div className="space-y-2 my-4">
          {item.variations.map((variation, index) => (
            <Button
              key={index}
              variant="outline"
              className="w-full justify-between h-auto py-3 px-4"
              onClick={() => handleVariationSelect(variation)}
            >
              <span>{variation.size}</span>
              <span className="font-medium">{formatCurrency(Number(variation.price), currency)}</span>
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ItemVariationDialog;
