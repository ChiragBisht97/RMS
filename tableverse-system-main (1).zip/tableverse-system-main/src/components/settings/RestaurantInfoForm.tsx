
import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Building, Phone, MapPin } from 'lucide-react';

const formSchema = z.object({
  name: z.string().min(2, { message: 'Restaurant name must be at least 2 characters' }),
  address: z.string().min(5, { message: 'Please enter a valid address' }),
  phone: z.string().min(6, { message: 'Please enter a valid phone number' }),
});

type FormValues = z.infer<typeof formSchema>;

interface RestaurantInfoFormProps {
  initialData: {
    restaurant_id: string;
    name: string;
    address: string | null;
    phone: string | null;
    logo_url?: string | null;
    active?: boolean;
  };
  isOwner: boolean;
  onUpdate: () => void;
}

const RestaurantInfoForm: React.FC<RestaurantInfoFormProps> = ({ 
  initialData, 
  isOwner,
  onUpdate 
}) => {
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  // Ensure initialData exists and has the expected properties
  const safeInitialData = {
    name: initialData?.name || '',
    address: initialData?.address || '',
    phone: initialData?.phone || '',
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: safeInitialData,
  });

  const onSubmit = async (values: FormValues) => {
    if (!isOwner) {
      toast({
        title: "Permission Denied",
        description: "Only restaurant owners can update restaurant information",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      const { error } = await supabase
        .from('restaurants')
        .update({
          name: values.name,
          address: values.address,
          phone: values.phone,
          updated_at: new Date().toISOString()
        })
        .eq('restaurant_id', initialData.restaurant_id);
      
      if (error) throw error;
      
      toast({
        title: "Restaurant updated",
        description: "Restaurant information has been updated successfully",
      });
      
      onUpdate();
    } catch (error: any) {
      console.error('Error updating restaurant:', error);
      toast({
        title: "Update failed",
        description: error.message || "Failed to update restaurant information",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Restaurant Name</FormLabel>
              <FormControl>
                <div className="relative">
                  <Building className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="Enter restaurant name" 
                    {...field} 
                    disabled={!isOwner}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Address</FormLabel>
              <FormControl>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="Enter restaurant address" 
                    {...field} 
                    disabled={!isOwner}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Phone Number</FormLabel>
              <FormControl>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="Enter phone number" 
                    {...field} 
                    disabled={!isOwner}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {isOwner && (
          <div className="flex justify-end pt-4">
            <AnimatedButton 
              type="submit" 
              disabled={isSubmitting} 
              glint
            >
              {isSubmitting ? 'Updating...' : 'Update Restaurant'}
            </AnimatedButton>
          </div>
        )}
      </form>
    </Form>
  );
};

export default RestaurantInfoForm;
