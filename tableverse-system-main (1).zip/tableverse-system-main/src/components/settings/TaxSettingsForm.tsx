
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Percent } from 'lucide-react';

const formSchema = z.object({
  taxEnabled: z.boolean(),
  taxPercentage: z.string().refine(value => {
    const num = parseFloat(value);
    return !isNaN(num) && num >= 0 && num <= 100;
  }, {
    message: "Tax percentage must be a number between 0 and 100",
  }),
  inclusiveTax: z.boolean(),
});

type FormValues = z.infer<typeof formSchema>;

interface TaxSettingsFormProps {
  restaurantId: string;
  isOwner: boolean;
  onUpdate: () => void;
}

const TaxSettingsForm: React.FC<TaxSettingsFormProps> = ({ 
  restaurantId, 
  isOwner,
  onUpdate 
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      taxEnabled: false,
      taxPercentage: '0',
      inclusiveTax: false,
    },
  });

  // Load existing tax settings
  useEffect(() => {
    const loadTaxSettings = async () => {
      if (!restaurantId) return;
      
      try {
        // Fetch tax enabled setting
        const { data: taxEnabledData } = await supabase
          .from('settings')
          .select('setting_value')
          .eq('restaurant_id', restaurantId)
          .eq('setting_key', 'tax_enabled')
          .maybeSingle();
        
        // Fetch tax percentage setting
        const { data: taxPercentageData } = await supabase
          .from('settings')
          .select('setting_value')
          .eq('restaurant_id', restaurantId)
          .eq('setting_key', 'tax_percentage')
          .maybeSingle();
        
        // Fetch inclusive tax setting
        const { data: inclusiveTaxData } = await supabase
          .from('settings')
          .select('setting_value')
          .eq('restaurant_id', restaurantId)
          .eq('setting_key', 'inclusive_tax')
          .maybeSingle();
        
        // Set form values with defaults if not found
        form.setValue('taxEnabled', taxEnabledData?.setting_value === 'true');
        form.setValue('taxPercentage', taxPercentageData?.setting_value || '0');
        form.setValue('inclusiveTax', inclusiveTaxData?.setting_value === 'true');
        
      } catch (error) {
        console.error('Error loading tax settings:', error);
      }
    };
    
    loadTaxSettings();
  }, [restaurantId, form]);

  const onSubmit = async (values: FormValues) => {
    if (!isOwner) {
      toast({
        title: "Permission Denied",
        description: "Only restaurant owners can update tax settings",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      // Upsert settings
      const settings = [
        {
          restaurant_id: restaurantId,
          setting_key: 'tax_enabled',
          setting_value: values.taxEnabled.toString(),
        },
        {
          restaurant_id: restaurantId,
          setting_key: 'tax_percentage',
          setting_value: values.taxPercentage,
        },
        {
          restaurant_id: restaurantId,
          setting_key: 'inclusive_tax',
          setting_value: values.inclusiveTax.toString(),
        }
      ];
      
      for (const setting of settings) {
        await supabase
          .from('settings')
          .upsert(setting, { onConflict: 'restaurant_id,setting_key' });
      }
      
      toast({
        title: "Tax Settings Updated",
        description: "Tax settings have been updated successfully",
      });
      
      onUpdate();
    } catch (error: any) {
      console.error('Error updating tax settings:', error);
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update tax settings",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const watchTaxEnabled = form.watch('taxEnabled');

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Tax Enabled Toggle */}
        <FormField
          control={form.control}
          name="taxEnabled"
          render={({ field }) => (
            <FormItem className="border p-4 rounded-md">
              <div className="flex items-center justify-between">
                <div>
                  <FormLabel className="text-base">Enable Tax</FormLabel>
                  <FormDescription>
                    Apply tax to all orders
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    disabled={!isOwner}
                  />
                </FormControl>
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {watchTaxEnabled && (
          <>
            {/* Tax Percentage Field */}
            <FormField
              control={form.control}
              name="taxPercentage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tax Rate (%)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Percent className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                      <Input
                        className="pl-10" 
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        placeholder="0.00" 
                        {...field} 
                        disabled={!isOwner}
                      />
                    </div>
                  </FormControl>
                  <FormDescription>
                    Enter the tax percentage (e.g., 10 for 10% tax)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Inclusive Tax Toggle */}
            <FormField
              control={form.control}
              name="inclusiveTax"
              render={({ field }) => (
                <FormItem className="border p-4 rounded-md">
                  <div className="flex items-center justify-between">
                    <div>
                      <FormLabel className="text-base">Inclusive Tax</FormLabel>
                      <FormDescription>
                        When enabled, prices in the menu already include tax. When disabled, tax is added on top of the menu prices.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={!isOwner}
                      />
                    </FormControl>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}
        
        {isOwner && (
          <div className="flex justify-end pt-4">
            <AnimatedButton 
              type="submit" 
              disabled={isSubmitting} 
              glint
            >
              {isSubmitting ? 'Updating...' : 'Update Tax Settings'}
            </AnimatedButton>
          </div>
        )}
      </form>
    </Form>
  );
};

export default TaxSettingsForm;
