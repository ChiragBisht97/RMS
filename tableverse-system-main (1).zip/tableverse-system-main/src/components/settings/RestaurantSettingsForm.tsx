
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { AnimatedButton } from '@/components/ui/AnimatedButton';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { CurrencyIcon, Percent, Upload, Image } from 'lucide-react';

const formSchema = z.object({
  currency: z.string().min(1, { message: 'Currency symbol or code is required' }),
  serviceChargeEnabled: z.boolean(),
  serviceChargePercentage: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface RestaurantSettingsFormProps {
  restaurantId: string;
  isOwner: boolean;
  onUpdate: () => void;
}

const RestaurantSettingsForm: React.FC<RestaurantSettingsFormProps> = ({ 
  restaurantId, 
  isOwner,
  onUpdate 
}) => {
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [existingLogo, setExistingLogo] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      currency: '₹',
      serviceChargeEnabled: false,
      serviceChargePercentage: '5',
    },
  });

  // Load existing settings
  useEffect(() => {
    const loadSettings = async () => {
      if (!restaurantId) return;
      
      try {
        // Fetch currency setting
        const { data: currencyData } = await supabase
          .from('settings')
          .select('setting_value')
          .eq('restaurant_id', restaurantId)
          .eq('setting_key', 'currency')
          .maybeSingle();
        
        // Fetch service charge settings
        const { data: serviceChargeData } = await supabase
          .from('settings')
          .select('setting_value')
          .eq('restaurant_id', restaurantId)
          .eq('setting_key', 'service_charge_enabled')
          .maybeSingle();
        
        const { data: serviceChargePercentageData } = await supabase
          .from('settings')
          .select('setting_value')
          .eq('restaurant_id', restaurantId)
          .eq('setting_key', 'service_charge_percentage')
          .maybeSingle();
        
        // Fetch restaurant info for logo
        const { data: restaurantData } = await supabase
          .from('restaurants')
          .select('logo_url')
          .eq('restaurant_id', restaurantId)
          .maybeSingle();
        
        // Set form values
        form.setValue('currency', currencyData?.setting_value || '₹');
        form.setValue('serviceChargeEnabled', serviceChargeData?.setting_value === 'true');
        form.setValue('serviceChargePercentage', serviceChargePercentageData?.setting_value || '5');
        
        if (restaurantData?.logo_url) {
          setExistingLogo(restaurantData.logo_url);
        }
      } catch (error) {
        console.error('Error loading settings:', error);
      }
    };
    
    loadSettings();
  }, [restaurantId, form]);

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLogoFile(file);
      const fileReader = new FileReader();
      fileReader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      fileReader.readAsDataURL(file);
    }
  };

  const uploadLogo = async () => {
    if (!logoFile || !restaurantId) return null;

    const fileExt = logoFile.name.split('.').pop();
    const fileName = `${restaurantId}-logo.${fileExt}`;
    
    try {
      const { data, error } = await supabase.storage
        .from('logos')
        .upload(fileName, logoFile, { upsert: true });
      
      if (error) throw error;
      
      const { data: urlData } = supabase.storage
        .from('logos')
        .getPublicUrl(fileName);
      
      return urlData.publicUrl;
    } catch (error) {
      console.error('Error uploading logo:', error);
      return null;
    }
  };

  const onSubmit = async (values: FormValues) => {
    if (!isOwner) {
      toast({
        title: "Permission Denied",
        description: "Only restaurant owners can update settings",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      // Upload logo if provided
      let logoUrl = existingLogo;
      if (logoFile) {
        const uploadedUrl = await uploadLogo();
        if (uploadedUrl) {
          logoUrl = uploadedUrl;
          
          // Update restaurant with new logo URL
          await supabase
            .from('restaurants')
            .update({ logo_url: logoUrl })
            .eq('restaurant_id', restaurantId);
        }
      }
      
      // Upsert settings
      const settings = [
        {
          restaurant_id: restaurantId,
          setting_key: 'currency',
          setting_value: values.currency,
        },
        {
          restaurant_id: restaurantId,
          setting_key: 'service_charge_enabled',
          setting_value: values.serviceChargeEnabled.toString(),
        },
        {
          restaurant_id: restaurantId,
          setting_key: 'service_charge_percentage',
          setting_value: values.serviceChargePercentage || '5',
        }
      ];
      
      for (const setting of settings) {
        await supabase
          .from('settings')
          .upsert(setting, { onConflict: 'restaurant_id,setting_key' });
      }
      
      // Trigger a currency refresh event
      window.dispatchEvent(new CustomEvent('refresh-currency'));
      console.log('Triggered refresh-currency event after settings update');
      
      toast({
        title: "Settings updated",
        description: "Restaurant settings have been updated successfully",
      });
      
      onUpdate();
    } catch (error: any) {
      console.error('Error updating settings:', error);
      toast({
        title: "Update failed",
        description: error.message || "Failed to update restaurant settings",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const watchServiceChargeEnabled = form.watch('serviceChargeEnabled');

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Currency Setting */}
        <FormField
          control={form.control}
          name="currency"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Currency Symbol/Code</FormLabel>
              <FormControl>
                <div className="relative">
                  <CurrencyIcon className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="₹ or INR" 
                    {...field} 
                    disabled={!isOwner}
                  />
                </div>
              </FormControl>
              <FormDescription>
                Enter your currency symbol (₹) or code (INR). This will be displayed throughout the app.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {/* Service Charge Settings */}
        <FormField
          control={form.control}
          name="serviceChargeEnabled"
          render={({ field }) => (
            <FormItem className="border p-4 rounded-md">
              <div className="flex items-center justify-between">
                <div>
                  <FormLabel className="text-base">Service Charge</FormLabel>
                  <FormDescription>
                    Enable to add a service charge to all orders
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    disabled={!isOwner}
                  />
                </FormControl>
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {watchServiceChargeEnabled && (
          <FormField
            control={form.control}
            name="serviceChargePercentage"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Service Charge Percentage (%)</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Percent className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                    <Input
                      className="pl-10" 
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      placeholder="5" 
                      {...field} 
                      disabled={!isOwner}
                    />
                  </div>
                </FormControl>
                <FormDescription>
                  This percentage will be applied to the subtotal of all orders.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        {/* Logo Upload */}
        <div className="border p-4 rounded-md space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Restaurant Logo</Label>
              <p className="text-sm text-muted-foreground">
                Upload your restaurant logo (recommended size: 200x200px)
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="w-24 h-24 border rounded-md flex items-center justify-center overflow-hidden bg-muted">
              {(logoPreview || existingLogo) ? (
                <img 
                  src={logoPreview || existingLogo || ''} 
                  alt="Restaurant logo" 
                  className="w-full h-full object-contain"
                />
              ) : (
                <Image className="w-10 h-10 text-muted-foreground" />
              )}
            </div>
            
            <div className="flex-1">
              <Label htmlFor="logo-upload" className="cursor-pointer">
                <div className="flex items-center gap-2 border rounded-md p-2 hover:bg-accent">
                  <Upload className="h-4 w-4" />
                  <span>Choose file</span>
                </div>
              </Label>
              <input
                id="logo-upload"
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleLogoChange}
                disabled={!isOwner}
              />
              <p className="text-xs text-muted-foreground mt-1">
                PNG, JPG or SVG (max. 2MB)
              </p>
            </div>
          </div>
        </div>
        
        {isOwner && (
          <div className="flex justify-end pt-4">
            <AnimatedButton 
              type="submit" 
              disabled={isSubmitting} 
              glint
            >
              {isSubmitting ? 'Updating...' : 'Update Settings'}
            </AnimatedButton>
          </div>
        )}
      </form>
    </Form>
  );
};

export default RestaurantSettingsForm;
