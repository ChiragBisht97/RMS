
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";
import { Resend } from "https://esm.sh/resend@2.0.0";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";

interface PlateUser {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: string;
  restaurantId: string;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      SUPABASE_URL,
      SUPABASE_SERVICE_ROLE_KEY,
    );
    
    const resend = new Resend(RESEND_API_KEY);
    
    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not configured");
    }

    const requestData = await req.json();
    console.log("Request data:", JSON.stringify(requestData));

    // For password reset operations
    if (requestData.action === 'reset-password') {
      const { userId, email, newPassword } = requestData;
      
      if (!userId || !email || !newPassword) {
        throw new Error("Missing required fields for password reset");
      }

      console.log(`Attempting to update password for user ${email}`);

      // Update password in Supabase Auth
      const { data: updateData, error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
        userId,
        { password: newPassword }
      );

      if (updateError) {
        console.error("Password update error:", updateError);
        return new Response(
          JSON.stringify({ error: updateError.message }),
          { 
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }
          }
        );
      }

      // Send password reset notification email
      await resend.emails.send({
        from: "PlateSync <noreply@platesync.app>",
        to: [email],
        subject: "Your password has been reset",
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #4f46e5;">PlateSync</h1>
            <p>Your password has been reset by an administrator.</p>
            <p>You can now login with your new password.</p>
            <p>If you didn't request this change, please contact your restaurant administrator immediately.</p>
          </div>
        `,
      });

      return new Response(
        JSON.stringify({ message: "Password reset successful" }),
        { 
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }
    
    // For profile update operations
    if (requestData.action === 'update-profile') {
      const { userId, firstName, lastName } = requestData;
      
      if (!userId || !firstName || !lastName) {
        throw new Error("Missing required fields for profile update");
      }

      console.log(`Attempting to update profile for user ${userId}`);

      // Update profile in Supabase profiles table
      const { data: updateData, error: updateError } = await supabaseAdmin
        .from('profiles')
        .update({
          pro_first_name: firstName,
          pro_last_name: lastName,
          pro_updated_at: new Date().toISOString()
        })
        .eq('pro_id', userId);

      if (updateError) {
        console.error("Profile update error:", updateError);
        return new Response(
          JSON.stringify({ error: updateError.message }),
          { 
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }
          }
        );
      }

      return new Response(
        JSON.stringify({ message: "Profile updated successfully" }),
        { 
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }
    
    // For user creation operations (default case)
    const { email, role, firstName, lastName, restaurantId } = requestData;
    
    if (!email || !role || !restaurantId || !firstName || !lastName) {
      throw new Error("Missing required fields");
    }
    
    console.log(`Creating new user with email ${email} for restaurant ${restaurantId}`);

    // Generate a secure random password
    const tempPassword = generateTemporaryPassword(12);
    console.log("Generated temporary password");

    // Create user in Supabase Auth
    const { data: userData, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: {
        first_name: firstName,
        last_name: lastName,
        role,
        restaurant_id: restaurantId,
        is_owner: false,
      },
    });

    if (createError) {
      console.error("User creation error:", createError);
      return new Response(
        JSON.stringify({ error: createError.message }),
        { 
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }

    console.log(`User created successfully with ID: ${userData.user.id}`);

    // Send welcome email with credentials
    await resend.emails.send({
      from: "PlateSync <noreply@platesync.app>",
      to: [email],
      subject: "Welcome to PlateSync - Your Login Credentials",
      html: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #4f46e5;">Welcome to PlateSync</h1>
          <p>You've been added to a restaurant team on PlateSync. Here are your login credentials:</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Temporary Password:</strong> ${tempPassword}</p>
          <p style="font-weight: bold; color: #dc2626;">Please change your password after logging in for the first time.</p>
          <p>Click the button below to login:</p>
          <a href="${SUPABASE_URL.replace('.supabase.co', '')}" style="background-color: #4f46e5; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; display: inline-block; margin: 10px 0;">Login to PlateSync</a>
        </div>
      `,
    });

    console.log("Welcome email sent successfully");

    return new Response(
      JSON.stringify({ message: "User created and email sent successfully" }),
      { 
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  } catch (err) {
    console.error("Error:", err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});

// Function to generate a secure random password
function generateTemporaryPassword(length: number): string {
  const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
  let password = "";
  
  // Generate cryptographically secure random values
  const randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  
  // Convert random values to password characters
  for (let i = 0; i < length; i++) {
    password += charset[randomValues[i] % charset.length];
  }
  
  return password;
}
