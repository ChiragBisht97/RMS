
-- Create storage bucket for restaurant logos
INSERT INTO storage.buckets (id, name, public)
VALUES ('logos', 'logos', true)
ON CONFLICT (id) DO NOTHING;

-- Set up security policies for the logos bucket
CREATE POLICY "Public access to logos"
ON storage.objects
FOR SELECT
USING (bucket_id = 'logos');

-- Only authenticated users can insert logos
CREATE POLICY "Authenticated users can upload logos"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'logos' AND
  auth.role() = 'authenticated'
);

-- Only restaurant owners or admins can update logos
CREATE POLICY "Owners and admins can update logos"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'logos' AND
  auth.role() = 'authenticated' AND
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE pro_id = auth.uid() AND (is_owner = true OR pro_role = 'admin')
  )
);
