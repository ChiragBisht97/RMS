
-- Create user_permissions table
CREATE TABLE IF NOT EXISTS public.user_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(pro_id) ON DELETE CASCADE,
  module TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  -- Composite unique constraint
  UNIQUE(user_id, module)
);

-- Add comment to the table
COMMENT ON TABLE public.user_permissions IS 'Stores user module access permissions';

-- Enable RLS
ALTER TABLE public.user_permissions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own permissions" 
  ON public.user_permissions 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Only admins and owners can manage permissions
CREATE POLICY "Admins can manage all permissions" 
  ON public.user_permissions 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE pro_id = auth.uid() 
      AND (pro_role = 'admin' OR is_owner = true)
    )
  );
